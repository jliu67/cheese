# Changelog

## 2.2.0 — 2026-08-31

### Impact-safe entry sizing

- Added fee-aware pre-trade simulation of both the taker buy and an immediate full bid-side liquidation.
- Added configurable maximum taker entry slippage, maximum immediate round-trip loss, required liquidation fraction, minimum taker notional, and bounded binary-search sizing.
- Taker candidates are reduced to the largest safe quantity instead of sweeping every visible ask level.
- Unsafe taker candidates fall back to queue-aware maker execution and preserve the exact taker rejection reason.
- Pending taker orders repeat the full preflight against a later authoritative depth observation and may be reduced or cancelled before any fill.
- Fee-aware target prices now recover entry costs and entry fees before adding the configured net target return.

### Thesis-aware exits

- Reclassified `stop_loss` as a wide catastrophic executable-liquidation stop; the default is now 8%.
- Increased the default minimum hold to 10 minutes.
- Added a five-minute persistent signal-deterioration grace after the minimum hold; score recovery resets the timer.
- Kept the four-hour maximum hold and immediate serious-risk/resolution exits.
- Risk calculations use the current event timestamp rather than wall-clock time where deterministic live/paper decisions require it.

### Re-entry protection

- Added a four-hour whole-market cooldown after the first losing trade.
- Added same-market UTC-day lockout after two losses, including across complementary YES/NO outcomes.
- Reset market loss controls on the next UTC risk day.

### Diagnostics and packaging

- Added requested versus safe notional, immediate-exit VWAP, liquidation fraction, immediate round-trip return, slippage, and taker rejection reason to entry-attempt storage.
- Expanded progress and reports with impact-safe taker preflight statistics.
- Moved default database, raw-feed, export, and log paths to V2.2-specific locations.
- Bumped package and CLI version to 2.2.0.
- Remains strictly paper-only.

## 2.1.0 — 2026-08-31

### Targeted freshness

- Replaced stale-entry abandonment with asynchronous per-token CLOB refresh requests.
- Added dedicated refresh workers, a bounded/coalesced request queue, a two-second default timeout, and refresh events that re-enter the monotonic local event sequence.
- Added distinct quote, top-level, and full-depth freshness tracking and consistency checks between quoted best prices and executable depth.
- Recompute the latest feature/signal snapshot after a successful entry refresh and abandon the attempt if the signal faded.
- Reuse targeted refreshes for pending taker entries and risk exits without blocking the WebSocket processor.

### Diagnostics and calibration

- Added persistent `entry_attempts` with initial/refreshed score, book ages, refresh state/latency, execution economics, decision, and rejection reason.
- Expanded `progress` and exported reports with entry-attempt and targeted-refresh diagnostics.
- Corrected forward labels so spread/fee setups already beyond the stop at entry are `UNTRADEABLE_AT_ENTRY`, not `STOP`.
- Made forward taker calibration include entry and exit fees.

### Packaging

- Bumped package/CLI version to 2.1.0 and moved default structured/raw/export paths to V2.1-specific locations.
- Added a headless runner for remote/tmux operation.
- Added targeted-refresh, freshness, entry-attempt, and calibration regression tests.

### Scope

- Keeps `entry_score: 69`, hybrid maker/taker execution, near-full-bankroll depth-capped paper sizing, and the 4-hour maximum hold.
- Remains strictly paper-only; no wallet, signing, deposits, withdrawals, or real-order submission.

## 2.0.0 — 2026-08-31

### Simulator correctness

- Added monotonic receive-event sequence IDs and stored `active_after_sequence` on simulated orders and exit requests.
- Prevented queued trades received before an order existed from filling that later order.
- Added configurable maker/taker placement latency and exchange-clock-skew protection.
- Added per-price depth observation sequence and local freshness metadata.
- Added stale-depth blocking for entries, taker entries, stops, signal exits, maximum-hold exits, kill-switch exits, resolution-buffer exits, and shutdown flattening.
- Added persistent `EXIT_REQUIRED` requests that wait for later fresh executable depth rather than fabricating a fill from a cached book.
- Added a counterfactual shadow book that tracks paper-consumed liquidity per price and replenishes only demonstrated public size increases.
- Added trade-driven level invalidation so a trade that may have consumed a level makes that cached level non-executable until re-observed.
- Added transaction/event deduplication before feature and fill processing.
- Added mark equity and fee/depth-aware liquidation equity; risk controls now use liquidation equity.
- Added conservative zero value for position quantity beyond fresh visible liquidation depth by default.
- Corrected `min_order_size` validation to use outcome-share quantity.
- Added conservative default taker fees when market fee metadata is unknown.
- Changed feature chronology to local receipt order and blocked stale top-of-book outcome labels.

### Strategy and execution

- Added near-full-bankroll paper sizing with a cash buffer, one-position default, and visible-depth utilization cap.
- Added queue-aware maker pricing, bid improvement, queue-time estimates, and queue rejection diagnostics.
- Added hybrid maker/taker entry with spread, fee, tick, depth, and expected-net-target gates.
- Prevented taker entries from filling against the same cached snapshot used to make the decision.
- Added signal hysteresis with a separate lower cancellation threshold and grace period.
- Added full-size FAK-style paper risk exits with realistic partial fills and cancelled remainders.
- Added cancelled-entry missed-move watches.
- Added forward signal outcome tracking at 5m, 15m, 30m, 1h, and 4h horizons.

### Operations and reporting

- Added a fresh V2 database and data paths so corrected results are not mixed with V1.
- Added runtime metrics for queue depth, processing lag, duplicate events, pending exits, entry states, queue size, and rejection reasons.
- Added `pm-scalper progress` and `scripts/progress.sh` for live diagnostics without stopping the engine.
- Expanded CSV/JSON reports with exit requests, signal outcomes, missed moves, and runtime metrics.
- Reduced dashboard refresh pressure for browser-based SSH terminals.
- Updated bootstrap to auto-detect Python 3.11–3.13, including Ubuntu 24.04's Python 3.12.
- Added 49 offline regression/API/storage tests.

### Scope

- Remains paper-only with no wallet, signing, authentication, deposit, withdrawal, or real-order path.
- Open positions and pending orders are not resumed after a process restart; a restart begins a fresh paper run.

## 1.0.0 — 2026-08-30

- Initial public-data recorder and maker-first forward paper trader.
