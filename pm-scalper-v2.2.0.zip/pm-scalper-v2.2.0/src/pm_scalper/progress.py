from __future__ import annotations

import json
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

from rich.console import Console
from rich.table import Table

from .config import AppConfig
from .storage import SQLiteStore
from .util import fmt_money

CONSOLE = Console()


def show_progress(
    config: AppConfig,
    run_id: str | None = None,
    top: int = 20,
) -> None:
    """Print a non-destructive operational and research snapshot for one run."""

    store = SQLiteStore(config)
    try:
        selected = run_id or store.latest_run_id(running_only=True) or store.latest_run_id()
        if not selected:
            raise RuntimeError("No PM-Scalper V2.2 runs exist in the configured database")
        run_rows = store.fetch_all("SELECT * FROM runs WHERE run_id=?", (selected,))
        if not run_rows:
            raise RuntimeError(f"Run not found: {selected}")
        run = run_rows[0]

        _show_overview(store, selected, run)
        _show_score_distribution(store, selected)
        _show_entry_pipeline(store, selected)
        _show_taker_preflight(store, selected)
        _show_order_progress(store, selected)
        _show_runtime_health(store, selected)
        _show_entry_blocks(store, selected)
        _show_recent_attempts(store, selected, max(0, top))
        _show_signal_states(store, selected)
        _show_outcome_calibration(store, selected)
        _show_actual_execution_calibration(store, selected)
    finally:
        store.close()


def _show_overview(store: SQLiteStore, run_id: str, run: Any) -> None:
    overview = Table(title=f"PM-Scalper V2.2 progress — {run_id}")
    overview.add_column("Metric")
    overview.add_column("Value", justify="right")
    overview.add_row("Status", str(run["status"]))
    overview.add_row("Started", str(run["started_at"]))
    overview.add_row("Finished", str(run["finished_at"] or "—"))

    signal = store.fetch_all(
        """
        SELECT COUNT(*) n, MIN(score) min_score, AVG(score) avg_score, MAX(score) max_score,
               SUM(eligible) eligible
        FROM signals WHERE run_id=?
        """,
        (run_id,),
    )[0]
    overview.add_row("Signal samples", f"{int(signal['n'] or 0):,}")
    overview.add_row(
        "Score min / avg / max",
        "—"
        if signal["n"] == 0
        else (
            f"{float(signal['min_score']):.2f} / "
            f"{float(signal['avg_score']):.2f} / "
            f"{float(signal['max_score']):.2f}"
        ),
    )
    overview.add_row("Eligible signal samples", f"{int(signal['eligible'] or 0):,}")

    attempts = store.fetch_all(
        """
        SELECT COUNT(*) n,
               SUM(CASE WHEN decision='ORDER_CREATED' THEN 1 ELSE 0 END) orders,
               SUM(CASE WHEN decision='BLOCKED' THEN 1 ELSE 0 END) blocked,
               SUM(CASE WHEN decision='REFRESH_REQUESTED' THEN 1 ELSE 0 END) pending
        FROM entry_attempts WHERE run_id=?
        """,
        (run_id,),
    )[0]
    overview.add_row("Unique entry attempts", f"{int(attempts['n'] or 0):,}")
    overview.add_row(
        "Attempt results: orders / blocked / refreshing",
        f"{int(attempts['orders'] or 0):,} / "
        f"{int(attempts['blocked'] or 0):,} / "
        f"{int(attempts['pending'] or 0):,}",
    )

    latest_equity = store.fetch_all(
        "SELECT * FROM equity WHERE run_id=? ORDER BY timestamp DESC LIMIT 1",
        (run_id,),
    )
    if latest_equity:
        equity = latest_equity[0]
        overview.add_row(
            "Liquidation / mark equity",
            f"{fmt_money(Decimal(equity['liquidation_equity']))} / "
            f"{fmt_money(Decimal(equity['mark_equity']))}",
        )
        overview.add_row("Cash", fmt_money(Decimal(equity["cash"])))
        overview.add_row("Open positions", str(equity["open_positions"]))

    trades = store.fetch_all(
        """
        SELECT COUNT(*) n, COALESCE(SUM(CAST(net_pnl AS REAL)),0) pnl,
               COALESCE(AVG(CAST(return_pct AS REAL)),0) avg_return,
               SUM(CASE WHEN CAST(net_pnl AS REAL)>0 THEN 1 ELSE 0 END) wins
        FROM closed_trades WHERE run_id=?
        """,
        (run_id,),
    )[0]
    overview.add_row("Closed trades", str(trades["n"]))
    overview.add_row("Closed-trade P&L", fmt_money(Decimal(str(trades["pnl"]))))
    if trades["n"]:
        overview.add_row(
            "Win rate / avg return",
            f"{100 * trades['wins'] / trades['n']:.1f}% / "
            f"{100 * trades['avg_return']:.3f}%",
        )
    CONSOLE.print(overview)


def _show_score_distribution(store: SQLiteStore, run_id: str) -> None:
    table = Table(title="Score distribution")
    table.add_column("Threshold", justify="right")
    table.add_column("Samples", justify="right")
    for threshold in [40, 45, 50, 55, 58, 60, 62, 65, 67, 69, 70, 72, 75]:
        count = store.fetch_all(
            "SELECT COUNT(*) n FROM signals WHERE run_id=? AND score>=?",
            (run_id, threshold),
        )[0]["n"]
        table.add_row(f"{threshold}+", f"{count:,}")
    CONSOLE.print(table)


def _show_entry_pipeline(store: SQLiteStore, run_id: str) -> None:
    row = store.fetch_all(
        """
        SELECT COUNT(*) attempts,
               SUM(refresh_required) refresh_required,
               SUM(refresh_attempted) refresh_attempted,
               SUM(CASE WHEN refresh_success=1 THEN 1 ELSE 0 END) refresh_success,
               SUM(CASE WHEN refresh_success=0 THEN 1 ELSE 0 END) refresh_failed,
               SUM(CASE WHEN decision='ORDER_CREATED' THEN 1 ELSE 0 END) order_created,
               SUM(CASE WHEN decision='BLOCKED' THEN 1 ELSE 0 END) blocked,
               SUM(CASE WHEN decision='CANCELLED' THEN 1 ELSE 0 END) cancelled,
               SUM(CASE WHEN decision='REFRESH_REQUESTED' THEN 1 ELSE 0 END) refreshing,
               AVG(CASE WHEN refresh_latency_ms IS NOT NULL THEN refresh_latency_ms END) avg_refresh_ms,
               MAX(refresh_latency_ms) max_refresh_ms
        FROM entry_attempts WHERE run_id=?
        """,
        (run_id,),
    )[0]
    table = Table(title="Entry decision pipeline")
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    table.add_row("Eligible attempts evaluated", f"{int(row['attempts'] or 0):,}")
    table.add_row("Required targeted refresh", f"{int(row['refresh_required'] or 0):,}")
    table.add_row("Refresh attempted", f"{int(row['refresh_attempted'] or 0):,}")
    table.add_row(
        "Refresh success / failed",
        f"{int(row['refresh_success'] or 0):,} / {int(row['refresh_failed'] or 0):,}",
    )
    table.add_row("Orders created", f"{int(row['order_created'] or 0):,}")
    table.add_row("Blocked after evaluation", f"{int(row['blocked'] or 0):,}")
    table.add_row("Still refreshing", f"{int(row['refreshing'] or 0):,}")
    table.add_row("Cancelled during shutdown", f"{int(row['cancelled'] or 0):,}")
    table.add_row(
        "Refresh latency avg / max",
        "—"
        if row["avg_refresh_ms"] is None
        else f"{float(row['avg_refresh_ms']):.1f}ms / {float(row['max_refresh_ms']):.1f}ms",
    )
    CONSOLE.print(table)


def _show_taker_preflight(store: SQLiteStore, run_id: str) -> None:
    row = store.fetch_all(
        """
        SELECT
            SUM(CASE WHEN taker_rejection_reason IS NOT NULL
                      OR (execution_style='TAKER' AND decision='ORDER_CREATED')
                     THEN 1 ELSE 0 END) candidates,
            SUM(CASE WHEN execution_style='TAKER' AND decision='ORDER_CREATED'
                     THEN 1 ELSE 0 END) accepted,
            SUM(CASE WHEN taker_rejection_reason IS NOT NULL
                     THEN 1 ELSE 0 END) rejected,
            AVG(CASE WHEN execution_style='TAKER' AND requested_notional IS NOT NULL
                     THEN CAST(requested_notional AS REAL) END) avg_requested,
            AVG(CASE WHEN execution_style='TAKER' AND safe_notional IS NOT NULL
                     THEN CAST(safe_notional AS REAL) END) avg_safe,
            AVG(CASE WHEN execution_style='TAKER' AND estimated_slippage_pct IS NOT NULL
                     THEN CAST(estimated_slippage_pct AS REAL) END) avg_slippage,
            MAX(CASE WHEN execution_style='TAKER' AND estimated_slippage_pct IS NOT NULL
                     THEN CAST(estimated_slippage_pct AS REAL) END) max_slippage,
            AVG(CASE WHEN execution_style='TAKER' AND immediate_round_trip_return IS NOT NULL
                     THEN CAST(immediate_round_trip_return AS REAL) END) avg_round_trip,
            MIN(CASE WHEN execution_style='TAKER' AND immediate_round_trip_return IS NOT NULL
                     THEN CAST(immediate_round_trip_return AS REAL) END) worst_round_trip
        FROM entry_attempts WHERE run_id=?
        """,
        (run_id,),
    )[0]
    table = Table(title="Impact-safe taker preflight")
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    table.add_row("Taker candidates evaluated", f"{int(row['candidates'] or 0):,}")
    table.add_row("Impact-safe taker orders", f"{int(row['accepted'] or 0):,}")
    table.add_row("Rejected / maker fallback", f"{int(row['rejected'] or 0):,}")
    if row["avg_requested"] is not None:
        table.add_row(
            "Average requested → safe notional",
            f"{fmt_money(Decimal(str(row['avg_requested'])))} → "
            f"{fmt_money(Decimal(str(row['avg_safe'] or 0)))}",
        )
    else:
        table.add_row("Average requested → safe notional", "—")
    if row["avg_slippage"] is None:
        table.add_row("Entry slippage avg / max", "—")
    else:
        table.add_row(
            "Entry slippage avg / max",
            f"{float(row['avg_slippage']) * 100:+.3f}% / "
            f"{float(row['max_slippage']) * 100:+.3f}%",
        )
    if row["avg_round_trip"] is None:
        table.add_row("Immediate round trip avg / worst", "—")
    else:
        table.add_row(
            "Immediate round trip avg / worst",
            f"{float(row['avg_round_trip']) * 100:+.3f}% / "
            f"{float(row['worst_round_trip']) * 100:+.3f}%",
        )
    CONSOLE.print(table)

    reasons = store.fetch_all(
        """
        SELECT taker_rejection_reason reason, COUNT(*) n
        FROM entry_attempts
        WHERE run_id=? AND taker_rejection_reason IS NOT NULL
        GROUP BY taker_rejection_reason
        ORDER BY n DESC, taker_rejection_reason
        LIMIT 10
        """,
        (run_id,),
    )
    if reasons:
        reason_table = Table(title="Taker preflight rejection reasons")
        reason_table.add_column("Reason")
        reason_table.add_column("Attempts", justify="right")
        for item in reasons:
            reason_table.add_row(str(item["reason"]), f"{int(item['n']):,}")
        CONSOLE.print(reason_table)


def _show_order_progress(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        """
        SELECT intent, execution_style, status, COUNT(*) n,
               SUM(CASE WHEN CAST(filled_quantity AS REAL)>0 THEN 1 ELSE 0 END) touched,
               AVG(CAST(queue_ahead AS REAL)) avg_queue
        FROM orders WHERE run_id=?
        GROUP BY intent, execution_style, status
        ORDER BY intent, execution_style, status
        """,
        (run_id,),
    )
    table = Table(title="Execution progress")
    table.add_column("Intent")
    table.add_column("Style")
    table.add_column("Status")
    table.add_column("Orders", justify="right")
    table.add_column("Any fill", justify="right")
    table.add_column("Avg queue", justify="right")
    for row in rows:
        table.add_row(
            str(row["intent"]),
            str(row["execution_style"]),
            str(row["status"]),
            f"{row['n']:,}",
            f"{int(row['touched'] or 0):,}",
            "—" if row["avg_queue"] is None else f"{row['avg_queue']:,.0f}",
        )
    if not rows:
        table.add_row("—", "—", "—", "0", "0", "—")
    CONSOLE.print(table)


def _show_runtime_health(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        "SELECT * FROM runtime_metrics WHERE run_id=? ORDER BY timestamp DESC LIMIT 1",
        (run_id,),
    )
    if not rows:
        return
    row = rows[0]
    table = Table(title="Live engine health")
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    table.add_row("Queue depth", f"{row['queue_depth']:,}")
    table.add_row(
        "Current / max processing lag",
        f"{row['event_processing_lag_seconds']:.3f}s / "
        f"{row['max_event_processing_lag_seconds']:.3f}s",
    )
    table.add_row(
        "Processed / received sequence",
        f"{row['processed_events']:,} / {row['received_events']:,}",
    )
    table.add_row("Duplicate trade events ignored", f"{row['duplicate_trades']:,}")
    table.add_row("Pending exits", f"{row['pending_exits']:,}")
    table.add_row("Pending entry refreshes", f"{row['pending_entry_refreshes']:,}")
    table.add_row("Missed moves", f"{row['missed_moves']:,}")
    table.add_row(
        "Targeted refreshes: requested / success / failed",
        f"{row['refresh_requests']:,} / {row['refresh_successes']:,} / "
        f"{row['refresh_failures']:,}",
    )
    table.add_row("Refresh timeouts / coalesced", f"{row['refresh_timeouts']:,} / {row['refresh_coalesced']:,}")
    table.add_row(
        "Refresh latency avg / max",
        f"{row['average_refresh_latency_ms']:.1f}ms / {row['max_refresh_latency_ms']:.1f}ms",
    )
    try:
        rejection_counts = json.loads(row["entry_rejections_json"] or "{}")
    except (json.JSONDecodeError, TypeError):
        rejection_counts = {}
    if rejection_counts:
        reason, count = max(rejection_counts.items(), key=lambda item: int(item[1]))
        table.add_row("Most common entry block", f"{reason} ({int(count):,})")
    CONSOLE.print(table)


def _show_entry_blocks(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        """
        SELECT reason, COUNT(*) n
        FROM entry_attempts
        WHERE run_id=? AND decision IN ('BLOCKED','CANCELLED')
        GROUP BY reason ORDER BY n DESC, reason LIMIT 15
        """,
        (run_id,),
    )
    table = Table(title="Entry blocks — exact execution reasons")
    table.add_column("Reason")
    table.add_column("Attempts", justify="right")
    if rows:
        for row in rows:
            table.add_row(str(row["reason"]), f"{row['n']:,}")
    else:
        table.add_row("—", "0")
    CONSOLE.print(table)


def _show_recent_attempts(store: SQLiteStore, run_id: str, top: int) -> None:
    if top <= 0:
        return
    rows = store.fetch_all(
        """
        SELECT created_at, outcome, initial_score, score_after_refresh,
               quote_age_ms, full_depth_age_ms, refresh_required, refresh_success,
               refresh_latency_ms, execution_style, requested_notional, safe_notional,
               estimated_slippage_pct, immediate_round_trip_return,
               expected_net_target_return, taker_rejection_reason, decision, reason
        FROM entry_attempts
        WHERE run_id=?
        ORDER BY created_at DESC LIMIT ?
        """,
        (run_id, top),
    )
    table = Table(title=f"Latest {top} entry attempts", expand=True)
    table.add_column("UTC", no_wrap=True)
    table.add_column("Side", no_wrap=True)
    table.add_column("Score", justify="right", no_wrap=True)
    table.add_column("Quote/depth age", justify="right", no_wrap=True)
    table.add_column("Refresh", no_wrap=True)
    table.add_column("Style", no_wrap=True)
    table.add_column("Requested → safe", justify="right", no_wrap=True)
    table.add_column("RT / slip", justify="right", no_wrap=True)
    table.add_column("Net target", justify="right", no_wrap=True)
    table.add_column("Decision / reason", ratio=2)
    if not rows:
        table.add_row("—", "—", "—", "—", "—", "—", "—", "—", "—", "No attempts")
    for row in rows:
        created = datetime.fromtimestamp(float(row["created_at"]), tz=timezone.utc)
        refresh = "not needed"
        if row["refresh_required"]:
            if row["refresh_success"] is None:
                refresh = "pending"
            elif row["refresh_success"]:
                latency = row["refresh_latency_ms"]
                refresh = "ok" if latency is None else f"ok {float(latency):.0f}ms"
            else:
                refresh = "failed"
        score = f"{float(row['initial_score']):.2f}"
        if row["score_after_refresh"] is not None:
            score += f"→{float(row['score_after_refresh']):.2f}"
        ages = f"{_format_ms(row['quote_age_ms'])}/{_format_ms(row['full_depth_age_ms'])}"
        notional = "—"
        if row["requested_notional"] is not None:
            requested = fmt_money(Decimal(str(row["requested_notional"])))
            safe = (
                "—"
                if row["safe_notional"] is None
                else fmt_money(Decimal(str(row["safe_notional"])))
            )
            notional = f"{requested}→{safe}"
        impact = "—"
        if row["immediate_round_trip_return"] is not None:
            impact = f"{Decimal(str(row['immediate_round_trip_return'])) * 100:+.2f}%"
            if row["estimated_slippage_pct"] is not None:
                impact += f" / {Decimal(str(row['estimated_slippage_pct'])) * 100:+.2f}%"
        net_target = "—"
        if row["expected_net_target_return"] is not None:
            net_target = f"{Decimal(str(row['expected_net_target_return'])) * 100:+.3f}%"
        detail = f"{row['decision']}: {row['reason'] or '—'}"
        if row["taker_rejection_reason"] and str(row["taker_rejection_reason"]) not in detail:
            detail += f" | taker: {row['taker_rejection_reason']}"
        table.add_row(
            created.strftime("%H:%M:%S"),
            str(row["outcome"]),
            score,
            ages,
            refresh,
            str(row["execution_style"] or "—"),
            notional,
            impact,
            net_target,
            detail,
        )
    CONSOLE.print(table)


def _show_signal_states(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        """
        SELECT reason, COUNT(*) n FROM signals WHERE run_id=?
        GROUP BY reason ORDER BY n DESC LIMIT 10
        """,
        (run_id,),
    )
    table = Table(title="Signal states")
    table.add_column("Reason")
    table.add_column("Samples", justify="right")
    for row in rows:
        table.add_row(str(row["reason"]), f"{row['n']:,}")
    CONSOLE.print(table)


def _show_outcome_calibration(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        """
        SELECT score, first_barrier, horizon_returns_json, completed,
               tradeable_at_entry, untradeable_reason
        FROM signal_outcomes WHERE run_id=?
        """,
        (run_id,),
    )
    table = Table(title="Forward calibration — fee-aware taker entry → future executable bid")
    table.add_column("Score bucket")
    table.add_column("Samples", justify="right")
    table.add_column("Tradeable", justify="right")
    table.add_column("Untradeable", justify="right")
    table.add_column("Target first", justify="right")
    table.add_column("Stop first", justify="right")
    table.add_column("Undecided", justify="right")
    table.add_column("Matured 1h avg", justify="right")
    buckets = [
        (40, 50, "40–50"),
        (50, 55, "50–55"),
        (55, 60, "55–60"),
        (60, 65, "60–65"),
        (65, 69, "65–69"),
        (69, 101, "69+"),
    ]
    for low, high, label in buckets:
        selected = [row for row in rows if low <= float(row["score"]) < high]
        tradeable = sum(1 for row in selected if bool(row["tradeable_at_entry"]))
        untradeable = len(selected) - tradeable
        target = sum(1 for row in selected if row["first_barrier"] == "TARGET")
        stop = sum(1 for row in selected if row["first_barrier"] == "STOP")
        undecided = sum(
            1
            for row in selected
            if bool(row["tradeable_at_entry"])
            and row["first_barrier"] not in {"TARGET", "STOP"}
        )
        one_hour: list[float] = []
        for row in selected:
            if not bool(row["tradeable_at_entry"]):
                continue
            try:
                returns: dict[str, Any] = json.loads(row["horizon_returns_json"])
                value = returns.get("3600")
                if value is not None:
                    one_hour.append(float(value))
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
        avg = sum(one_hour) / len(one_hour) if one_hour else None
        table.add_row(
            label,
            f"{len(selected):,}",
            f"{tradeable:,}",
            f"{untradeable:,}",
            f"{target:,}",
            f"{stop:,}",
            f"{undecided:,}",
            "—" if avg is None else f"{avg * 100:+.3f}%",
        )
    CONSOLE.print(table)


def _show_actual_execution_calibration(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        """
        SELECT execution_style,
               COUNT(*) orders,
               SUM(CASE WHEN CAST(filled_quantity AS REAL)>0 THEN 1 ELSE 0 END) any_fill,
               SUM(CASE WHEN status='FILLED' THEN 1 ELSE 0 END) full_fill,
               AVG(CAST(queue_ahead AS REAL)) avg_queue
        FROM orders
        WHERE run_id=? AND intent='ENTRY'
        GROUP BY execution_style ORDER BY execution_style
        """,
        (run_id,),
    )
    trade_rows = store.fetch_all(
        """
        SELECT COUNT(*) trades,
               SUM(CASE WHEN CAST(net_pnl AS REAL)>0 THEN 1 ELSE 0 END) wins,
               AVG(CAST(return_pct AS REAL)) avg_return
        FROM closed_trades WHERE run_id=?
        """,
        (run_id,),
    )[0]
    table = Table(title="Actual paper-execution calibration")
    table.add_column("Style")
    table.add_column("Entry orders", justify="right")
    table.add_column("Any fill", justify="right")
    table.add_column("Full fill", justify="right")
    table.add_column("Fill rate", justify="right")
    table.add_column("Avg queue", justify="right")
    if rows:
        for row in rows:
            orders = int(row["orders"] or 0)
            any_fill = int(row["any_fill"] or 0)
            table.add_row(
                str(row["execution_style"]),
                f"{orders:,}",
                f"{any_fill:,}",
                f"{int(row['full_fill'] or 0):,}",
                f"{100 * any_fill / orders:.1f}%" if orders else "—",
                "—" if row["avg_queue"] is None else f"{float(row['avg_queue']):,.0f}",
            )
    else:
        table.add_row("—", "0", "0", "0", "—", "—")
    trades = int(trade_rows["trades"] or 0)
    wins = int(trade_rows["wins"] or 0)
    avg_return = float(trade_rows["avg_return"] or 0.0)
    table.caption = (
        f"Closed trades: {trades:,}; wins: {wins:,}; "
        f"win rate: {100 * wins / trades:.1f}%" if trades else "No completed paper trades yet."
    )
    if trades:
        table.caption += f"; average return: {100 * avg_return:+.3f}%"
    CONSOLE.print(table)


def _format_ms(value: Any) -> str:
    if value is None:
        return "—"
    number = float(value)
    if number < 1000:
        return f"{number:.0f}ms"
    return f"{number / 1000:.1f}s"
