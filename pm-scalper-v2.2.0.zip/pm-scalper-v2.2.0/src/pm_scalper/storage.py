from __future__ import annotations

import csv
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Iterable

from .config import AppConfig
from .models import (
    Asset,
    ClosedTrade,
    EntryAttempt,
    ExitRequest,
    Fill,
    MissedMove,
    PaperOrder,
    RuntimeMetrics,
    SignalOutcome,
    SignalSnapshot,
)
from .util import iso_now, json_dumps


class RawEventRecorder:
    def __init__(self, config: AppConfig, run_id: str) -> None:
        root = Path(config.storage.raw_event_dir)
        date_dir = root / iso_now()[:10]
        date_dir.mkdir(parents=True, exist_ok=True)
        self.path = date_dir / f"events-{run_id}.jsonl"
        self._handle = self.path.open("a", encoding="utf-8", buffering=1)
        self._flush_every = max(1, config.storage.raw_flush_every)
        self._count = 0

    def write(
        self, payload: dict[str, Any], received_at: float, sequence_id: int = 0
    ) -> None:
        record = {
            "sequence_id": sequence_id,
            "received_at": received_at,
            "payload": payload,
        }
        self._handle.write(json_dumps(record) + "\n")
        self._count += 1
        if self._count % self._flush_every == 0:
            self._handle.flush()

    def close(self) -> None:
        if not self._handle.closed:
            self._handle.flush()
            self._handle.close()


class SQLiteStore:
    def __init__(self, config: AppConfig) -> None:
        path = Path(config.storage.sqlite_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.connection = sqlite3.connect(path, timeout=30.0)
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA synchronous=NORMAL")
        self.connection.execute("PRAGMA busy_timeout=30000")
        self._dirty = 0
        self._create_schema()

    def _create_schema(self) -> None:
        self.connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS runs (
                run_id TEXT PRIMARY KEY,
                started_at TEXT NOT NULL,
                finished_at TEXT,
                mode TEXT NOT NULL,
                status TEXT NOT NULL,
                config_json TEXT NOT NULL,
                note TEXT
            );

            CREATE TABLE IF NOT EXISTS assets (
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                market_id TEXT NOT NULL,
                condition_id TEXT NOT NULL,
                slug TEXT,
                question TEXT NOT NULL,
                outcome TEXT NOT NULL,
                market_liquidity TEXT NOT NULL,
                market_volume_24h TEXT NOT NULL,
                end_date TEXT,
                fee_json TEXT NOT NULL,
                PRIMARY KEY (run_id, token_id)
            );

            CREATE TABLE IF NOT EXISTS signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                timestamp REAL NOT NULL,
                token_id TEXT NOT NULL,
                score REAL NOT NULL,
                eligible INTEGER NOT NULL,
                reason TEXT NOT NULL,
                features_json TEXT NOT NULL,
                components_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_signals_run_time ON signals(run_id, timestamp);
            CREATE INDEX IF NOT EXISTS idx_signals_run_score ON signals(run_id, score);

            CREATE TABLE IF NOT EXISTS entry_attempts (
                attempt_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                market_id TEXT NOT NULL,
                outcome TEXT NOT NULL,
                question TEXT NOT NULL,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                initial_score REAL NOT NULL,
                score_after_refresh REAL,
                bid TEXT,
                ask TEXT,
                spread TEXT,
                quoted_bid TEXT,
                quoted_ask TEXT,
                bid_top_age_ms REAL,
                ask_top_age_ms REAL,
                quote_age_ms REAL,
                full_depth_age_ms REAL,
                refresh_required INTEGER NOT NULL,
                refresh_attempted INTEGER NOT NULL,
                refresh_request_id TEXT,
                refresh_started_at REAL,
                refresh_completed_at REAL,
                refresh_latency_ms REAL,
                refresh_success INTEGER,
                execution_style TEXT,
                maker_price TEXT,
                taker_vwap TEXT,
                immediate_exit_vwap TEXT,
                requested_notional TEXT,
                safe_notional TEXT,
                estimated_fee TEXT,
                estimated_slippage_pct TEXT,
                immediate_liquidation_fraction TEXT,
                immediate_round_trip_return TEXT,
                expected_net_target_return TEXT,
                taker_rejection_reason TEXT,
                decision TEXT NOT NULL,
                reason TEXT NOT NULL,
                order_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_attempts_run_time ON entry_attempts(run_id, created_at);
            CREATE INDEX IF NOT EXISTS idx_attempts_run_decision ON entry_attempts(run_id, decision);

            CREATE TABLE IF NOT EXISTS orders (
                order_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                market_id TEXT NOT NULL,
                outcome TEXT NOT NULL,
                side TEXT NOT NULL,
                intent TEXT NOT NULL,
                execution_style TEXT NOT NULL,
                limit_price TEXT NOT NULL,
                quantity TEXT NOT NULL,
                filled_quantity TEXT NOT NULL,
                average_fill_price TEXT NOT NULL,
                queue_ahead TEXT NOT NULL,
                estimated_queue_seconds REAL,
                created_at REAL NOT NULL,
                active_at REAL NOT NULL,
                active_after_sequence INTEGER NOT NULL,
                expires_at REAL,
                fade_started_at REAL,
                status TEXT NOT NULL,
                score_at_creation REAL NOT NULL,
                reason TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_orders_run_time ON orders(run_id, created_at);

            CREATE TABLE IF NOT EXISTS fills (
                fill_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                order_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                side TEXT NOT NULL,
                intent TEXT NOT NULL,
                quantity TEXT NOT NULL,
                price TEXT NOT NULL,
                fee TEXT NOT NULL,
                maker INTEGER NOT NULL,
                timestamp REAL NOT NULL,
                sequence_id INTEGER NOT NULL
            );

            CREATE TABLE IF NOT EXISTS closed_trades (
                trade_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                market_id TEXT NOT NULL,
                outcome TEXT NOT NULL,
                question TEXT NOT NULL,
                opened_at REAL NOT NULL,
                closed_at REAL NOT NULL,
                quantity TEXT NOT NULL,
                average_entry_price TEXT NOT NULL,
                average_exit_price TEXT NOT NULL,
                gross_pnl TEXT NOT NULL,
                fees TEXT NOT NULL,
                net_pnl TEXT NOT NULL,
                return_pct TEXT NOT NULL,
                exit_reason TEXT NOT NULL,
                entry_score REAL NOT NULL,
                exit_score REAL NOT NULL
            );

            CREATE TABLE IF NOT EXISTS equity (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                timestamp REAL NOT NULL,
                cash TEXT NOT NULL,
                exposure TEXT NOT NULL,
                mark_unrealized_pnl TEXT NOT NULL,
                liquidation_unrealized_pnl TEXT NOT NULL,
                realized_pnl TEXT NOT NULL,
                mark_equity TEXT NOT NULL,
                liquidation_equity TEXT NOT NULL,
                open_positions INTEGER NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_equity_run_time ON equity(run_id, timestamp);

            CREATE TABLE IF NOT EXISTS exit_requests (
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                reason TEXT NOT NULL,
                requested_at REAL NOT NULL,
                exit_score REAL NOT NULL,
                active_after_sequence INTEGER NOT NULL,
                active_at REAL NOT NULL,
                status TEXT NOT NULL,
                attempts INTEGER NOT NULL,
                last_attempt_at REAL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (run_id, token_id)
            );

            CREATE TABLE IF NOT EXISTS signal_outcomes (
                outcome_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                market_id TEXT NOT NULL,
                outcome TEXT NOT NULL,
                question TEXT NOT NULL,
                created_at REAL NOT NULL,
                score REAL NOT NULL,
                entry_ask TEXT NOT NULL,
                initial_bid TEXT NOT NULL,
                target_price TEXT NOT NULL,
                stop_price TEXT NOT NULL,
                calibration_style TEXT NOT NULL,
                entry_fee_per_share TEXT NOT NULL,
                entry_cost_per_share TEXT NOT NULL,
                tradeable_at_entry INTEGER NOT NULL,
                untradeable_reason TEXT,
                first_barrier TEXT,
                barrier_at REAL,
                max_bid TEXT NOT NULL,
                min_bid TEXT NOT NULL,
                horizon_returns_json TEXT NOT NULL,
                completed INTEGER NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_outcomes_run_score ON signal_outcomes(run_id, score);

            CREATE TABLE IF NOT EXISTS missed_moves (
                missed_id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                token_id TEXT NOT NULL,
                market_id TEXT NOT NULL,
                outcome TEXT NOT NULL,
                question TEXT NOT NULL,
                order_id TEXT NOT NULL,
                cancelled_at REAL NOT NULL,
                entry_price TEXT NOT NULL,
                target_price TEXT NOT NULL,
                score REAL NOT NULL,
                expires_at REAL NOT NULL,
                hit_at REAL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS runtime_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                timestamp REAL NOT NULL,
                queue_depth INTEGER NOT NULL,
                event_processing_lag_seconds REAL NOT NULL,
                max_event_processing_lag_seconds REAL NOT NULL,
                duplicate_trades INTEGER NOT NULL,
                received_events INTEGER NOT NULL,
                processed_events INTEGER NOT NULL,
                max_score_seen REAL NOT NULL,
                eligible_signals INTEGER NOT NULL,
                entry_attempts INTEGER NOT NULL,
                entry_orders INTEGER NOT NULL,
                maker_entry_orders INTEGER NOT NULL,
                taker_entry_orders INTEGER NOT NULL,
                filled_entry_orders INTEGER NOT NULL,
                cancelled_entry_orders INTEGER NOT NULL,
                pending_exits INTEGER NOT NULL,
                missed_moves INTEGER NOT NULL,
                average_queue_ahead REAL NOT NULL,
                pending_entry_refreshes INTEGER NOT NULL,
                refresh_requests INTEGER NOT NULL,
                refresh_successes INTEGER NOT NULL,
                refresh_failures INTEGER NOT NULL,
                refresh_timeouts INTEGER NOT NULL,
                refresh_coalesced INTEGER NOT NULL,
                average_refresh_latency_ms REAL NOT NULL,
                max_refresh_latency_ms REAL NOT NULL,
                entry_rejections_json TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_runtime_run_time ON runtime_metrics(run_id, timestamp);
            """
        )
        # Forward-compatible migration for users who deliberately point V2.2 at a
        # V2.1 database. The default uses a fresh file, but adding nullable audit
        # columns is safe and prevents a confusing runtime failure.
        self._ensure_column("entry_attempts", "immediate_exit_vwap", "TEXT")
        self._ensure_column("entry_attempts", "safe_notional", "TEXT")
        self._ensure_column(
            "entry_attempts", "immediate_liquidation_fraction", "TEXT"
        )
        self._ensure_column("entry_attempts", "immediate_round_trip_return", "TEXT")
        self._ensure_column("entry_attempts", "taker_rejection_reason", "TEXT")
        self.connection.commit()

    def _ensure_column(self, table: str, column: str, declaration: str) -> None:
        existing = {
            str(row[1])
            for row in self.connection.execute(f'PRAGMA table_info("{table}")')
        }
        if column not in existing:
            self.connection.execute(
                f'ALTER TABLE "{table}" ADD COLUMN "{column}" {declaration}'
            )

    def start_run(self, config: AppConfig, note: str | None = None) -> str:
        run_id = uuid.uuid4().hex[:12]
        self.connection.execute(
            "INSERT INTO runs(run_id, started_at, mode, status, config_json, note) VALUES(?,?,?,?,?,?)",
            (
                run_id,
                iso_now(),
                config.execution.mode,
                "RUNNING",
                json_dumps(config.as_dict()),
                note,
            ),
        )
        self.connection.commit()
        return run_id

    def finish_run(self, run_id: str, status: str, note: str | None = None) -> None:
        self.connection.execute(
            "UPDATE runs SET finished_at=?, status=?, note=COALESCE(?, note) WHERE run_id=?",
            (iso_now(), status, note, run_id),
        )
        self.connection.commit()

    def record_assets(self, run_id: str, assets: Iterable[Asset]) -> None:
        rows = []
        for asset in assets:
            rows.append(
                (
                    run_id,
                    asset.token_id,
                    asset.market_id,
                    asset.condition_id,
                    asset.slug,
                    asset.question,
                    asset.outcome,
                    str(asset.market_liquidity),
                    str(asset.market_volume_24h),
                    asset.end_date.isoformat() if asset.end_date else None,
                    json_dumps(asset.fee_schedule),
                )
            )
        self.connection.executemany(
            """
            INSERT OR REPLACE INTO assets(
                run_id, token_id, market_id, condition_id, slug, question, outcome,
                market_liquidity, market_volume_24h, end_date, fee_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """,
            rows,
        )
        self.connection.commit()

    def record_signal(self, run_id: str, signal: SignalSnapshot) -> None:
        self.connection.execute(
            """
            INSERT INTO signals(run_id, timestamp, token_id, score, eligible, reason, features_json, components_json)
            VALUES(?,?,?,?,?,?,?,?)
            """,
            (
                run_id,
                signal.timestamp,
                signal.token_id,
                signal.score,
                int(signal.eligible),
                signal.reason,
                json_dumps(signal.features.as_dict()),
                json_dumps(signal.components),
            ),
        )
        self._mark_dirty()

    def record_entry_attempt(
        self, run_id: str, attempt: EntryAttempt, *, force: bool = False
    ) -> None:
        def text(value: Any) -> str | None:
            return None if value is None else str(value)

        self.connection.execute(
            """
            INSERT INTO entry_attempts(
                attempt_id, run_id, token_id, market_id, outcome, question,
                created_at, updated_at, initial_score, score_after_refresh,
                bid, ask, spread, quoted_bid, quoted_ask, bid_top_age_ms,
                ask_top_age_ms, quote_age_ms, full_depth_age_ms, refresh_required,
                refresh_attempted, refresh_request_id, refresh_started_at,
                refresh_completed_at, refresh_latency_ms, refresh_success,
                execution_style, maker_price, taker_vwap, immediate_exit_vwap,
                requested_notional, safe_notional, estimated_fee,
                estimated_slippage_pct, immediate_liquidation_fraction,
                immediate_round_trip_return, expected_net_target_return,
                taker_rejection_reason, decision, reason, order_id
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(attempt_id) DO UPDATE SET
                updated_at=excluded.updated_at,
                score_after_refresh=excluded.score_after_refresh,
                bid=excluded.bid, ask=excluded.ask, spread=excluded.spread,
                quoted_bid=excluded.quoted_bid, quoted_ask=excluded.quoted_ask,
                bid_top_age_ms=excluded.bid_top_age_ms,
                ask_top_age_ms=excluded.ask_top_age_ms,
                quote_age_ms=excluded.quote_age_ms,
                full_depth_age_ms=excluded.full_depth_age_ms,
                refresh_required=excluded.refresh_required,
                refresh_attempted=excluded.refresh_attempted,
                refresh_request_id=excluded.refresh_request_id,
                refresh_started_at=excluded.refresh_started_at,
                refresh_completed_at=excluded.refresh_completed_at,
                refresh_latency_ms=excluded.refresh_latency_ms,
                refresh_success=excluded.refresh_success,
                execution_style=excluded.execution_style,
                maker_price=excluded.maker_price,
                taker_vwap=excluded.taker_vwap,
                immediate_exit_vwap=excluded.immediate_exit_vwap,
                requested_notional=excluded.requested_notional,
                safe_notional=excluded.safe_notional,
                estimated_fee=excluded.estimated_fee,
                estimated_slippage_pct=excluded.estimated_slippage_pct,
                immediate_liquidation_fraction=excluded.immediate_liquidation_fraction,
                immediate_round_trip_return=excluded.immediate_round_trip_return,
                expected_net_target_return=excluded.expected_net_target_return,
                taker_rejection_reason=excluded.taker_rejection_reason,
                decision=excluded.decision, reason=excluded.reason,
                order_id=excluded.order_id
            """,
            (
                attempt.id, run_id, attempt.token_id, attempt.market_id,
                attempt.outcome, attempt.question, attempt.created_at,
                attempt.updated_at, attempt.initial_score,
                attempt.score_after_refresh, text(attempt.bid), text(attempt.ask),
                text(attempt.spread), text(attempt.quoted_bid),
                text(attempt.quoted_ask), attempt.bid_top_age_ms,
                attempt.ask_top_age_ms, attempt.quote_age_ms,
                attempt.full_depth_age_ms, int(attempt.refresh_required),
                int(attempt.refresh_attempted), attempt.refresh_request_id,
                attempt.refresh_started_at, attempt.refresh_completed_at,
                attempt.refresh_latency_ms,
                None if attempt.refresh_success is None else int(attempt.refresh_success),
                attempt.execution_style, text(attempt.maker_price),
                text(attempt.taker_vwap), text(attempt.immediate_exit_vwap),
                text(attempt.requested_notional), text(attempt.safe_notional),
                text(attempt.estimated_fee), text(attempt.estimated_slippage_pct),
                text(attempt.immediate_liquidation_fraction),
                text(attempt.immediate_round_trip_return),
                text(attempt.expected_net_target_return),
                attempt.taker_rejection_reason, attempt.decision, attempt.reason,
                attempt.order_id,
            ),
        )
        self._mark_dirty(force=force or attempt.decision not in {"EVALUATING", "REFRESH_REQUESTED"})

    def record_order(self, run_id: str, order: PaperOrder, *, force: bool = False) -> None:
        self.connection.execute(
            """
            INSERT INTO orders(
                order_id, run_id, token_id, market_id, outcome, side, intent,
                execution_style, limit_price, quantity, filled_quantity,
                average_fill_price, queue_ahead, estimated_queue_seconds, created_at,
                active_at, active_after_sequence, expires_at, fade_started_at, status,
                score_at_creation, reason, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(order_id) DO UPDATE SET
                filled_quantity=excluded.filled_quantity,
                average_fill_price=excluded.average_fill_price,
                queue_ahead=excluded.queue_ahead,
                estimated_queue_seconds=excluded.estimated_queue_seconds,
                expires_at=excluded.expires_at,
                fade_started_at=excluded.fade_started_at,
                status=excluded.status,
                reason=excluded.reason,
                updated_at=excluded.updated_at
            """,
            (
                order.id,
                run_id,
                order.token_id,
                order.market_id,
                order.outcome,
                order.side,
                order.intent,
                order.execution_style,
                str(order.limit_price),
                str(order.quantity),
                str(order.filled_quantity),
                str(order.average_fill_price),
                str(order.queue_ahead),
                order.estimated_queue_seconds,
                order.created_at,
                order.active_at,
                order.active_after_sequence,
                order.expires_at,
                order.fade_started_at,
                order.status,
                order.score_at_creation,
                order.reason,
                iso_now(),
            ),
        )
        self._mark_dirty(force=force)

    def record_fill(self, run_id: str, fill: Fill) -> None:
        self.connection.execute(
            """
            INSERT INTO fills(
                fill_id, run_id, order_id, token_id, side, intent, quantity,
                price, fee, maker, timestamp, sequence_id
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                fill.id,
                run_id,
                fill.order_id,
                fill.token_id,
                fill.side,
                fill.intent,
                str(fill.quantity),
                str(fill.price),
                str(fill.fee),
                int(fill.maker),
                fill.timestamp,
                fill.sequence_id,
            ),
        )
        self._mark_dirty(force=True)

    def record_closed_trade(self, run_id: str, trade: ClosedTrade) -> None:
        self.connection.execute(
            """
            INSERT INTO closed_trades(
                trade_id, run_id, token_id, market_id, outcome, question, opened_at,
                closed_at, quantity, average_entry_price, average_exit_price,
                gross_pnl, fees, net_pnl, return_pct, exit_reason, entry_score, exit_score
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                trade.id,
                run_id,
                trade.token_id,
                trade.market_id,
                trade.outcome,
                trade.question,
                trade.opened_at,
                trade.closed_at,
                str(trade.quantity),
                str(trade.average_entry_price),
                str(trade.average_exit_price),
                str(trade.gross_pnl),
                str(trade.fees),
                str(trade.net_pnl),
                str(trade.return_pct),
                trade.exit_reason,
                trade.entry_score,
                trade.exit_score,
            ),
        )
        self._mark_dirty(force=True)

    def record_equity(
        self,
        run_id: str,
        timestamp: float,
        cash: Any,
        exposure: Any,
        mark_unrealized_pnl: Any,
        liquidation_unrealized_pnl: Any,
        realized_pnl: Any,
        mark_equity: Any,
        liquidation_equity: Any,
        open_positions: int,
    ) -> None:
        self.connection.execute(
            """
            INSERT INTO equity(
                run_id, timestamp, cash, exposure, mark_unrealized_pnl,
                liquidation_unrealized_pnl, realized_pnl, mark_equity,
                liquidation_equity, open_positions
            ) VALUES(?,?,?,?,?,?,?,?,?,?)
            """,
            (
                run_id,
                timestamp,
                str(cash),
                str(exposure),
                str(mark_unrealized_pnl),
                str(liquidation_unrealized_pnl),
                str(realized_pnl),
                str(mark_equity),
                str(liquidation_equity),
                open_positions,
            ),
        )
        self._mark_dirty()

    def record_exit_request(self, run_id: str, request: ExitRequest) -> None:
        self.connection.execute(
            """
            INSERT INTO exit_requests(
                run_id, token_id, reason, requested_at, exit_score,
                active_after_sequence, active_at, status, attempts,
                last_attempt_at, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(run_id, token_id) DO UPDATE SET
                reason=excluded.reason,
                exit_score=excluded.exit_score,
                active_after_sequence=excluded.active_after_sequence,
                active_at=excluded.active_at,
                status=excluded.status,
                attempts=excluded.attempts,
                last_attempt_at=excluded.last_attempt_at,
                updated_at=excluded.updated_at
            """,
            (
                run_id,
                request.token_id,
                request.reason,
                request.requested_at,
                request.exit_score,
                request.active_after_sequence,
                request.active_at,
                request.status,
                request.attempts,
                request.last_attempt_at,
                iso_now(),
            ),
        )
        self._mark_dirty(force=True)

    def record_signal_outcome(self, run_id: str, sample: SignalOutcome) -> None:
        self.connection.execute(
            """
            INSERT INTO signal_outcomes(
                outcome_id, run_id, token_id, market_id, outcome, question,
                created_at, score, entry_ask, initial_bid, target_price, stop_price,
                calibration_style, entry_fee_per_share, entry_cost_per_share,
                tradeable_at_entry, untradeable_reason, first_barrier, barrier_at,
                max_bid, min_bid, horizon_returns_json, completed, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(outcome_id) DO UPDATE SET
                calibration_style=excluded.calibration_style,
                entry_fee_per_share=excluded.entry_fee_per_share,
                entry_cost_per_share=excluded.entry_cost_per_share,
                tradeable_at_entry=excluded.tradeable_at_entry,
                untradeable_reason=excluded.untradeable_reason,
                first_barrier=excluded.first_barrier,
                barrier_at=excluded.barrier_at,
                max_bid=excluded.max_bid,
                min_bid=excluded.min_bid,
                horizon_returns_json=excluded.horizon_returns_json,
                completed=excluded.completed,
                updated_at=excluded.updated_at
            """,
            (
                sample.id,
                run_id,
                sample.token_id,
                sample.market_id,
                sample.outcome,
                sample.question,
                sample.created_at,
                sample.score,
                str(sample.entry_ask),
                str(sample.initial_bid),
                str(sample.target_price),
                str(sample.stop_price),
                sample.calibration_style,
                str(sample.entry_fee_per_share),
                str(sample.entry_cost_per_share),
                int(sample.tradeable_at_entry),
                sample.untradeable_reason,
                sample.first_barrier,
                sample.barrier_at,
                str(sample.max_bid),
                str(sample.min_bid),
                json_dumps(sample.horizon_returns),
                int(sample.completed),
                iso_now(),
            ),
        )
        self._mark_dirty()

    def record_missed_move(self, run_id: str, missed: MissedMove) -> None:
        self.connection.execute(
            """
            INSERT INTO missed_moves(
                missed_id, run_id, token_id, market_id, outcome, question,
                order_id, cancelled_at, entry_price, target_price, score,
                expires_at, hit_at, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(missed_id) DO UPDATE SET
                hit_at=excluded.hit_at,
                updated_at=excluded.updated_at
            """,
            (
                missed.id,
                run_id,
                missed.token_id,
                missed.market_id,
                missed.outcome,
                missed.question,
                missed.order_id,
                missed.cancelled_at,
                str(missed.entry_price),
                str(missed.target_price),
                missed.score,
                missed.expires_at,
                missed.hit_at,
                iso_now(),
            ),
        )
        self._mark_dirty(force=missed.hit_at is not None)

    def record_runtime_metrics(self, run_id: str, metrics: RuntimeMetrics) -> None:
        self.connection.execute(
            """
            INSERT INTO runtime_metrics(
                run_id, timestamp, queue_depth, event_processing_lag_seconds,
                max_event_processing_lag_seconds, duplicate_trades, received_events,
                processed_events, max_score_seen, eligible_signals, entry_attempts,
                entry_orders, maker_entry_orders, taker_entry_orders,
                filled_entry_orders, cancelled_entry_orders, pending_exits,
                missed_moves, average_queue_ahead, pending_entry_refreshes,
                refresh_requests, refresh_successes, refresh_failures,
                refresh_timeouts, refresh_coalesced, average_refresh_latency_ms,
                max_refresh_latency_ms, entry_rejections_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                run_id,
                metrics.timestamp,
                metrics.queue_depth,
                metrics.event_processing_lag_seconds,
                metrics.max_event_processing_lag_seconds,
                metrics.duplicate_trades,
                metrics.received_events,
                metrics.processed_events,
                metrics.max_score_seen,
                metrics.eligible_signals,
                metrics.entry_attempts,
                metrics.entry_orders,
                metrics.maker_entry_orders,
                metrics.taker_entry_orders,
                metrics.filled_entry_orders,
                metrics.cancelled_entry_orders,
                metrics.pending_exits,
                metrics.missed_moves,
                metrics.average_queue_ahead,
                metrics.pending_entry_refreshes,
                metrics.refresh_requests,
                metrics.refresh_successes,
                metrics.refresh_failures,
                metrics.refresh_timeouts,
                metrics.refresh_coalesced,
                metrics.average_refresh_latency_ms,
                metrics.max_refresh_latency_ms,
                json_dumps(metrics.entry_rejections),
            ),
        )
        self._mark_dirty()

    def latest_run_id(self, *, running_only: bool = False) -> str | None:
        query = "SELECT run_id FROM runs"
        if running_only:
            query += " WHERE status='RUNNING'"
        query += " ORDER BY started_at DESC LIMIT 1"
        row = self.connection.execute(query).fetchone()
        return str(row[0]) if row else None

    def fetch_all(self, query: str, parameters: tuple[Any, ...] = ()) -> list[sqlite3.Row]:
        return list(self.connection.execute(query, parameters).fetchall())

    def close(self) -> None:
        self.connection.commit()
        self.connection.close()

    def _mark_dirty(self, *, force: bool = False) -> None:
        self._dirty += 1
        if force or self._dirty >= 50:
            self.connection.commit()
            self._dirty = 0


def write_csv(path: Path, rows: list[sqlite3.Row]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        if not rows:
            handle.write("")
            return
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        for row in rows:
            writer.writerow(dict(row))
