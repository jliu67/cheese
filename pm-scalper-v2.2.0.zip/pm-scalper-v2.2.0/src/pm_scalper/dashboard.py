from __future__ import annotations

from decimal import Decimal
from typing import Mapping

from rich.console import Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .models import Asset, RuntimeMetrics, SignalSnapshot
from .paper import PaperBroker
from .util import fmt_money


class Dashboard:
    def __init__(self, assets: Mapping[str, Asset]) -> None:
        self.assets = dict(assets)

    def render(
        self,
        broker: PaperBroker,
        signals: Mapping[str, SignalSnapshot],
        run_id: str,
        raw_path: str,
        runtime: RuntimeMetrics,
    ) -> Group:
        header = Table.grid(expand=True)
        header.add_column()
        header.add_column(justify="right")
        status = "HALTED: " + broker.halt_reason if broker.halted else "PAPER MODE"
        header.add_row(
            Text(f"PM-SCALPER 2.2  |  run {run_id}", style="bold"),
            Text(status, style="bold red" if broker.halted else "bold green"),
        )
        header.add_row(
            f"Liquidation equity {fmt_money(broker.liquidation_equity)}   "
            f"Mark equity {fmt_money(broker.mark_equity)}   Cash {fmt_money(broker.cash)}",
            f"Exposure {fmt_money(broker.exposure)}   Reserved {fmt_money(broker.reserved_cash)}",
        )
        header.add_row(
            f"Realized {fmt_money(broker.realized_pnl)}   "
            f"Liquidation U/P&L {fmt_money(broker.liquidation_unrealized_pnl)}   "
            f"Mark U/P&L {fmt_money(broker.mark_unrealized_pnl)}",
            f"Closed {broker.closed_trades}   Win rate {broker.win_rate * 100:.1f}%   "
            f"Fees {fmt_money(broker.total_fees)}",
        )
        header.add_row(
            f"Max score {runtime.max_score_seen:.2f}   Eligible samples {runtime.eligible_signals:,}   "
            f"Entry orders {runtime.entry_orders}   Filled {runtime.filled_entry_orders}   "
            f"Cancelled {runtime.cancelled_entry_orders}",
            f"Maker/Taker {runtime.maker_entry_orders}/{runtime.taker_entry_orders}   "
            f"Pending exits {runtime.pending_exits}   Missed moves {runtime.missed_moves}",
        )
        lag_style = "red" if runtime.event_processing_lag_seconds > 2 else "green"
        header.add_row(
            f"Queue {runtime.queue_depth:,}   Processed {runtime.processed_events:,}/"
            f"{runtime.received_events:,}   Duplicate trades {runtime.duplicate_trades:,}",
            Text(
                f"Lag {runtime.event_processing_lag_seconds:.3f}s  "
                f"Max {runtime.max_event_processing_lag_seconds:.3f}s",
                style=lag_style,
            ),
        )
        top_rejection = (
            max(runtime.entry_rejections.items(), key=lambda item: item[1])
            if runtime.entry_rejections
            else None
        )
        header.add_row(
            f"Raw feed: {raw_path}",
            "Risk uses executable liquidation depth"
            if top_rejection is None
            else f"Top entry block: {top_rejection[0]} ({top_rejection[1]})",
        )

        opportunities = Table(title="Top short-horizon signals", expand=True)
        opportunities.add_column("Score", justify="right", width=7)
        opportunities.add_column("Outcome", width=8)
        opportunities.add_column("Bid / Ask", justify="right", width=14)
        opportunities.add_column("Spread", justify="right", width=8)
        opportunities.add_column("Flow", justify="right", width=8)
        opportunities.add_column("Sell60", justify="right", width=9)
        opportunities.add_column("State", width=11)
        opportunities.add_column("Market")
        ranked = sorted(signals.values(), key=lambda item: item.score, reverse=True)[:10]
        for signal in ranked:
            asset = self.assets.get(signal.token_id)
            if asset is None:
                continue
            features = signal.features
            score_style = (
                "green"
                if signal.eligible
                else "yellow"
                if signal.score >= 60
                else "white"
            )
            opportunities.add_row(
                Text(f"{signal.score:5.1f}", style=score_style),
                asset.outcome,
                f"{features.best_bid:.4f} / {features.best_ask:.4f}",
                f"{features.spread:.4f}",
                f"{features.trade_flow:+.2f}",
                f"{features.sell_volume_60s_shares:,.0f}",
                "ELIGIBLE" if signal.eligible else signal.reason[:10],
                asset.question[:70],
            )
        if not ranked:
            opportunities.add_row("—", "—", "—", "—", "—", "—", "—", "Waiting for books")

        positions = Table(title="Positions and working orders", expand=True)
        positions.add_column("Type", width=11)
        positions.add_column("Style", width=7)
        positions.add_column("Outcome", width=8)
        positions.add_column("Entry / Limit", justify="right", width=14)
        positions.add_column("Bid / Target", justify="right", width=14)
        positions.add_column("Qty", justify="right", width=11)
        positions.add_column("Liq P&L", justify="right", width=11)
        positions.add_column("Queue", justify="right", width=11)
        positions.add_column("Market")

        for token_id, position in broker.positions.items():
            asset = self.assets[token_id]
            book = broker.books.get(token_id)
            bid = book.best_bid if book and book.best_bid is not None else Decimal("0")
            proceeds, _ = broker.liquidation_quote(
                token_id, position.quantity, __import__("time").time()
            )
            pnl = proceeds - position.entry_cost - position.entry_fees
            state = "EXIT WAIT" if token_id in broker.exit_requests else "POSITION"
            positions.add_row(
                state,
                "—",
                position.outcome,
                f"{position.average_entry_price:.4f}",
                f"{bid:.4f} / {position.target_price:.4f}",
                f"{position.quantity:.2f}",
                f"{pnl:+.2f}",
                "—",
                asset.question[:62],
            )

        for order in broker.orders.values():
            if order.status not in {"OPEN", "PARTIAL", "PENDING"}:
                continue
            asset = self.assets[order.token_id]
            queue_text = f"{order.queue_ahead:,.0f}"
            if order.estimated_queue_seconds is not None:
                queue_text += f"/{order.estimated_queue_seconds:.0f}s"
            positions.add_row(
                order.intent,
                order.execution_style,
                order.outcome,
                f"{order.limit_price:.4f}",
                "—",
                f"{order.remaining_quantity:.2f}",
                "—",
                queue_text,
                asset.question[:62],
            )
        if not broker.positions and not any(
            order.status in {"OPEN", "PARTIAL", "PENDING"}
            for order in broker.orders.values()
        ):
            positions.add_row("—", "—", "—", "—", "—", "—", "—", "—", "No trades yet")

        return Group(Panel(header, title="Session"), opportunities, positions)
