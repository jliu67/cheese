from __future__ import annotations

import logging
import math
import uuid
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from typing import Callable, Mapping

from .book import BookStore, OrderBook
from .config import AppConfig
from .models import (
    Asset,
    ClosedTrade,
    EntryAttempt,
    ExitRequest,
    Fill,
    MissedMove,
    PaperOrder,
    Position,
    RuntimeMetrics,
    SignalSnapshot,
    TradePrint,
)
from .shadow import ShadowBookStore
from .storage import SQLiteStore
from .util import ONE, ZERO, ceil_to_tick, floor_to_tick

LOGGER = logging.getLogger(__name__)


@dataclass(slots=True)
class ExitAccumulator:
    token_id: str
    market_id: str
    outcome: str
    question: str
    opened_at: float
    average_entry_price: Decimal
    entry_score: float
    quantity: Decimal = ZERO
    exit_notional: Decimal = ZERO
    entry_cost: Decimal = ZERO
    entry_fees: Decimal = ZERO
    exit_fees: Decimal = ZERO
    exit_reason: str = "unknown"
    exit_score: float = 50.0


@dataclass(slots=True)
class PendingEntryRefresh:
    attempt: EntryAttempt
    asset: Asset
    request_id: str


@dataclass(slots=True)
class TakerEntryPlan:
    """A fully executable, fee-aware, impact-safe taker entry preview."""

    quantity: Decimal
    entry_fills: list[tuple[Decimal, Decimal]]
    entry_vwap: Decimal
    entry_notional: Decimal
    entry_fee: Decimal
    max_fill_price: Decimal
    target_price: Decimal
    expected_target_return: Decimal
    exit_fills: list[tuple[Decimal, Decimal]]
    exit_vwap: Decimal
    exit_proceeds: Decimal
    exit_fee: Decimal
    liquidation_fraction: Decimal
    immediate_round_trip_return: Decimal
    entry_slippage_pct: Decimal

    @property
    def total_entry_cost(self) -> Decimal:
        return self.entry_notional + self.entry_fee


RefreshRequester = Callable[[str, str, float, str | None], str | None]


class PaperBroker:
    """Causality-safe, depth-aware live paper broker.

    Maker fills require a qualifying *later-received* trade print after simulated
    placement latency. Taker entries/exits require a later authoritative depth
    observation and consume a counterfactual shadow book that cannot reuse paper-
    consumed liquidity until the public book demonstrates replenishment.
    """

    def __init__(
        self,
        config: AppConfig,
        assets: Mapping[str, Asset],
        books: BookStore,
        store: SQLiteStore,
        run_id: str,
        sequence_watermark: Callable[[], int] | None = None,
        refresh_requester: RefreshRequester | None = None,
    ) -> None:
        self.config = config
        self.assets = dict(assets)
        self.books = books
        self.store = store
        self.run_id = run_id
        self._sequence_watermark = sequence_watermark or (lambda: 0)
        self._refresh_requester = refresh_requester

        self.shadow = ShadowBookStore()
        for book in books.books.values():
            self.shadow.sync(book)

        self.starting_cash = Decimal(str(config.risk.starting_cash_usdc))
        self.cash = self.starting_cash
        self.orders: dict[str, PaperOrder] = {}
        self.positions: dict[str, Position] = {}
        self.exit_requests: dict[str, ExitRequest] = {}
        self.exit_accumulators: dict[str, ExitAccumulator] = {}
        self.missed_move_watches: dict[str, MissedMove] = {}
        self.pending_entry_refreshes: dict[str, PendingEntryRefresh] = {}
        self.entry_attempt_records: dict[str, EntryAttempt] = {}
        self._last_refresh_requested_at: dict[tuple[str, str, str | None], float] = {}
        self._active_refresh_keys: dict[tuple[str, str, str | None], str] = {}
        self.cooldown_until: dict[str, float] = {}
        self.market_loss_cooldown_until: dict[str, float] = {}
        self.market_loss_counts: Counter[str] = Counter()
        self.markets_locked_for_day: set[str] = set()
        self.realized_pnl = ZERO
        self.total_fees = ZERO
        self.entries_today = 0
        self.risk_day: str | None = None
        self.day_start_equity = self.starting_cash
        self.closed_trades = 0
        self.wins = 0
        self.losses = 0
        self.consecutive_losses = 0
        self.halted = False
        self.halt_reason = ""
        self.resolved_tokens: set[str] = set()

        # Diagnostics.
        self.max_score_seen = 0.0
        self.eligible_signals = 0
        self.entry_attempts = 0
        self.entry_orders = 0
        self.maker_entry_orders = 0
        self.taker_entry_orders = 0
        self.filled_entry_orders = 0
        self.cancelled_entry_orders = 0
        self.missed_moves = 0
        self._queue_samples: list[float] = []
        self._counted_filled_entries: set[str] = set()
        self.entry_rejection_counts: Counter[str] = Counter()
        self.refresh_requests = 0
        self.refresh_successes = 0
        self.refresh_failures = 0
        self.refresh_timeouts = 0
        self.refresh_coalesced = 0
        self._refresh_latency_samples: list[float] = []

    def _watermark(self) -> int:
        return int(self._sequence_watermark())

    @property
    def reserved_cash(self) -> Decimal:
        return sum((order.reserved_notional for order in self.orders.values()), ZERO)

    @property
    def available_cash(self) -> Decimal:
        return max(ZERO, self.cash - self.reserved_cash)

    @property
    def exposure(self) -> Decimal:
        position_cost = sum((position.entry_cost for position in self.positions.values()), ZERO)
        return position_cost + self.reserved_cash

    @property
    def mark_unrealized_pnl(self) -> Decimal:
        total = ZERO
        for token_id, position in self.positions.items():
            book = self.books.get(token_id)
            bid = book.best_bid if book else None
            if bid is None:
                continue
            total += position.quantity * bid - position.entry_cost - position.entry_fees
        return total

    @property
    def mark_equity(self) -> Decimal:
        marked = self.cash
        for token_id, position in self.positions.items():
            book = self.books.get(token_id)
            bid = book.best_bid if book else None
            if bid is not None:
                marked += position.quantity * bid
        return marked

    @property
    def liquidation_unrealized_pnl(self) -> Decimal:
        total = ZERO
        now = datetime.now(tz=timezone.utc).timestamp()
        for token_id, position in self.positions.items():
            proceeds, _ = self._liquidation_proceeds(token_id, position.quantity, now)
            total += proceeds - position.entry_cost - position.entry_fees
        return total

    @property
    def liquidation_equity(self) -> Decimal:
        now = datetime.now(tz=timezone.utc).timestamp()
        return self._liquidation_equity_at(now)

    def _liquidation_equity_at(self, timestamp: float) -> Decimal:
        value = self.cash
        for token_id, position in self.positions.items():
            proceeds, _ = self._liquidation_proceeds(
                token_id, position.quantity, timestamp
            )
            value += proceeds
        return value

    # Backward-friendly aliases used by old dashboard/report integrations.
    @property
    def unrealized_pnl(self) -> Decimal:
        return self.liquidation_unrealized_pnl

    @property
    def equity(self) -> Decimal:
        return self.liquidation_equity

    @property
    def win_rate(self) -> float:
        return self.wins / self.closed_trades if self.closed_trades else 0.0

    @property
    def average_queue_ahead(self) -> float:
        return sum(self._queue_samples) / len(self._queue_samples) if self._queue_samples else 0.0

    @property
    def has_pending_entry_refresh(self) -> bool:
        return bool(self.pending_entry_refreshes)

    def observe_signals(self, signals: Mapping[str, SignalSnapshot]) -> None:
        if not signals:
            return
        self.max_score_seen = max(
            self.max_score_seen, max(signal.score for signal in signals.values())
        )
        self.eligible_signals += sum(1 for signal in signals.values() if signal.eligible)

    def runtime_metrics(
        self,
        timestamp: float,
        *,
        queue_depth: int,
        event_processing_lag_seconds: float,
        max_event_processing_lag_seconds: float,
        duplicate_trades: int,
        received_events: int,
        processed_events: int,
    ) -> RuntimeMetrics:
        return RuntimeMetrics(
            timestamp=timestamp,
            queue_depth=queue_depth,
            event_processing_lag_seconds=event_processing_lag_seconds,
            max_event_processing_lag_seconds=max_event_processing_lag_seconds,
            duplicate_trades=duplicate_trades,
            received_events=received_events,
            processed_events=processed_events,
            max_score_seen=self.max_score_seen,
            eligible_signals=self.eligible_signals,
            entry_attempts=self.entry_attempts,
            entry_orders=self.entry_orders,
            maker_entry_orders=self.maker_entry_orders,
            taker_entry_orders=self.taker_entry_orders,
            filled_entry_orders=self.filled_entry_orders,
            cancelled_entry_orders=self.cancelled_entry_orders,
            pending_exits=len(self.exit_requests),
            missed_moves=self.missed_moves,
            average_queue_ahead=self.average_queue_ahead,
            pending_entry_refreshes=len(self.pending_entry_refreshes),
            refresh_requests=self.refresh_requests,
            refresh_successes=self.refresh_successes,
            refresh_failures=self.refresh_failures,
            refresh_timeouts=self.refresh_timeouts,
            refresh_coalesced=self.refresh_coalesced,
            average_refresh_latency_ms=(
                sum(self._refresh_latency_samples) / len(self._refresh_latency_samples)
                if self._refresh_latency_samples
                else 0.0
            ),
            max_refresh_latency_ms=max(self._refresh_latency_samples, default=0.0),
            entry_rejections=dict(self.entry_rejection_counts),
        )

    def _record_attempt(self, attempt: EntryAttempt, *, force: bool = False) -> None:
        self.entry_attempt_records[attempt.id] = attempt
        recorder = getattr(self.store, "record_entry_attempt", None)
        if recorder is not None:
            recorder(self.run_id, attempt, force=force)

    @staticmethod
    def _age_ms(observed_at: float, timestamp: float) -> float | None:
        return None if observed_at <= 0 else max(0.0, (timestamp - observed_at) * 1000.0)

    def _update_attempt_book(
        self, attempt: EntryAttempt, book: OrderBook, timestamp: float
    ) -> None:
        attempt.updated_at = timestamp
        attempt.bid = book.best_bid
        attempt.ask = book.best_ask
        attempt.spread = book.spread
        attempt.quoted_bid = book.quoted_best_bid
        attempt.quoted_ask = book.quoted_best_ask
        bid_age = book.top_age_seconds("BUY", timestamp)
        ask_age = book.top_age_seconds("SELL", timestamp)
        quote_age = book.quote_age_seconds(timestamp)
        depth_age = book.full_depth_age_seconds(timestamp)
        attempt.bid_top_age_ms = None if bid_age is None else bid_age * 1000.0
        attempt.ask_top_age_ms = None if ask_age is None else ask_age * 1000.0
        attempt.quote_age_ms = None if quote_age is None else quote_age * 1000.0
        attempt.full_depth_age_ms = None if depth_age is None else depth_age * 1000.0

    def _new_entry_attempt(
        self, asset: Asset, book: OrderBook, score: float, timestamp: float
    ) -> EntryAttempt:
        attempt = EntryAttempt(
            id=uuid.uuid4().hex,
            token_id=asset.token_id,
            market_id=asset.market_id,
            outcome=asset.outcome,
            question=asset.question,
            created_at=timestamp,
            updated_at=timestamp,
            initial_score=score,
        )
        self._update_attempt_book(attempt, book, timestamp)
        self._record_attempt(attempt)
        return attempt

    def _finish_attempt(
        self, attempt: EntryAttempt | None, decision: str, reason: str, timestamp: float
    ) -> None:
        if attempt is None:
            return
        attempt.decision = decision
        attempt.reason = reason
        attempt.updated_at = timestamp
        self._record_attempt(attempt, force=True)
        LOGGER.info(
            "ENTRY ATTEMPT token=%s score=%.2f refreshed_score=%s decision=%s "
            "style=%s refresh=%s reason=%s",
            attempt.token_id,
            attempt.initial_score,
            "—" if attempt.score_after_refresh is None else f"{attempt.score_after_refresh:.2f}",
            decision,
            attempt.execution_style or "—",
            attempt.refresh_success,
            reason,
        )

    def _reject_entry(
        self, reason: str, attempt: EntryAttempt | None = None, timestamp: float | None = None
    ) -> PaperOrder | None:
        self.entry_rejection_counts[reason] += 1
        if attempt is not None:
            self._finish_attempt(
                attempt, "BLOCKED", reason, attempt.updated_at if timestamp is None else timestamp
            )
        return None

    def _schedule_refresh(
        self,
        token_id: str,
        purpose: str,
        not_before: float,
        related_id: str | None = None,
    ) -> str | None:
        if self._refresh_requester is None:
            return None
        key = (token_id, purpose, related_id)
        existing = self._active_refresh_keys.get(key)
        if existing is not None:
            self.refresh_coalesced += 1
            return existing
        request_id = self._refresh_requester(token_id, purpose, not_before, related_id)
        if request_id is None:
            return None
        self._active_refresh_keys[key] = request_id
        self._last_refresh_requested_at[key] = not_before
        self.refresh_requests += 1
        LOGGER.info(
            "TARGETED BOOK REFRESH requested token=%s purpose=%s related_id=%s "
            "request_id=%s not_before=%.6f",
            token_id,
            purpose,
            related_id or "—",
            request_id,
            not_before,
        )
        return request_id

    def _clear_refresh_request(
        self, token_id: str, purpose: str, related_id: str | None, request_id: str
    ) -> None:
        key = (token_id, purpose, related_id)
        if self._active_refresh_keys.get(key) == request_id:
            self._active_refresh_keys.pop(key, None)

    def _entry_book_is_fresh(self, book: OrderBook, timestamp: float) -> bool:
        # A fresh quote timestamp alone is not enough: the quote hint must still
        # agree with the executable depth ladder used for sizing/pricing.
        quotes_match_depth = (
            book.best_bid is not None
            and book.best_ask is not None
            and book.quoted_best_bid == book.best_bid
            and book.quoted_best_ask == book.best_ask
        )
        return (
            book.full_depth_is_fresh(
                timestamp, self.config.strategy.depth_stale_seconds
            )
            and book.quotes_are_fresh(
                timestamp, self.config.strategy.top_book_stale_seconds
            )
            and quotes_match_depth
            and book.top_is_fresh(
                "BUY", timestamp, self.config.strategy.stale_book_seconds
            )
            and book.top_is_fresh(
                "SELL", timestamp, self.config.strategy.stale_book_seconds
            )
        )

    def can_enter(self, asset: Asset, book: OrderBook, timestamp: float) -> tuple[bool, str]:
        self._roll_risk_day(timestamp)
        if self.halted:
            return False, self.halt_reason or "risk halt"
        if asset.token_id in self.resolved_tokens:
            return False, "market resolved"
        if asset.token_id in self.positions:
            return False, "position already open"
        if asset.token_id in self.exit_requests:
            return False, "exit pending"
        if self._has_open_order(asset.token_id, intent="ENTRY"):
            return False, "entry already pending"
        if asset.market_id in self.markets_locked_for_day:
            return False, "market disabled after repeated losses"
        if self.market_loss_cooldown_until.get(asset.market_id, 0.0) > timestamp:
            return False, "market loss cooldown"
        if self.cooldown_until.get(asset.token_id, 0.0) > timestamp:
            return False, "cooldown"
        if asset.end_date is not None:
            end_buffer = self.config.universe.min_hours_to_end * 3600.0
            if asset.end_date.timestamp() - timestamp < end_buffer:
                return False, "market too close to resolution"
        if self.entries_today >= self.config.risk.max_trades_per_day:
            return False, "maximum entries reached"
        active_slots = (
            len(self.positions)
            + len(self.pending_entry_refreshes)
            + sum(
                1
                for order in self.orders.values()
                if order.intent == "ENTRY"
                and order.status in {"OPEN", "PARTIAL", "PENDING"}
            )
        )
        if active_slots >= self.config.risk.max_open_positions:
            return False, "maximum open positions reached"
        if any(
            position.market_id == asset.market_id for position in self.positions.values()
        ) or any(
            order.market_id == asset.market_id
            and order.status in {"OPEN", "PARTIAL", "PENDING"}
            for order in self.orders.values()
        ) or any(
            pending.asset.market_id == asset.market_id
            for pending in self.pending_entry_refreshes.values()
        ):
            return False, "another outcome from this market is active"
        if book.best_bid is None or book.best_ask is None or book.best_ask <= book.best_bid:
            return False, "invalid order book"
        if self.available_cash <= Decimal(str(self.config.risk.cash_buffer_usdc)):
            return False, "no available cash above buffer"
        max_exposure = self._liquidation_equity_at(timestamp) * Decimal(
            str(self.config.risk.max_total_exposure_pct_equity)
        )
        if self.exposure >= max_exposure:
            return False, "maximum total exposure reached"
        return True, "ok"

    def place_entry(
        self,
        asset: Asset,
        book: OrderBook,
        signal: SignalSnapshot | float,
        timestamp: float,
    ) -> PaperOrder | None:
        if asset.token_id in self.pending_entry_refreshes:
            self.refresh_coalesced += 1
            return None
        if isinstance(signal, SignalSnapshot):
            score = signal.score
        else:
            score = float(signal)
        self.entry_attempts += 1
        attempt = self._new_entry_attempt(asset, book, score, timestamp)

        allowed, reason = self.can_enter(asset, book, timestamp)
        if not allowed:
            return self._reject_entry(reason, attempt, timestamp)

        if not self._entry_book_is_fresh(book, timestamp):
            attempt.refresh_required = True
            attempt.refresh_attempted = True
            attempt.refresh_started_at = timestamp
            request_id = self._schedule_refresh(
                asset.token_id, "ENTRY_DECISION", timestamp, attempt.id
            )
            if request_id is None:
                return self._reject_entry(
                    "stale execution depth and refresh unavailable", attempt, timestamp
                )
            attempt.refresh_request_id = request_id
            attempt.decision = "REFRESH_REQUESTED"
            attempt.reason = "stale execution depth; targeted refresh requested"
            self.pending_entry_refreshes[asset.token_id] = PendingEntryRefresh(
                attempt=attempt, asset=asset, request_id=request_id
            )
            self._record_attempt(attempt, force=True)
            return None

        return self._execute_entry_attempt(asset, book, signal, timestamp, attempt)

    def on_refresh_result(
        self,
        *,
        token_id: str,
        purpose: str,
        request_id: str,
        related_id: str | None,
        success: bool,
        timestamp: float,
        latency_ms: float | None = None,
        reason: str | None = None,
        timed_out: bool = False,
        book: OrderBook | None = None,
        signal: SignalSnapshot | None = None,
    ) -> PaperOrder | None:
        self._clear_refresh_request(token_id, purpose, related_id, request_id)
        if success:
            self.refresh_successes += 1
        else:
            self.refresh_failures += 1
            if timed_out:
                self.refresh_timeouts += 1
        if latency_ms is not None:
            self._refresh_latency_samples.append(max(0.0, latency_ms))
        LOGGER.info(
            "TARGETED BOOK REFRESH result token=%s purpose=%s request_id=%s "
            "success=%s timeout=%s latency_ms=%s reason=%s",
            token_id,
            purpose,
            request_id,
            success,
            timed_out,
            "—" if latency_ms is None else f"{latency_ms:.1f}",
            reason or "—",
        )

        if purpose != "ENTRY_DECISION":
            return None
        pending = self.pending_entry_refreshes.get(token_id)
        if pending is None or pending.request_id != request_id:
            return None
        self.pending_entry_refreshes.pop(token_id, None)
        attempt = pending.attempt
        attempt.refresh_completed_at = timestamp
        attempt.refresh_latency_ms = latency_ms
        attempt.refresh_success = success
        attempt.score_after_refresh = signal.score if signal is not None else None
        if book is not None:
            self._update_attempt_book(attempt, book, timestamp)

        if not success or book is None:
            return self._reject_entry(
                reason or "targeted book refresh failed", attempt, timestamp
            )
        # Keep the counterfactual executable-depth view aligned even when callers
        # deliver a targeted refresh directly instead of through on_book_update().
        self.shadow.sync(book)
        if signal is None or not signal.eligible or signal.score < self.config.strategy.entry_score:
            return self._reject_entry(
                "signal faded before refreshed execution decision", attempt, timestamp
            )
        if not self._entry_book_is_fresh(book, timestamp):
            return self._reject_entry(
                "targeted refresh did not certify fresh execution depth", attempt, timestamp
            )
        return self._execute_entry_attempt(
            pending.asset, book, signal, timestamp, attempt
        )

    def _execute_entry_attempt(
        self,
        asset: Asset,
        book: OrderBook,
        signal: SignalSnapshot | float,
        timestamp: float,
        attempt: EntryAttempt,
    ) -> PaperOrder | None:
        if isinstance(signal, SignalSnapshot):
            score = signal.score
            features = signal.features
        else:
            score = float(signal)
            features = None
        attempt.score_after_refresh = (
            score if attempt.refresh_attempted else attempt.score_after_refresh
        )
        self._update_attempt_book(attempt, book, timestamp)
        allowed, reason = self.can_enter(asset, book, timestamp)
        if not allowed:
            return self._reject_entry(reason, attempt, timestamp)
        bid, ask = book.best_bid, book.best_ask
        if bid is None or ask is None:
            return self._reject_entry("missing top of book", attempt, timestamp)

        # Strong signals may use a taker entry, but only after V2.2 proves that the
        # size can be entered and immediately liquidated within strict impact limits.
        # If the taker route is unsafe, fall back to the queue-aware maker route
        # rather than discarding an otherwise valid signal.
        taker_candidate = (
            self.config.execution.entry_style == "hybrid"
            and score >= self.config.execution.taker_entry_score
            and self._taker_spread_ok(book)
        )
        if taker_candidate:
            desired_notional = self._entry_notional(book, ask, "TAKER", timestamp)
            attempt.requested_notional = desired_notional
            if desired_notional > ZERO:
                desired_quantity = self._quantize_quantity(desired_notional / ask)
                plan, taker_reason = self._find_safe_taker_plan(
                    asset,
                    book,
                    desired_quantity,
                    timestamp,
                )
                if plan is not None:
                    self._apply_taker_plan_to_attempt(attempt, plan)
                    return self._create_taker_entry(
                        asset,
                        plan.max_fill_price,
                        plan.quantity,
                        score,
                        timestamp,
                        plan.expected_target_return,
                        attempt=attempt,
                    )
                attempt.taker_rejection_reason = taker_reason
            else:
                attempt.taker_rejection_reason = "position size capped to zero"

        attempt.execution_style = "MAKER"
        maker_price = self._maker_entry_price(book, score)
        attempt.maker_price = maker_price
        notional = self._entry_notional(book, maker_price, "MAKER", timestamp)
        if attempt.requested_notional is None:
            attempt.requested_notional = notional
        if notional <= ZERO:
            reason = "position size capped to zero"
            if attempt.taker_rejection_reason:
                reason = f"taker unsafe: {attempt.taker_rejection_reason}; {reason}"
            return self._reject_entry(reason, attempt, timestamp)
        quantity = self._quantize_quantity(notional / maker_price)
        if quantity < book.min_order_size:
            reason = "entry below minimum share size"
            if attempt.taker_rejection_reason:
                reason = f"taker unsafe: {attempt.taker_rejection_reason}; {reason}"
            return self._reject_entry(reason, attempt, timestamp)

        maker_price, queue_ahead, queue_seconds, queue_ok = self._queue_aware_price(
            book, quantity, score, features
        )
        attempt.maker_price = maker_price
        attempt.safe_notional = maker_price * quantity
        if not queue_ok:
            reason = "maker queue too deep or slow"
            if attempt.taker_rejection_reason:
                reason = f"taker unsafe: {attempt.taker_rejection_reason}; {reason}"
            return self._reject_entry(reason, attempt, timestamp)
        return self._create_maker_entry(
            asset,
            maker_price,
            quantity,
            queue_ahead,
            queue_seconds,
            score,
            timestamp,
            attempt=attempt,
        )

    def on_trade(self, trade: TradePrint) -> None:
        candidates = [
            order
            for order in self.orders.values()
            if order.token_id == trade.token_id
            and order.execution_style == "MAKER"
            and order.status in {"OPEN", "PARTIAL"}
        ]
        remaining_trade = trade.size
        for order in sorted(candidates, key=lambda item: (item.created_at, item.id)):
            if remaining_trade <= ZERO:
                break
            if trade.sequence_id <= order.active_after_sequence:
                continue
            if trade.received_at < order.active_at:
                continue
            if (
                trade.timestamp
                + self.config.execution.max_exchange_clock_skew_seconds
                < order.created_at
            ):
                continue
            if order.side == "BUY":
                eligible = trade.side == "SELL" and trade.price <= order.limit_price
            else:
                eligible = trade.side == "BUY" and trade.price >= order.limit_price
            if not eligible:
                continue

            if trade.price == order.limit_price and order.queue_ahead > ZERO:
                consumed_queue = min(order.queue_ahead, remaining_trade)
                order.queue_ahead -= consumed_queue
                remaining_trade -= consumed_queue
                self.store.record_order(self.run_id, order)
            elif trade.price != order.limit_price:
                order.queue_ahead = ZERO

            fill_quantity = min(order.remaining_quantity, remaining_trade)
            if fill_quantity <= ZERO:
                continue
            remaining_trade -= fill_quantity
            self._apply_fill(
                order,
                fill_quantity,
                order.limit_price,
                maker=True,
                timestamp=trade.received_at or trade.timestamp,
                sequence_id=trade.sequence_id,
                exit_reason="profit target" if order.intent == "TARGET" else "entry",
            )

    def on_book_update(self, book: OrderBook, timestamp: float) -> None:
        self.shadow.sync(book)
        self._process_missed_moves(book, timestamp)
        self._process_pending_taker_entry(book, timestamp)
        self._process_exit_request(book, timestamp)

    def manage(self, timestamp: float, signals: Mapping[str, SignalSnapshot]) -> None:
        self._roll_risk_day(timestamp)
        self._expire_entry_orders(timestamp)
        self._manage_entry_orders(timestamp, signals)

        for token_id in list(self.positions):
            position = self.positions.get(token_id)
            if position is None:
                continue
            book = self.books.get(token_id)
            if book is None:
                continue
            signal = signals.get(token_id)
            if signal is not None:
                position.last_score = signal.score
            if book.best_bid is not None:
                position.peak_bid = max(position.peak_bid, book.best_bid)

            if token_id not in self.exit_requests and not self._has_open_order(
                token_id, intent="ENTRY"
            ):
                self._ensure_target_order(position, book, timestamp)

            asset = self.assets.get(token_id)
            if asset is not None and asset.end_date is not None:
                end_buffer = self.config.universe.min_hours_to_end * 3600.0
                if asset.end_date.timestamp() - timestamp < end_buffer:
                    self.request_exit(
                        token_id, "market nearing resolution", timestamp, position.last_score
                    )
                    continue

            age = timestamp - position.opened_at
            liquidation_return, liquidation_fraction = (
                self._position_liquidation_snapshot(position, timestamp)
            )
            if (
                liquidation_fraction
                >= Decimal(
                    str(self.config.execution.min_immediate_liquidation_fraction)
                )
                and liquidation_return
                <= -Decimal(str(self.config.strategy.stop_loss))
            ):
                self.request_exit(
                    token_id,
                    "catastrophic stop",
                    timestamp,
                    position.last_score,
                )
                continue
            if age >= self.config.strategy.maximum_hold_seconds:
                self.request_exit(
                    token_id, "maximum holding time", timestamp, position.last_score
                )
                continue
            if age < self.config.strategy.minimum_hold_seconds:
                position.signal_exit_started_at = None
                continue
            if signal is None or signal.score >= self.config.strategy.exit_score:
                position.signal_exit_started_at = None
                continue
            if position.signal_exit_started_at is None:
                position.signal_exit_started_at = timestamp
                continue
            if (
                timestamp - position.signal_exit_started_at
                >= self.config.strategy.signal_exit_grace_seconds
            ):
                self.request_exit(
                    token_id,
                    "persistent signal deterioration",
                    timestamp,
                    signal.score,
                )

        self._check_kill_switch(timestamp)

    def request_exit(
        self,
        token_id: str,
        reason: str,
        timestamp: float,
        exit_score: float = 50.0,
    ) -> bool:
        position = self.positions.get(token_id)
        if position is None:
            return False
        existing = self.exit_requests.get(token_id)
        if existing is not None:
            # Preserve the earliest request but keep the latest/strongest reason visible.
            existing.reason = reason
            existing.exit_score = exit_score
            self.store.record_exit_request(self.run_id, existing)
            return True
        self._cancel_orders_for_token(
            token_id, f"cancelled for {reason}", timestamp=timestamp
        )
        request = ExitRequest(
            token_id=token_id,
            reason=reason,
            requested_at=timestamp,
            exit_score=exit_score,
            active_after_sequence=self._watermark(),
            active_at=timestamp + self.config.execution.taker_latency_ms / 1000.0,
        )
        self.exit_requests[token_id] = request
        self.store.record_exit_request(self.run_id, request)
        self._schedule_refresh(token_id, "EXIT", request.active_at, token_id)
        LOGGER.warning("PAPER EXIT REQUESTED %s | %s", self.assets[token_id].label, reason)
        return True

    # Backward-compatible method name; V2.2 does not fabricate an immediate cached fill.
    def force_exit(
        self,
        token_id: str,
        reason: str,
        timestamp: float,
        exit_score: float = 50.0,
    ) -> bool:
        return self.request_exit(token_id, reason, timestamp, exit_score)

    def flatten_all(self, reason: str, timestamp: float) -> None:
        for token_id in list(self.positions):
            position = self.positions.get(token_id)
            self.request_exit(
                token_id,
                reason,
                timestamp,
                position.last_score if position else 50.0,
            )

    def on_market_resolved(
        self,
        asset_ids: list[str] | tuple[str, ...] | set[str],
        winning_asset_id: str | None,
        timestamp: float,
    ) -> None:
        tokens = {str(token_id) for token_id in asset_ids if str(token_id)}
        winner = str(winning_asset_id) if winning_asset_id else None
        if not tokens:
            return
        self.resolved_tokens.update(tokens)
        for token_id in tokens:
            self._cancel_orders_for_token(
                token_id, "market resolved", timestamp=timestamp, track_missed=False
            )
            self.exit_requests.pop(token_id, None)

        for token_id in list(tokens):
            position = self.positions.get(token_id)
            asset = self.assets.get(token_id)
            if position is None or asset is None:
                continue
            if winner is None:
                LOGGER.error(
                    "Resolution event for %s has no winning asset; position left open",
                    asset.label,
                )
                continue
            settlement_price = ONE if token_id == winner else ZERO
            order = self._new_order(
                asset=asset,
                side="SELL",
                intent="SETTLEMENT",
                execution_style="SETTLEMENT",
                limit_price=settlement_price,
                quantity=position.quantity,
                queue_ahead=ZERO,
                score=position.last_score,
                timestamp=timestamp,
                expires_at=None,
                reason="market resolved",
                latency_ms=0,
            )
            self._apply_fill(
                order,
                position.quantity,
                settlement_price,
                maker=True,
                timestamp=timestamp,
                sequence_id=self._watermark(),
                exit_reason="market resolved",
            )

    def shutdown(self, timestamp: float) -> None:
        for pending in list(self.pending_entry_refreshes.values()):
            self._finish_attempt(
                pending.attempt, "CANCELLED", "shutdown while refresh pending", timestamp
            )
        self.pending_entry_refreshes.clear()
        for order in list(self.orders.values()):
            if order.status in {"OPEN", "PARTIAL", "PENDING"} and order.intent == "ENTRY":
                self._cancel_order(order, "shutdown", timestamp)
        if self.config.execution.flatten_on_shutdown:
            # This creates requests only. Without a later fresh depth event, V2 leaves
            # the position open rather than claiming a cached shutdown fill.
            self.flatten_all("session shutdown", timestamp)
        else:
            for position in self.positions.values():
                book = self.books.get(position.token_id)
                if book and position.token_id not in self.exit_requests:
                    self._ensure_target_order(position, book, timestamp)

    def _create_maker_entry(
        self,
        asset: Asset,
        price: Decimal,
        quantity: Decimal,
        queue_ahead: Decimal,
        queue_seconds: float | None,
        score: float,
        timestamp: float,
        attempt: EntryAttempt | None = None,
    ) -> PaperOrder:
        order = self._new_order(
            asset=asset,
            side="BUY",
            intent="ENTRY",
            execution_style="MAKER",
            limit_price=price,
            quantity=quantity,
            queue_ahead=queue_ahead,
            score=score,
            timestamp=timestamp,
            expires_at=timestamp + self.config.strategy.entry_timeout_seconds,
            reason="queue-aware maker signal entry",
            latency_ms=self.config.execution.maker_latency_ms,
            estimated_queue_seconds=queue_seconds,
        )
        self.entry_orders += 1
        self.maker_entry_orders += 1
        self._queue_samples.append(float(queue_ahead))
        if attempt is not None:
            attempt.execution_style = "MAKER"
            attempt.maker_price = price
            if attempt.requested_notional is None:
                attempt.requested_notional = price * quantity
            attempt.safe_notional = price * quantity
            attempt.order_id = order.id
            self._finish_attempt(
                attempt, "ORDER_CREATED", "maker order created", timestamp
            )
        LOGGER.info(
            "PAPER MAKER ENTRY %s @ %s qty=%s queue=%s score=%.2f",
            asset.label,
            price,
            quantity,
            queue_ahead,
            score,
        )
        return order

    def _create_taker_entry(
        self,
        asset: Asset,
        max_fill_price: Decimal,
        quantity: Decimal,
        score: float,
        timestamp: float,
        expected_return: Decimal,
        attempt: EntryAttempt | None = None,
    ) -> PaperOrder:
        order = self._new_order(
            asset=asset,
            side="BUY",
            intent="ENTRY",
            execution_style="TAKER",
            limit_price=max_fill_price,
            quantity=quantity,
            queue_ahead=ZERO,
            score=score,
            timestamp=timestamp,
            expires_at=timestamp + self.config.strategy.entry_timeout_seconds,
            reason=(
                "impact-safe hybrid taker entry; expected net target return "
                f"{expected_return:.4%}"
            ),
            latency_ms=self.config.execution.taker_latency_ms,
            status="PENDING",
        )
        self.entry_orders += 1
        self.taker_entry_orders += 1
        if attempt is not None:
            attempt.execution_style = "TAKER"
            attempt.expected_net_target_return = expected_return
            attempt.order_id = order.id
            self._finish_attempt(
                attempt, "ORDER_CREATED", "taker order created", timestamp
            )
        self._schedule_refresh(
            asset.token_id, "TAKER_ENTRY", order.active_at, order.id
        )
        LOGGER.info(
            "PAPER TAKER ENTRY PENDING %s max=%s qty=%s score=%.2f",
            asset.label,
            max_fill_price,
            quantity,
            score,
        )
        return order

    def _new_order(
        self,
        *,
        asset: Asset,
        side: str,
        intent: str,
        execution_style: str,
        limit_price: Decimal,
        quantity: Decimal,
        queue_ahead: Decimal,
        score: float,
        timestamp: float,
        expires_at: float | None,
        reason: str,
        latency_ms: int,
        status: str = "OPEN",
        estimated_queue_seconds: float | None = None,
    ) -> PaperOrder:
        order = PaperOrder(
            id=uuid.uuid4().hex,
            token_id=asset.token_id,
            market_id=asset.market_id,
            outcome=asset.outcome,
            side=side,
            intent=intent,
            execution_style=execution_style,
            limit_price=limit_price,
            quantity=quantity,
            filled_quantity=ZERO,
            average_fill_price=ZERO,
            queue_ahead=queue_ahead,
            estimated_queue_seconds=estimated_queue_seconds,
            created_at=timestamp,
            active_at=timestamp + latency_ms / 1000.0,
            active_after_sequence=self._watermark(),
            expires_at=expires_at,
            status=status,
            score_at_creation=score,
            reason=reason,
        )
        self.orders[order.id] = order
        self.store.record_order(self.run_id, order, force=True)
        return order

    def _maker_entry_price(self, book: OrderBook, score: float) -> Decimal:
        bid = book.best_bid
        ask = book.best_ask
        if bid is None or ask is None:
            return ZERO
        ticks = self.config.execution.base_improve_bid_ticks
        if score >= self.config.execution.aggressive_maker_score:
            ticks = self.config.execution.aggressive_improve_bid_ticks
        improved = bid + book.tick_size * ticks
        highest_post_only = ask - book.tick_size
        price = min(improved, highest_post_only) if highest_post_only > bid else bid
        price = floor_to_tick(price, book.tick_size)
        return bid if price <= ZERO or price >= ask else price

    def _queue_aware_price(
        self,
        book: OrderBook,
        quantity: Decimal,
        score: float,
        features: object | None,
    ) -> tuple[Decimal, Decimal, float | None, bool]:
        price = self._maker_entry_price(book, score)
        queue, seconds, ok = self._queue_metrics(book, price, quantity, features)
        ask = book.best_ask
        bid = book.best_bid
        if ok or ask is None or bid is None:
            return price, queue, seconds, ok
        # Rescue a bad queue incrementally. Never jump across the entire spread just
        # to obtain a zero displayed queue; that would silently turn a maker entry
        # into an almost-taker price.
        candidate = price
        for _ in range(self.config.execution.max_queue_rescue_ticks):
            candidate = floor_to_tick(candidate + book.tick_size, book.tick_size)
            if candidate >= ask:
                break
            queue2, seconds2, ok2 = self._queue_metrics(
                book, candidate, quantity, features
            )
            if ok2:
                return candidate, queue2, seconds2, True
        return price, queue, seconds, False

    def _queue_metrics(
        self,
        book: OrderBook,
        price: Decimal,
        quantity: Decimal,
        features: object | None,
    ) -> tuple[Decimal, float | None, bool]:
        queue = book.size_at("BUY", price) * Decimal(
            str(self.config.execution.queue_ahead_fraction)
        )
        multiple = float(queue / quantity) if quantity > ZERO else math.inf
        sell_shares = float(getattr(features, "sell_volume_60s_shares", 0.0))
        seconds = None
        if sell_shares > 0:
            seconds = float(queue) / (sell_shares / 60.0)
        flow_ok = (
            seconds is not None
            and seconds <= self.config.execution.max_estimated_queue_seconds
        ) or (
            seconds is None and not self.config.execution.require_queue_flow_estimate
        )
        ok = multiple <= self.config.execution.max_queue_ahead_multiple and flow_ok
        return queue, seconds, ok

    def _entry_notional(
        self, book: OrderBook, price: Decimal, style: str, timestamp: float
    ) -> Decimal:
        available_after_buffer = max(
            ZERO,
            self.available_cash - Decimal(str(self.config.risk.cash_buffer_usdc)),
        )
        if self.config.risk.sizing_mode == "bankroll_fraction":
            target = available_after_buffer * Decimal(str(self.config.risk.bankroll_fraction))
        else:
            target = Decimal(str(self.config.risk.fixed_position_usdc))
        equity = self._liquidation_equity_at(timestamp)
        per_position_cap = equity * Decimal(str(self.config.risk.max_position_pct_equity))
        total_cap = equity * Decimal(str(self.config.risk.max_total_exposure_pct_equity))
        remaining_exposure = max(ZERO, total_cap - self.exposure)
        bid_depth_cap = self.shadow.depth_notional(
            book.token_id,
            "BUY",
            self.config.universe.depth_levels,
            timestamp=timestamp,
            stale_seconds=self.config.strategy.stale_book_seconds,
        ) * Decimal(str(self.config.risk.depth_utilization))
        caps = [target, per_position_cap, remaining_exposure, available_after_buffer, bid_depth_cap]
        if style == "TAKER":
            ask_depth_cap = self.shadow.depth_notional(
                book.token_id,
                "SELL",
                self.config.universe.depth_levels,
                timestamp=timestamp,
                stale_seconds=self.config.strategy.stale_book_seconds,
            ) * Decimal(str(self.config.risk.depth_utilization))
            caps.append(ask_depth_cap)
        return max(ZERO, min(caps))

    def _taker_spread_ok(self, book: OrderBook) -> bool:
        if book.spread is None or book.midpoint is None or book.midpoint <= ZERO:
            return False
        return (
            book.spread / book.midpoint
            <= Decimal(str(self.config.execution.max_taker_spread_pct))
        )

    def _quantity_quantum(self) -> Decimal:
        return Decimal("1").scaleb(-self.config.execution.quantity_decimals)

    def _minimum_quantity(self, book: OrderBook) -> Decimal:
        quantum = self._quantity_quantum()
        units = (book.min_order_size / quantum).to_integral_value(
            rounding=ROUND_CEILING
        )
        return units * quantum

    def _fills_notional_and_fee(
        self,
        asset: Asset,
        fills: list[tuple[Decimal, Decimal]],
        quantity: Decimal,
        *,
        maker: bool,
    ) -> tuple[Decimal, Decimal, Decimal]:
        remaining = quantity
        notional = ZERO
        fee = ZERO
        actual = ZERO
        for price, available in fills:
            take = min(remaining, available)
            if take <= ZERO:
                continue
            notional += price * take
            fee += self._fee(asset, take, price, maker=maker)
            actual += take
            remaining -= take
            if remaining <= ZERO:
                break
        return notional, fee, actual

    def _evaluate_taker_quantity(
        self,
        asset: Asset,
        book: OrderBook,
        quantity: Decimal,
        timestamp: float,
        *,
        after_sequence: int | None = None,
        active_at: float | None = None,
        limit_price: Decimal | None = None,
        cash_limit: Decimal | None = None,
    ) -> tuple[TakerEntryPlan | None, str]:
        if quantity <= ZERO:
            return None, "taker quantity is zero"

        entry_fills = self.shadow.walk(
            asset.token_id,
            "SELL",
            quantity,
            consume=False,
            limit_price=limit_price,
            after_sequence=after_sequence,
            active_at=active_at,
            timestamp=timestamp,
            stale_seconds=self.config.strategy.stale_book_seconds,
        )
        entry_vwap, entry_quantity = self.shadow.aggregate(entry_fills)
        if entry_vwap is None or entry_quantity < quantity:
            return None, "insufficient executable ask depth"
        ask = book.best_ask
        if ask is None or ask <= ZERO:
            return None, "missing best ask"
        entry_slippage = entry_vwap / ask - ONE
        if entry_slippage > Decimal(
            str(self.config.execution.max_taker_entry_slippage_pct)
        ):
            return None, "taker entry slippage exceeds limit"

        entry_notional, entry_fee, actual_entry = self._fills_notional_and_fee(
            asset, entry_fills, quantity, maker=False
        )
        if actual_entry < quantity or entry_notional <= ZERO:
            return None, "insufficient executable ask shares"
        total_entry_cost = entry_notional + entry_fee
        if cash_limit is not None and total_entry_cost > cash_limit:
            return None, "insufficient paper cash after taker fees"

        exit_fills = self.shadow.walk(
            asset.token_id,
            "BUY",
            quantity,
            consume=False,
            after_sequence=after_sequence,
            active_at=active_at,
            timestamp=timestamp,
            stale_seconds=self.config.strategy.stale_book_seconds,
        )
        exit_vwap, exit_quantity = self.shadow.aggregate(exit_fills)
        liquidation_fraction = (
            exit_quantity / quantity if quantity > ZERO else ZERO
        )
        if (
            exit_vwap is None
            or liquidation_fraction
            < Decimal(
                str(self.config.execution.min_immediate_liquidation_fraction)
            )
        ):
            return None, "insufficient immediate exit depth"
        exit_notional, exit_fee, actual_exit = self._fills_notional_and_fee(
            asset, exit_fills, quantity, maker=False
        )
        if actual_exit < quantity:
            return None, "insufficient immediate exit depth"
        exit_proceeds = exit_notional - exit_fee
        immediate_return = (
            (exit_proceeds - total_entry_cost) / total_entry_cost
            if total_entry_cost > ZERO
            else Decimal("-1")
        )
        if immediate_return < -Decimal(
            str(self.config.execution.max_immediate_round_trip_loss_pct)
        ):
            return None, "immediate round-trip loss exceeds limit"

        target_raw = (
            total_entry_cost
            * (ONE + Decimal(str(self.config.strategy.target_return)))
            / quantity
        )
        target_price = ceil_to_tick(target_raw, book.tick_size)
        if target_price >= ONE:
            return None, "net profit target is outside tradable price range"
        target_price = min(ONE - book.tick_size, target_price)
        expected_target_return = (
            (quantity * target_price - total_entry_cost) / total_entry_cost
            if total_entry_cost > ZERO
            else Decimal("-1")
        )
        if expected_target_return < Decimal(
            str(self.config.execution.minimum_expected_net_target_return)
        ):
            return None, "taker target is not net-positive after fees"

        max_fill_price = max(price for price, _ in entry_fills)
        if self.config.execution.taker_slippage_buffer_ticks > 0:
            max_fill_price += (
                book.tick_size * self.config.execution.taker_slippage_buffer_ticks
            )
        max_fill_price = min(
            ONE - book.tick_size, ceil_to_tick(max_fill_price, book.tick_size)
        )
        return (
            TakerEntryPlan(
                quantity=quantity,
                entry_fills=entry_fills,
                entry_vwap=entry_vwap,
                entry_notional=entry_notional,
                entry_fee=entry_fee,
                max_fill_price=max_fill_price,
                target_price=target_price,
                expected_target_return=expected_target_return,
                exit_fills=exit_fills,
                exit_vwap=exit_vwap,
                exit_proceeds=exit_proceeds,
                exit_fee=exit_fee,
                liquidation_fraction=liquidation_fraction,
                immediate_round_trip_return=immediate_return,
                entry_slippage_pct=entry_slippage,
            ),
            "ok",
        )

    def _find_safe_taker_plan(
        self,
        asset: Asset,
        book: OrderBook,
        desired_quantity: Decimal,
        timestamp: float,
        *,
        after_sequence: int | None = None,
        active_at: float | None = None,
        limit_price: Decimal | None = None,
        cash_limit: Decimal | None = None,
    ) -> tuple[TakerEntryPlan | None, str]:
        quantum = self._quantity_quantum()
        minimum = self._minimum_quantity(book)
        high_units = int(
            (desired_quantity / quantum).to_integral_value(rounding=ROUND_FLOOR)
        )
        minimum_units = int(
            (minimum / quantum).to_integral_value(rounding=ROUND_CEILING)
        )
        if high_units < minimum_units:
            return None, "safe taker size below minimum share size"

        effective_cash = self.available_cash if cash_limit is None else cash_limit
        minimum_plan, minimum_reason = self._evaluate_taker_quantity(
            asset,
            book,
            Decimal(minimum_units) * quantum,
            timestamp,
            after_sequence=after_sequence,
            active_at=active_at,
            limit_price=limit_price,
            cash_limit=effective_cash,
        )
        if minimum_plan is None:
            return None, minimum_reason

        best = minimum_plan
        low_units = minimum_units + 1
        upper_units = high_units
        iterations = 0
        while low_units <= upper_units and iterations < self.config.execution.taker_sizing_iterations:
            iterations += 1
            mid_units = (low_units + upper_units) // 2
            candidate_quantity = Decimal(mid_units) * quantum
            candidate, _ = self._evaluate_taker_quantity(
                asset,
                book,
                candidate_quantity,
                timestamp,
                after_sequence=after_sequence,
                active_at=active_at,
                limit_price=limit_price,
                cash_limit=effective_cash,
            )
            if candidate is not None:
                best = candidate
                low_units = mid_units + 1
            else:
                upper_units = mid_units - 1

        minimum_notional = Decimal(
            str(self.config.execution.minimum_taker_notional_usdc)
        )
        if best.entry_notional < minimum_notional:
            return None, "safe taker notional below configured minimum"
        return best, "ok"

    @staticmethod
    def _apply_taker_plan_to_attempt(
        attempt: EntryAttempt, plan: TakerEntryPlan
    ) -> None:
        attempt.execution_style = "TAKER"
        attempt.taker_vwap = plan.entry_vwap
        attempt.immediate_exit_vwap = plan.exit_vwap
        attempt.safe_notional = plan.entry_notional
        attempt.estimated_fee = plan.entry_fee
        attempt.estimated_slippage_pct = plan.entry_slippage_pct
        attempt.immediate_liquidation_fraction = plan.liquidation_fraction
        attempt.immediate_round_trip_return = plan.immediate_round_trip_return
        attempt.expected_net_target_return = plan.expected_target_return

    def _update_attempt_for_order(
        self, order: PaperOrder, plan: TakerEntryPlan, timestamp: float
    ) -> None:
        for attempt in self.entry_attempt_records.values():
            if attempt.order_id != order.id:
                continue
            self._apply_taker_plan_to_attempt(attempt, plan)
            attempt.updated_at = timestamp
            self._record_attempt(attempt, force=True)
            return

    def _expected_taker_entry_return(
        self,
        asset: Asset,
        book: OrderBook,
        fills: list[tuple[Decimal, Decimal]],
        quantity: Decimal,
    ) -> Decimal:
        """Compatibility helper: net return at the tick-rounded maker target."""

        cost, fees, actual = self._fills_notional_and_fee(
            asset, fills, quantity, maker=False
        )
        if actual < quantity or cost <= ZERO:
            return Decimal("-1")
        total = cost + fees
        target = ceil_to_tick(
            total
            * (ONE + Decimal(str(self.config.strategy.target_return)))
            / quantity,
            book.tick_size,
        )
        if target >= ONE:
            return Decimal("-1")
        return (quantity * target - total) / total

    def _process_pending_taker_entry(self, book: OrderBook, timestamp: float) -> None:
        for order in list(self.orders.values()):
            if (
                order.token_id != book.token_id
                or order.intent != "ENTRY"
                or order.execution_style != "TAKER"
                or order.status not in {"PENDING", "PARTIAL"}
            ):
                continue
            if timestamp < order.active_at:
                continue

            asset = self.assets[order.token_id]
            plan, reason = self._find_safe_taker_plan(
                asset,
                book,
                order.remaining_quantity,
                timestamp,
                after_sequence=order.active_after_sequence,
                active_at=order.active_at,
                limit_price=order.limit_price,
                # Pending BUY notional is reserved but has not left cash yet.
                cash_limit=self.cash,
            )
            if plan is None:
                if reason in {
                    "insufficient executable ask depth",
                    "insufficient executable ask shares",
                    "insufficient immediate exit depth",
                    "missing best ask",
                }:
                    self._schedule_refresh(
                        order.token_id, "TAKER_ENTRY", timestamp, order.id
                    )
                    continue
                self._cancel_order(
                    order,
                    f"taker preflight failed before activation: {reason}",
                    timestamp,
                )
                position = self.positions.get(order.token_id)
                if position:
                    self._ensure_target_order(position, book, timestamp)
                continue

            if order.filled_quantity == ZERO and plan.quantity < order.quantity:
                original = order.quantity
                order.quantity = plan.quantity
                order.limit_price = min(order.limit_price, plan.max_fill_price)
                order.reason = (
                    "impact-safe taker entry; size reduced from "
                    f"{original} to {plan.quantity} shares"
                )
                self.store.record_order(self.run_id, order, force=True)
                LOGGER.info(
                    "PAPER TAKER SIZE REDUCED token=%s from=%s to=%s "
                    "round_trip=%s slippage=%s",
                    order.token_id,
                    original,
                    plan.quantity,
                    f"{plan.immediate_round_trip_return:.4%}",
                    f"{plan.entry_slippage_pct:.4%}",
                )
            self._update_attempt_for_order(order, plan, timestamp)

            # Fill exactly the preflight-certified ask levels. The public-side depth
            # is consumed from the shadow ledger so it cannot be reused by a later
            # paper order unless the real book demonstrates replenishment.
            for price, available in plan.entry_fills:
                if order.remaining_quantity <= ZERO:
                    break
                requested = min(available, order.remaining_quantity)
                affordable = self._max_affordable_buy_quantity(
                    asset, price, requested, maker=False
                )
                if affordable <= ZERO:
                    break
                filled = self._apply_fill(
                    order,
                    affordable,
                    price,
                    maker=False,
                    timestamp=timestamp,
                    sequence_id=book.last_ask_sequence,
                    exit_reason="entry",
                )
                if filled > ZERO:
                    self.shadow.consume_fills(
                        order.token_id, "SELL", [(price, filled)]
                    )

            # Simulate a fill-and-kill marketable order: one later fresh attempt only.
            if order.status != "FILLED":
                self._cancel_order(order, "taker FAK remainder cancelled", timestamp)
                position = self.positions.get(order.token_id)
                if position:
                    self._ensure_target_order(position, book, timestamp)

    def _process_exit_request(self, book: OrderBook, timestamp: float) -> None:
        request = self.exit_requests.get(book.token_id)
        position = self.positions.get(book.token_id)
        asset = self.assets.get(book.token_id)
        if request is None or position is None or asset is None:
            return
        if timestamp < request.active_at:
            return
        request.attempts += 1
        request.last_attempt_at = timestamp
        if position.quantity < book.min_order_size:
            request.status = "BLOCKED_MINIMUM_SIZE"
            self.store.record_exit_request(self.run_id, request)
            LOGGER.error(
                "Cannot submit paper exit for %s: residual %s shares is below min size %s",
                asset.label,
                position.quantity,
                book.min_order_size,
            )
            return
        fills = self.shadow.walk(
            book.token_id,
            "BUY",
            position.quantity,
            consume=False,
            after_sequence=request.active_after_sequence,
            active_at=request.active_at,
            timestamp=timestamp,
            stale_seconds=self.config.strategy.stale_book_seconds,
        )
        if not fills:
            observed = list(
                book.iter_observed_levels(
                    "BUY",
                    after_sequence=request.active_after_sequence,
                    active_at=request.active_at,
                    timestamp=timestamp,
                    stale_seconds=self.config.strategy.stale_book_seconds,
                )
            )
            request.status = (
                "WAITING_LIQUIDITY" if observed else "WAITING_FRESH_DEPTH"
            )
            request.active_after_sequence = self._watermark()
            request.active_at = timestamp + self.config.execution.taker_latency_ms / 1000.0
            self.store.record_exit_request(self.run_id, request)
            self._schedule_refresh(
                book.token_id, "EXIT", request.active_at, book.token_id
            )
            return

        vwap, filled_quantity = self.shadow.aggregate(fills)
        if vwap is None or filled_quantity <= ZERO:
            return
        adjusted_prices = []
        for public_price, _ in fills:
            adjusted = public_price
            if self.config.execution.taker_slippage_buffer_ticks > 0:
                adjusted = max(
                    book.tick_size,
                    floor_to_tick(
                        public_price
                        - book.tick_size
                        * self.config.execution.taker_slippage_buffer_ticks,
                        book.tick_size,
                    ),
                )
            adjusted_prices.append(adjusted)
        order = self._new_order(
            asset=asset,
            side="SELL",
            intent="RISK_EXIT",
            execution_style="TAKER",
            limit_price=min(adjusted_prices),
            # Submit the whole remaining position as the FAK order. A legal order can
            # receive a partial fill smaller than min_order_size; only the submitted
            # order size itself has to satisfy the market minimum.
            quantity=position.quantity,
            queue_ahead=ZERO,
            score=request.exit_score,
            timestamp=timestamp,
            expires_at=None,
            reason=request.reason,
            latency_ms=0,
        )
        for (public_price, quantity), adjusted in zip(fills, adjusted_prices):
            filled = self._apply_fill(
                order,
                quantity,
                adjusted,
                maker=False,
                timestamp=timestamp,
                sequence_id=book.last_bid_sequence,
                exit_reason=request.reason,
            )
            if filled > ZERO:
                self.shadow.consume_fills(
                    book.token_id, "BUY", [(public_price, filled)]
                )
        if order.status != "FILLED":
            self._cancel_order(
                order,
                "risk-exit FAK remainder cancelled",
                timestamp,
                track_missed=False,
            )
        if book.token_id not in self.positions:
            request.status = "FILLED"
            self.store.record_exit_request(self.run_id, request)
            self.exit_requests.pop(book.token_id, None)
        else:
            request.status = "WAITING_FRESH_DEPTH"
            request.active_after_sequence = self._watermark()
            request.active_at = timestamp + self.config.execution.taker_latency_ms / 1000.0
            self.store.record_exit_request(self.run_id, request)
            self._schedule_refresh(
                book.token_id, "EXIT", request.active_at, book.token_id
            )

    def _expire_entry_orders(self, timestamp: float) -> None:
        for order in list(self.orders.values()):
            if (
                order.intent == "ENTRY"
                and order.status in {"OPEN", "PARTIAL", "PENDING"}
                and order.expires_at is not None
                and timestamp >= order.expires_at
            ):
                self._cancel_order(order, "entry timeout", timestamp)
                position = self.positions.get(order.token_id)
                book = self.books.get(order.token_id)
                if position and book:
                    self._ensure_target_order(position, book, timestamp)

    def _manage_entry_orders(
        self, timestamp: float, signals: Mapping[str, SignalSnapshot]
    ) -> None:
        for order in list(self.orders.values()):
            if order.intent != "ENTRY" or order.status not in {"OPEN", "PARTIAL", "PENDING"}:
                continue
            signal = signals.get(order.token_id)
            faded = signal is None or signal.score < self.config.strategy.entry_cancel_score
            if faded:
                if order.fade_started_at is None:
                    order.fade_started_at = timestamp
                    self.store.record_order(self.run_id, order)
                elif (
                    timestamp - order.fade_started_at
                    >= self.config.strategy.signal_fade_grace_seconds
                ):
                    self._cancel_order(order, "entry signal faded after grace", timestamp)
                    position = self.positions.get(order.token_id)
                    book = self.books.get(order.token_id)
                    if position and book:
                        self._ensure_target_order(position, book, timestamp)
                    continue
            else:
                if order.fade_started_at is not None:
                    order.fade_started_at = None
                    self.store.record_order(self.run_id, order)

            book = self.books.get(order.token_id)
            if book is None:
                continue
            if floor_to_tick(order.limit_price, book.tick_size) != order.limit_price:
                self._cancel_order(
                    order, "entry price invalid after tick-size change", timestamp
                )
                continue
            if order.filled_quantity == ZERO and order.remaining_quantity < book.min_order_size:
                self._cancel_order(order, "entry below updated minimum share size", timestamp)

    def _ensure_target_order(
        self, position: Position, book: OrderBook, timestamp: float
    ) -> PaperOrder | None:
        if position.token_id in self.exit_requests:
            return None
        existing = self._target_order(position.token_id)
        target = ceil_to_tick(
            (position.entry_cost + position.entry_fees)
            * (ONE + Decimal(str(self.config.strategy.target_return)))
            / position.quantity,
            book.tick_size,
        )
        target = min(ONE - book.tick_size, target)
        position.target_price = target
        if existing is not None:
            if existing.limit_price == target and existing.quantity == position.quantity:
                position.target_order_id = existing.id
                return existing
            self._cancel_order(existing, "target repriced", timestamp, track_missed=False)
        if target <= ZERO or position.quantity <= ZERO:
            return None
        if position.quantity < book.min_order_size:
            LOGGER.warning(
                "Cannot place paper target for %s: %s shares is below minimum %s",
                self.assets[position.token_id].label,
                position.quantity,
                book.min_order_size,
            )
            return None
        queue_ahead = book.size_at("SELL", target) * Decimal(
            str(self.config.execution.target_queue_ahead_fraction)
        )
        asset = self.assets[position.token_id]
        order = self._new_order(
            asset=asset,
            side="SELL",
            intent="TARGET",
            execution_style="MAKER",
            limit_price=target,
            quantity=position.quantity,
            queue_ahead=queue_ahead,
            score=position.entry_score,
            timestamp=timestamp,
            expires_at=None,
            reason="maker profit target",
            latency_ms=self.config.execution.maker_latency_ms,
        )
        position.target_order_id = order.id
        LOGGER.info("PAPER TARGET %s @ %s", asset.label, target)
        return order

    def _apply_fill(
        self,
        order: PaperOrder,
        quantity: Decimal,
        price: Decimal,
        *,
        maker: bool,
        timestamp: float,
        sequence_id: int,
        exit_reason: str,
    ) -> Decimal:
        quantity = min(quantity, order.remaining_quantity)
        if quantity <= ZERO:
            return ZERO
        asset = self.assets[order.token_id]
        fee = self._fee(asset, quantity, price, maker)

        if order.side == "BUY":
            required = quantity * price + fee
            if required > self.cash:
                quantity = self._max_affordable_buy_quantity(
                    asset, price, quantity, maker=maker
                )
                if quantity <= ZERO:
                    self._cancel_order(order, "insufficient paper cash", timestamp)
                    return ZERO
                fee = self._fee(asset, quantity, price, maker)
                required = quantity * price + fee
            self.cash -= required
        else:
            position = self.positions.get(order.token_id)
            if position is None:
                self._cancel_order(
                    order, "position no longer exists", timestamp, track_missed=False
                )
                return ZERO
            quantity = min(quantity, position.quantity)
            if quantity <= ZERO:
                return ZERO
            fee = self._fee(asset, quantity, price, maker)

        previous_status = order.status
        previous_filled = order.filled_quantity
        new_filled = previous_filled + quantity
        order.average_fill_price = (
            order.average_fill_price * previous_filled + price * quantity
        ) / new_filled
        order.filled_quantity = new_filled
        order.status = "FILLED" if order.remaining_quantity <= ZERO else "PARTIAL"

        fill = Fill(
            id=uuid.uuid4().hex,
            order_id=order.id,
            token_id=order.token_id,
            side=order.side,
            intent=order.intent,
            quantity=quantity,
            price=price,
            fee=fee,
            maker=maker,
            timestamp=timestamp,
            sequence_id=sequence_id,
        )
        self.store.record_fill(self.run_id, fill)

        if order.side == "BUY":
            self._apply_buy_fill(order, asset, quantity, price, fee, timestamp)
        else:
            self._apply_sell_fill(
                order, asset, quantity, price, fee, timestamp, exit_reason
            )
        self.total_fees += fee
        self.store.record_order(self.run_id, order, force=True)
        if (
            order.intent == "ENTRY"
            and order.id not in self._counted_filled_entries
            and order.filled_quantity > ZERO
        ):
            self._counted_filled_entries.add(order.id)
            self.filled_entry_orders += 1
        if previous_status == "PENDING" and order.status == "PARTIAL":
            order.reason = "partial taker entry fill"
        return quantity

    def _max_affordable_buy_quantity(
        self,
        asset: Asset,
        price: Decimal,
        requested: Decimal,
        *,
        maker: bool,
    ) -> Decimal:
        if requested <= ZERO or price <= ZERO or self.cash <= ZERO:
            return ZERO
        schedule = asset.fee_schedule
        if maker or (schedule.known and not schedule.enabled):
            return min(requested, self._quantize_quantity(self.cash / price))
        # The current fee curve is linear in quantity at a fixed price. Use an
        # unquantized per-share curve, then verify against the rounded total fee.
        rate = schedule.rate
        if rate <= ZERO:
            rate = Decimal(str(self.config.execution.default_taker_fee_rate))
        exponent = schedule.exponent
        if exponent <= ZERO:
            exponent = Decimal(str(self.config.execution.default_fee_exponent))
        per_share_fee = rate * ((price * (ONE - price)) ** exponent)
        unit_cost = price + per_share_fee
        if unit_cost <= ZERO:
            return ZERO
        quantity = min(requested, self._quantize_quantity(self.cash / unit_cost))
        quantum = Decimal("1").scaleb(-self.config.execution.quantity_decimals)
        while quantity > ZERO:
            required = quantity * price + self._fee(asset, quantity, price, maker=False)
            if required <= self.cash:
                return quantity
            quantity = max(ZERO, quantity - quantum)
        return ZERO

    def _apply_buy_fill(
        self,
        order: PaperOrder,
        asset: Asset,
        quantity: Decimal,
        price: Decimal,
        fee: Decimal,
        timestamp: float,
    ) -> None:
        position = self.positions.get(order.token_id)
        if position is None:
            book = self.books.get(order.token_id)
            tick = book.tick_size if book else Decimal("0.01")
            target = ceil_to_tick(
                price * (ONE + Decimal(str(self.config.strategy.target_return))), tick
            )
            position = Position(
                token_id=order.token_id,
                market_id=asset.market_id,
                outcome=asset.outcome,
                question=asset.question,
                quantity=quantity,
                average_entry_price=price,
                entry_cost=quantity * price,
                entry_fees=fee,
                opened_at=timestamp,
                entry_score=order.score_at_creation,
                target_price=target,
                peak_bid=price,
                last_score=order.score_at_creation,
            )
            self.positions[order.token_id] = position
            self.entries_today += 1
        else:
            old_quantity = position.quantity
            new_quantity = old_quantity + quantity
            position.average_entry_price = (
                position.average_entry_price * old_quantity + price * quantity
            ) / new_quantity
            position.quantity = new_quantity
            position.entry_cost += quantity * price
            position.entry_fees += fee
        if order.status == "FILLED":
            book = self.books.get(order.token_id)
            if book:
                self._ensure_target_order(position, book, timestamp)

    def _apply_sell_fill(
        self,
        order: PaperOrder,
        asset: Asset,
        quantity: Decimal,
        price: Decimal,
        fee: Decimal,
        timestamp: float,
        exit_reason: str,
    ) -> None:
        position = self.positions[order.token_id]
        pre_quantity = position.quantity
        ratio = quantity / pre_quantity if pre_quantity > ZERO else ONE
        allocated_cost = position.entry_cost * ratio
        allocated_entry_fees = position.entry_fees * ratio

        proceeds = quantity * price - fee
        self.cash += proceeds
        incremental_net = quantity * price - allocated_cost - allocated_entry_fees - fee
        self.realized_pnl += incremental_net

        accumulator = self.exit_accumulators.get(order.token_id)
        if accumulator is None:
            accumulator = ExitAccumulator(
                token_id=order.token_id,
                market_id=position.market_id,
                outcome=position.outcome,
                question=position.question,
                opened_at=position.opened_at,
                average_entry_price=position.average_entry_price,
                entry_score=position.entry_score,
            )
            self.exit_accumulators[order.token_id] = accumulator
        accumulator.quantity += quantity
        accumulator.exit_notional += quantity * price
        accumulator.entry_cost += allocated_cost
        accumulator.entry_fees += allocated_entry_fees
        accumulator.exit_fees += fee
        accumulator.exit_reason = exit_reason
        accumulator.exit_score = order.score_at_creation

        position.quantity -= quantity
        position.entry_cost -= allocated_cost
        position.entry_fees -= allocated_entry_fees
        if position.quantity <= Decimal("0.00000001"):
            position.quantity = ZERO
            self._finalize_trade(order.token_id, timestamp)
        elif order.intent == "TARGET" and order.status == "FILLED":
            position.target_order_id = None
            book = self.books.get(order.token_id)
            if book:
                self._ensure_target_order(position, book, timestamp)

    def _finalize_trade(self, token_id: str, timestamp: float) -> None:
        position = self.positions.pop(token_id)
        accumulator = self.exit_accumulators.pop(token_id)
        average_exit = (
            accumulator.exit_notional / accumulator.quantity
            if accumulator.quantity > ZERO
            else ZERO
        )
        gross = accumulator.exit_notional - accumulator.entry_cost
        fees = accumulator.entry_fees + accumulator.exit_fees
        net = gross - fees
        denominator = accumulator.entry_cost + accumulator.entry_fees
        return_pct = net / denominator if denominator > ZERO else ZERO
        trade = ClosedTrade(
            id=uuid.uuid4().hex,
            token_id=token_id,
            market_id=accumulator.market_id,
            outcome=accumulator.outcome,
            question=accumulator.question,
            opened_at=accumulator.opened_at,
            closed_at=timestamp,
            quantity=accumulator.quantity,
            average_entry_price=accumulator.average_entry_price,
            average_exit_price=average_exit,
            gross_pnl=gross,
            fees=fees,
            net_pnl=net,
            return_pct=return_pct,
            exit_reason=accumulator.exit_reason,
            entry_score=accumulator.entry_score,
            exit_score=accumulator.exit_score,
        )
        self.store.record_closed_trade(self.run_id, trade)
        self.closed_trades += 1
        if net > ZERO:
            self.wins += 1
            self.consecutive_losses = 0
        else:
            self.losses += 1
            self.consecutive_losses += 1
            self.market_loss_counts[trade.market_id] += 1
            loss_count = self.market_loss_counts[trade.market_id]
            if loss_count >= self.config.risk.max_losses_per_market_per_day:
                self.markets_locked_for_day.add(trade.market_id)
                self.market_loss_cooldown_until.pop(trade.market_id, None)
                LOGGER.warning(
                    "MARKET LOCKOUT market=%s losses=%s until next UTC risk day",
                    trade.market_id,
                    loss_count,
                )
            else:
                self.market_loss_cooldown_until[trade.market_id] = (
                    timestamp + self.config.risk.market_loss_cooldown_seconds
                )
                LOGGER.warning(
                    "MARKET LOSS COOLDOWN market=%s losses=%s seconds=%s",
                    trade.market_id,
                    loss_count,
                    self.config.risk.market_loss_cooldown_seconds,
                )
        self.cooldown_until[token_id] = (
            timestamp + self.config.strategy.cooldown_after_exit_seconds
        )
        position.target_order_id = None
        LOGGER.info(
            "PAPER CLOSE %s | P&L %s (%s%%) | %s",
            self.assets[token_id].label,
            f"{trade.net_pnl:.2f}",
            f"{trade.return_pct * 100:.2f}",
            trade.exit_reason,
        )
        if self.consecutive_losses >= self.config.risk.max_consecutive_losses:
            self._halt("maximum consecutive losses reached", timestamp, flatten=False)

    def _fee(
        self, asset: Asset, quantity: Decimal, price: Decimal, maker: bool
    ) -> Decimal:
        schedule = asset.fee_schedule
        if maker or (schedule.known and not schedule.enabled):
            return ZERO
        rate = schedule.rate
        if rate <= ZERO:
            rate = Decimal(str(self.config.execution.default_taker_fee_rate))
        exponent = schedule.exponent
        if exponent <= ZERO:
            exponent = Decimal(str(self.config.execution.default_fee_exponent))
        curve = price * (ONE - price)
        fee = quantity * rate * (curve**exponent)
        return fee.quantize(Decimal("0.00001"))

    def _liquidation_proceeds(
        self, token_id: str, quantity: Decimal, timestamp: float
    ) -> tuple[Decimal, Decimal]:
        book = self.books.get(token_id)
        asset = self.assets.get(token_id)
        if book is None or asset is None or quantity <= ZERO:
            return ZERO, ZERO
        fills = self.shadow.walk(
            token_id,
            "BUY",
            quantity,
            consume=False,
            timestamp=timestamp,
            stale_seconds=self.config.strategy.stale_book_seconds,
        )
        if not fills:
            bid = book.best_bid or ZERO
            haircut_value = (
                quantity
                * bid
                * Decimal(str(self.config.risk.stale_liquidation_value_pct))
            )
            return haircut_value, ZERO
        proceeds = ZERO
        filled = ZERO
        for price, size in fills:
            proceeds += size * price - self._fee(asset, size, price, maker=False)
            filled += size
        # Any quantity beyond visible shadow depth is conservatively worth zero.
        return proceeds, filled

    def liquidation_quote(
        self, token_id: str, quantity: Decimal, timestamp: float | None = None
    ) -> tuple[Decimal, Decimal]:
        """Return fee/depth-aware executable proceeds and visible filled shares."""

        when = (
            datetime.now(tz=timezone.utc).timestamp()
            if timestamp is None
            else timestamp
        )
        return self._liquidation_proceeds(token_id, quantity, when)

    def _position_liquidation_return(
        self, position: Position, timestamp: float
    ) -> Decimal:
        return self._position_liquidation_snapshot(position, timestamp)[0]

    def _position_liquidation_snapshot(
        self, position: Position, timestamp: float
    ) -> tuple[Decimal, Decimal]:
        proceeds, filled = self._liquidation_proceeds(
            position.token_id, position.quantity, timestamp
        )
        denominator = position.entry_cost + position.entry_fees
        if denominator <= ZERO:
            return ZERO, ZERO
        filled_fraction = (
            min(ONE, filled / position.quantity)
            if position.quantity > ZERO
            else ZERO
        )
        return (proceeds - denominator) / denominator, filled_fraction

    def _check_kill_switch(self, timestamp: float) -> None:
        self._roll_risk_day(timestamp)
        floor = self.day_start_equity * (
            ONE - Decimal(str(self.config.risk.max_daily_loss_pct))
        )
        equity = self._liquidation_equity_at(timestamp)
        if equity > floor:
            return
        if not self.halted:
            LOGGER.error("PAPER KILL SWITCH: liquidation equity fell to %s", equity)
        self._halt(
            "daily loss limit reached",
            timestamp,
            flatten=self.config.risk.flatten_on_kill_switch,
        )

    def _roll_risk_day(self, timestamp: float) -> None:
        try:
            day = datetime.fromtimestamp(timestamp, tz=timezone.utc).date().isoformat()
        except (OverflowError, OSError, ValueError):
            return
        if self.risk_day is None:
            self.risk_day = day
            self.day_start_equity = self._liquidation_equity_at(timestamp)
            return
        if day == self.risk_day:
            return
        previous_day = self.risk_day
        self.risk_day = day
        self.entries_today = 0
        self.day_start_equity = self._liquidation_equity_at(timestamp)
        self.market_loss_counts.clear()
        self.market_loss_cooldown_until.clear()
        self.markets_locked_for_day.clear()
        if self.halted and self.halt_reason == "daily loss limit reached":
            self.halted = False
            self.halt_reason = ""
        LOGGER.info(
            "Rolled paper risk controls from UTC day %s to %s; liquidation anchor %s",
            previous_day,
            day,
            self.day_start_equity,
        )

    def _halt(self, reason: str, timestamp: float, *, flatten: bool) -> None:
        self.halted = True
        self.halt_reason = reason
        for order in list(self.orders.values()):
            if order.intent == "ENTRY" and order.status in {"OPEN", "PARTIAL", "PENDING"}:
                self._cancel_order(order, f"risk halt: {reason}", timestamp)
        if flatten and self.positions:
            self.flatten_all(reason, timestamp)

    def _cancel_order(
        self,
        order: PaperOrder,
        reason: str,
        timestamp: float,
        *,
        track_missed: bool = True,
    ) -> None:
        if order.status not in {"OPEN", "PARTIAL", "PENDING"}:
            return
        was_entry = order.intent == "ENTRY"
        had_fill = order.filled_quantity > ZERO
        order.status = "CANCELLED"
        order.reason = reason
        self.store.record_order(self.run_id, order, force=True)
        if was_entry:
            self.cancelled_entry_orders += 1
            if track_missed and not had_fill:
                self._add_missed_watch(order, timestamp)
        position = self.positions.get(order.token_id)
        if position and position.target_order_id == order.id:
            position.target_order_id = None

    def _add_missed_watch(self, order: PaperOrder, timestamp: float) -> None:
        book = self.books.get(order.token_id)
        asset = self.assets.get(order.token_id)
        if book is None or asset is None:
            return
        target = min(
            ONE - book.tick_size,
            ceil_to_tick(
                order.limit_price
                * (ONE + Decimal(str(self.config.strategy.target_return))),
                book.tick_size,
            ),
        )
        watch = MissedMove(
            id=uuid.uuid4().hex,
            token_id=order.token_id,
            market_id=order.market_id,
            outcome=order.outcome,
            question=asset.question,
            order_id=order.id,
            cancelled_at=timestamp,
            entry_price=order.limit_price,
            target_price=target,
            score=order.score_at_creation,
            expires_at=timestamp + self.config.execution.missed_move_window_seconds,
        )
        self.missed_move_watches[watch.id] = watch
        self.store.record_missed_move(self.run_id, watch)

    def _process_missed_moves(self, book: OrderBook, timestamp: float) -> None:
        for watch_id, watch in list(self.missed_move_watches.items()):
            if watch.token_id != book.token_id:
                continue
            if timestamp > watch.expires_at:
                self.missed_move_watches.pop(watch_id, None)
                continue
            if watch.hit_at is None and book.best_bid is not None and book.best_bid >= watch.target_price:
                watch.hit_at = timestamp
                self.missed_moves += 1
                self.store.record_missed_move(self.run_id, watch)
                self.missed_move_watches.pop(watch_id, None)

    def _cancel_orders_for_token(
        self,
        token_id: str,
        reason: str,
        *,
        timestamp: float | None = None,
        track_missed: bool = True,
    ) -> None:
        now = (
            datetime.now(tz=timezone.utc).timestamp()
            if timestamp is None
            else timestamp
        )
        for order in list(self.orders.values()):
            if order.token_id == token_id and order.status in {"OPEN", "PARTIAL", "PENDING"}:
                self._cancel_order(
                    order,
                    reason,
                    now,
                    track_missed=track_missed and order.intent == "ENTRY",
                )

    def _has_open_order(self, token_id: str, *, intent: str | None = None) -> bool:
        return any(
            order.token_id == token_id
            and order.status in {"OPEN", "PARTIAL", "PENDING"}
            and (intent is None or order.intent == intent)
            for order in self.orders.values()
        )

    def _target_order(self, token_id: str) -> PaperOrder | None:
        for order in self.orders.values():
            if (
                order.token_id == token_id
                and order.intent == "TARGET"
                and order.status in {"OPEN", "PARTIAL"}
            ):
                return order
        return None

    def _book_is_fresh(self, book: OrderBook, timestamp: float) -> bool:
        stale_seconds = self.config.strategy.stale_book_seconds
        return book.top_is_fresh(
            "BUY", timestamp, stale_seconds
        ) and book.top_is_fresh("SELL", timestamp, stale_seconds)

    def _quantize_quantity(self, quantity: Decimal) -> Decimal:
        quantum = Decimal("1").scaleb(-self.config.execution.quantity_decimals)
        return max(ZERO, quantity.quantize(quantum, rounding=ROUND_FLOOR))
