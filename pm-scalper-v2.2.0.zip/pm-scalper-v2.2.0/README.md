# PM-Scalper V2.2

PM-Scalper V2.2 is a **live Polymarket public-data recorder and forward paper-trading research engine** for short-horizon YES/NO contracts. It scans liquid markets, calculates a transparent opportunity score, simulates realistic maker/taker execution, targets approximately `+1%`, and records the evidence needed to decide whether the strategy has an edge.

It is **paper-only**. There is no wallet, private-key, signing, deposit, withdrawal, or real-order submission code.

V2.2 was built from the V2.1 live run that exposed a specific failure: a near-full-bankroll taker order swept several ask levels, then the executable bid-side liquidation value was already down roughly 5–10%, causing exits within seconds. V2.2 moves that analysis **before entry**, sizes taker orders down to an impact-safe amount, and gives a valid position time to work toward its target.

## What changed in V2.2

### Impact-safe taker entries

A score above the taker threshold no longer means “sweep whatever depth is available.” V2.2 first simulates:

```text
buy the proposed quantity through fresh asks
              ↓
include applicable/unknown-default taker fees
              ↓
compute entry VWAP and slippage
              ↓
simulate immediate liquidation through fresh bids
              ↓
include exit taker fees
              ↓
accept only if the round trip and liquidity limits pass
```

The default taker constraints are:

```yaml
max_taker_entry_slippage_pct: 0.0025       # 0.25%
max_immediate_round_trip_loss_pct: 0.005  # 0.50%
min_immediate_liquidation_fraction: 1.0   # 100% visible exit capacity
minimum_taker_notional_usdc: 25
```

The broker binary-searches for the largest quantity that satisfies every constraint. A desired `$9,775` order may therefore become a `$9,775`, `$2,000`, `$200`, or zero-dollar taker order depending on the actual book. If no safe taker size exists, V2.2 falls back to the queue-aware maker route instead of forcing the trade.

### Thesis-aware holding

The target remains approximately `+1%`, but a normal weak-signal exit no longer overrides the intended holding horizon seconds after entry.

Default position flow:

```text
position opens
    ↓
post fee-aware +1% maker target
    ↓
first 10 minutes:
    ignore ordinary score weakness
    while still enforcing serious-risk exits
    ↓
after 10 minutes:
    score must remain below 43 for 5 continuous minutes
    before a thesis exit is requested
    ↓
otherwise hold until target, serious risk, resolution buffer,
market resolution, or the 4-hour maximum
```

The default `8%` stop is a **catastrophic executable-liquidation stop**, not a routine scalp stop. The portfolio-level daily-loss limit remains `5%`, so an almost-all-in position can still be flattened earlier if liquidation equity breaches that portfolio floor.

### Same-market loss protection

V2.1 entered the same losing market repeatedly. V2.2 adds market-level controls:

```text
first losing trade in a market
→ block that entire market for 4 hours

second losing trade in the same market during the UTC risk day
→ disable that market until the next UTC day
```

This is separate from the short token-level cooldown and prevents repeatedly attacking another YES/NO outcome belonging to the same event.

### Better diagnostics

Every entry attempt stores:

- desired notional and impact-safe notional;
- entry and immediate-exit VWAP;
- entry slippage;
- immediate liquidation fraction;
- simulated immediate round-trip return;
- taker rejection reason and maker fallback result;
- refresh state, latency, execution style, order ID, and final reason.

`pm-scalper progress` displays the new taker preflight summary and shows requested-to-safe sizing plus round-trip/slippage values for recent attempts.

## Default strategy

```yaml
strategy:
  entry_score: 69
  entry_cancel_score: 65
  target_return: 0.01
  stop_loss: 0.08
  minimum_hold_seconds: 600
  signal_exit_grace_seconds: 300
  exit_score: 43
  maximum_hold_seconds: 14400

execution:
  entry_style: "hybrid"
  taker_entry_score: 70
  max_taker_entry_slippage_pct: 0.0025
  max_immediate_round_trip_loss_pct: 0.005
  min_immediate_liquidation_fraction: 1.0

risk:
  starting_cash_usdc: 10000
  sizing_mode: "bankroll_fraction"
  bankroll_fraction: 0.98
  max_open_positions: 1
  max_daily_loss_pct: 0.05
  market_loss_cooldown_seconds: 14400
  max_losses_per_market_per_day: 2
```

The configured bankroll fraction is a **desired maximum**, not a promise to deploy the entire bankroll. Fresh executable liquidity and the V2.2 impact limits determine the final safe size.

## Requirements

- Linux, macOS, or another environment with Python `3.11+`
- Internet access to Polymarket public Gamma, CLOB, and market WebSocket endpoints
- No Polymarket account is needed for public-data paper mode

Ubuntu 24.04’s standard Python 3.12 is supported.

## Install

From the directory containing the ZIP:

```bash
unzip pm-scalper-v2.2.0.zip
cd pm-scalper-v2.2.0

chmod +x scripts/*.sh
./scripts/bootstrap.sh
```

The bootstrap selects Python 3.13, 3.12, 3.11, or another compatible `python3`, creates `.venv`, installs the package and development dependencies, and runs local validation.

Manual installation:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip setuptools wheel
.venv/bin/python -m pip install -e '.[dev]'
```

## Validate and discover

```bash
.venv/bin/pm-scalper --version
.venv/bin/pm-scalper validate --config config/default.yaml
.venv/bin/pm-scalper discover --config config/default.yaml
```

Expected version:

```text
pm-scalper 2.2.0
```

Online validation combines local checks with live market discovery:

```bash
.venv/bin/pm-scalper validate --config config/default.yaml --online
```

## Run the paper trader

Interactive dashboard:

```bash
./scripts/run-paper.sh
```

Headless mode for a remote server:

```bash
./scripts/run-paper-headless.sh
```

An optional duration may be supplied only when a bounded test is desired:

```bash
./scripts/run-paper-headless.sh --duration 12h
```

With no duration, it runs until interrupted.

## Run persistently in tmux on Lightsail

Stop the old release first so two versions do not run simultaneously:

```bash
pgrep -af 'pm-scalper paper'
tmux ls
```

Attach to the old session and press `Ctrl+C`, or send an interrupt directly, for example:

```bash
tmux send-keys -t polymarket-v21 C-c
sleep 3
pgrep -af 'pm-scalper paper' || true
```

Start V2.2 headlessly in a detached tmux session:

```bash
tmux kill-session -t polymarket-v22 2>/dev/null || true

tmux new-session -d -s polymarket-v22 \
  "cd $HOME/cheese/pm-scalper-v2.2.0 && exec ./scripts/run-paper-headless.sh"

tmux ls
```

The process continues after SSH disconnects.

Reattach:

```bash
tmux attach -t polymarket-v22
```

Detach without stopping it:

```text
Ctrl+B, release, then D
```

## Check progress and the reasons behind decisions

```bash
cd ~/cheese/pm-scalper-v2.2.0
./scripts/progress.sh --top 30
```

Or directly:

```bash
.venv/bin/pm-scalper progress \
  --config config/default.yaml \
  --top 30
```

Automatically refresh every 30 seconds:

```bash
watch -n 30 './scripts/progress.sh --top 30'
```

Operational log:

```bash
tail -f logs/pm-scalper-v2.2.log
```

Focused decision history:

```bash
grep -Ei 'entry|taker|maker|preflight|round.trip|slippage|target|exit|cooldown|lockout|halt|reject' \
  logs/pm-scalper-v2.2.log | tail -n 300
```

Generate/export a report:

```bash
.venv/bin/pm-scalper report --config config/default.yaml
```

## Record only

Record the public feed without placing paper orders:

```bash
./scripts/record-feed.sh
```

Or for a fixed period:

```bash
./scripts/record-feed.sh --duration 2h
```

## Storage paths

V2.2 uses separate paths so its results are not mixed with V2.1:

```text
data/pm_scalper_v2_2.sqlite3
data/raw-v2.2/YYYY-MM-DD/events-<run-id>.jsonl
logs/pm-scalper-v2.2.log
exports-v2.2/<run-id>/
```

A report directory includes:

```text
summary.json
trades.csv
equity.csv
signals.csv
entry_attempts.csv
orders.csv
fills.csv
signal_outcomes.csv
missed_moves.csv
exit_requests.csv
runtime_metrics.csv
```

## How entries work

### Signal gate

The transparent V1/V2 score remains a weighted combination of:

- 15-second, 60-second, and 5-minute momentum;
- visible order-book imbalance;
- recent aggressive trade flow;
- volume acceleration;
- microprice pressure;
- spread and volatility penalties.

A score is a ranking heuristic, **not a probability of success**. The default score must reach `69` before execution is considered.

### Freshness gate

An eligible signal requires consistent, fresh quote and full-depth state. If the relevant depth is stale, the engine requests a targeted per-token CLOB refresh and recomputes the signal before continuing.

### Hybrid execution

A qualifying strong signal first evaluates the taker route. V2.2 calculates the largest impact-safe quantity through the fresh shadow book. If the taker route is unsafe, it records the reason and tries a queue-aware maker order instead.

Maker fills require later sell-side trade flow after the simulated order becomes active. Taker fills require a later authoritative depth observation after simulated latency. The snapshot used to make a decision cannot fill the order that decision created.

## How exits work

Positions can close for:

- fee-aware maker target around `+1%`;
- catastrophic executable-liquidation stop;
- persistent signal deterioration after the minimum hold;
- 4-hour maximum holding time;
- market nearing resolution;
- portfolio daily-loss kill switch;
- market resolution/settlement;
- explicit shutdown flattening only when enabled and later fresh depth exists.

Forced exits use later fresh executable bid depth. The simulator does not claim a cached fill merely because an exit was requested.

## Important limitations

- **No restart recovery:** open positions, pending orders, and in-memory rolling features are not restored after a process restart. Historical database rows remain, but a restart begins a fresh paper run. Stop or restart while flat whenever possible.
- **Public-feed simulation:** paper fills approximate what could have happened using public book/trade events. They do not guarantee identical real execution.
- **Aggressor-side assumption:** maker queue simulation treats the public trade side as aggressor direction. This should be sensitivity-tested.
- **Liquidity can vanish:** passing the pre-entry liquidation check does not guarantee the same bid depth remains later.
- **The score is unproven:** V2.2 fixes identified execution and hold-logic errors. It does not establish that the score predicts profitable moves.
- **Full-bankroll risk:** the defaults intentionally test the user’s near-all-in concept in paper mode. That makes model and event risk extreme and is not a real-money recommendation.

## Tests

```bash
.venv/bin/python -m pytest
```

The regression suite covers causality, stale-depth handling, targeted refreshes, shadow liquidity, maker queues, partial fills, fee handling, impact-safe taker sizing, immediate round-trip screening, thesis-aware exits, market loss cooldowns/lockouts, reporting, and storage migrations.

## Project layout

```text
pm-scalper-v2.2.0/
├── config/default.yaml
├── scripts/
│   ├── bootstrap.sh
│   ├── progress.sh
│   ├── record-feed.sh
│   ├── run-paper-headless.sh
│   └── run-paper.sh
├── src/pm_scalper/
├── tests/
├── CHANGELOG.md
├── LICENSE
├── README.md
└── pyproject.toml
```
