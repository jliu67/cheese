# Changelog

## 2.0.0 — 2026-08-31

### Simulator correctness

- Added monotonic receive-event sequence IDs and stored `active_after_sequence` on simulated orders and exit requests.
- Prevented queued trades received before an order existed from filling that later order.
- Added configurable maker/taker placement latency and exchange-clock-skew protection.
- Added per-price depth observation sequence and local freshness metadata.
- Added stale-depth blocking for entries, taker entries, stops, signal exits, maximum-hold exits, kill-switch exits, resolution-buffer exits, and shutdown flattening.
- Added persistent `EXIT_REQUIRED` requests that wait for later fresh executable depth rather than fabricating a fill from a cached book.
- Added a counterfactual shadow book that tracks paper-consumed liquidity per price and replenishes only demonstrated public size increases.
- Added trade-driven level invalidation so a trade that may have consumed a level makes that cached level non-executable until re-observed.
- Added transaction/event deduplication before feature and fill processing.
- Added mark equity and fee/depth-aware liquidation equity; risk controls now use liquidation equity.
- Added conservative zero value for position quantity beyond fresh visible liquidation depth by default.
- Corrected `min_order_size` validation to use outcome-share quantity.
- Added conservative default taker fees when market fee metadata is unknown.
- Changed feature chronology to local receipt order and blocked stale top-of-book outcome labels.

### Strategy and execution

- Added near-full-bankroll paper sizing with a cash buffer, one-position default, and visible-depth utilization cap.
- Added queue-aware maker pricing, bid improvement, queue-time estimates, and queue rejection diagnostics.
- Added hybrid maker/taker entry with spread, fee, tick, depth, and expected-net-target gates.
- Prevented taker entries from filling against the same cached snapshot used to make the decision.
- Added signal hysteresis with a separate lower cancellation threshold and grace period.
- Added full-size FAK-style paper risk exits with realistic partial fills and cancelled remainders.
- Added cancelled-entry missed-move watches.
- Added forward signal outcome tracking at 5m, 15m, 30m, 1h, and 4h horizons.

### Operations and reporting

- Added a fresh V2 database and data paths so corrected results are not mixed with V1.
- Added runtime metrics for queue depth, processing lag, duplicate events, pending exits, entry states, queue size, and rejection reasons.
- Added `pm-scalper progress` and `scripts/progress.sh` for live diagnostics without stopping the engine.
- Expanded CSV/JSON reports with exit requests, signal outcomes, missed moves, and runtime metrics.
- Reduced dashboard refresh pressure for browser-based SSH terminals.
- Updated bootstrap to auto-detect Python 3.11–3.13, including Ubuntu 24.04's Python 3.12.
- Added 49 offline regression/API/storage tests.

### Scope

- Remains paper-only with no wallet, signing, authentication, deposit, withdrawal, or real-order path.
- Open positions and pending orders are not resumed after a process restart; a restart begins a fresh paper run.

## 1.0.0 — 2026-08-30

- Initial public-data recorder and maker-first forward paper trader.
