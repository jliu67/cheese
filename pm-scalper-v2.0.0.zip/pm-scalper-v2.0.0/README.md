# PM-Scalper V2

PM-Scalper V2 is a **live Polymarket public-data recorder and forward paper-trading research engine** for short-horizon YES/NO contracts. It watches liquid markets, calculates a transparent short-term opportunity score, simulates queue-aware entries, aims for a tick-valid profit target around `+1%`, and records enough execution and outcome data to determine whether the idea actually has an edge.

> **Paper only.** This release cannot place a real order. It contains no wallet, private key, signing, authentication, deposit, withdrawal, or live-order code. Configuration validation rejects every execution mode except `paper`.

V2 is not a profitability claim. It is a stricter simulator and data-collection release designed to stop the paper engine from granting itself fills or liquidation prices that a simultaneously running real trader could not have received.

## What changed in V2

### Execution-correctness fixes

- **Causal event sequencing.** Every received event gets a monotonic sequence number. A trade already received before an order was created cannot fill that order later merely because it was still waiting in the processing queue.
- **Simulated placement latency.** Maker and taker orders become eligible only after their configured local activation time.
- **Stale-exit protection.** Stops, time exits, signal exits, kill-switch exits, resolution-buffer exits, and shutdown exits cannot execute against old cached depth. They enter an `EXIT_REQUIRED` state and wait for later fresh, authoritative bid depth.
- **Counterfactual shadow liquidity.** Paper-consumed depth remains consumed until the public book demonstrates actual replenishment at that price. An unrelated update or an identical repeated snapshot cannot resurrect liquidity already used by the simulator.
- **Depth-aware liquidation equity.** V2 keeps separate mark and liquidation values. Risk controls use fee- and visible-depth-aware liquidation equity; any position quantity beyond executable fresh depth is valued conservatively at the configured stale-liquidity haircut, which defaults to zero.
- **Correct minimum-order units.** `min_order_size` is enforced as outcome-share quantity rather than dollar notional.
- **Trade deduplication.** Duplicate public trade events are ignored before they can inflate flow features, consume queue twice, or create impossible fills.
- **Local-time feature chronology.** Momentum and flow histories follow event receipt order, avoiding broken deques when exchange timestamps arrive out of order.
- **Conservative unknown fees.** Missing fee metadata is not silently interpreted as fee-free. Taker economics use the configured default fee curve until authoritative metadata proves otherwise.

### Strategy and execution changes

- **Near-full-bankroll paper mode.** The default attempts to deploy 98% of available cash after a `$25` buffer.
- **One position at a time.** The default allows one active position or pending entry across the portfolio.
- **Depth cap.** Position size is capped at 50% of currently executable fresh depth, so “all bankroll” does not pretend a thin book can absorb unlimited size.
- **Hybrid entry.** Normal strong signals use a queue-aware maker order. Stronger signals may improve the bid. A taker entry is allowed only when spread, valid ticks, available ask depth, fees, and the eventual target still leave the configured positive expected net return.
- **No instant fantasy taker fill.** A new taker order is not credited against the same cached snapshot that caused the decision. It waits for a later authoritative ask-depth observation after simulated latency.
- **Signal hysteresis.** Entry requires `69+` by default, but a live order is not cancelled on a tiny momentary dip. It must remain below the lower cancellation score for the configured grace period.
- **Queue diagnostics.** V2 estimates queue seconds from recent sell flow, records average queue ahead, counts queue rejections, and watches cancelled entries to identify missed moves.
- **Forward signal labels.** Independently of order fills, V2 records what happened to fresh top-of-book prices after signals over 5 minutes, 15 minutes, 30 minutes, 1 hour, and 4 hours.
- **Built-in progress command.** Inspect score distributions, entry attempts, fill states, queue depth, processing lag, duplicate events, pending exits, missed moves, and outcome calibration without stopping the running bot.

## Default V2 behavior

```yaml
strategy:
  entry_score: 69
  entry_cancel_score: 65
  signal_fade_grace_seconds: 20
  target_return: 0.01
  stop_loss: 0.0125
  maximum_hold_seconds: 14400   # 4 hours

risk:
  starting_cash_usdc: 10000
  sizing_mode: bankroll_fraction
  bankroll_fraction: 0.98
  cash_buffer_usdc: 25
  max_open_positions: 1
  depth_utilization: 0.50

execution:
  mode: paper
  entry_style: hybrid
  maker_latency_ms: 250
  taker_latency_ms: 250
```

This does **not** guarantee that every entry uses exactly 98% of the bankroll. The final quantity is the minimum allowed by available cash, risk limits, fresh executable depth, market minimum share size, valid price ticks, and fee-aware affordability.

## Install on Ubuntu or Debian

PM-Scalper requires Python 3.11 or newer. The installer automatically selects Python 3.13, 3.12, 3.11, or a compatible `python3`.

```bash
cd pm-scalper-v2.0.0
chmod +x scripts/*.sh
./scripts/bootstrap.sh
```

Ubuntu 24.04 normally uses Python 3.12, which is supported.

If virtual-environment support is missing:

```bash
sudo apt update
sudo apt install -y python3-venv
./scripts/bootstrap.sh
```

Verify the installation:

```bash
.venv/bin/pm-scalper --version
.venv/bin/pm-scalper validate --config config/default.yaml
```

## Upgrade from V1

V2 uses a separate database, raw-data directory, and export directory:

```text
data/pm_scalper_v2.sqlite3
data/raw-v2/
exports-v2/
```

It therefore does not mix the corrected V2 paper results with V1 execution statistics. Keep V1 for reference, but run V2 from its own extracted folder.

On the remote server:

```bash
cd ~/cheese
unzip pm-scalper-v2.0.0.zip
cd pm-scalper-v2.0.0
chmod +x scripts/*.sh
./scripts/bootstrap.sh
.venv/bin/pm-scalper validate --config config/default.yaml
.venv/bin/pm-scalper discover --config config/default.yaml
```

Stop the old V1 process before starting V2 so both programs do not duplicate storage and network work:

```bash
pgrep -af 'pm-scalper paper'
```

Use `Ctrl+C` in the V1 tmux session, or terminate only the verified V1 PID.

## Check the live universe

```bash
.venv/bin/pm-scalper discover --config config/default.yaml
```

The message that some outcomes “failed live book filters” means they were rejected by liquidity, spread, price, depth, or market-time filters. It is not a program failure.

## Run continuously on Lightsail with tmux

```bash
cd ~/cheese/pm-scalper-v2.0.0

tmux new -s polymarket-v2
./scripts/run-paper.sh
```

Detach without stopping the bot:

```text
Ctrl+B, release, then D
```

Later:

```bash
tmux ls
tmux attach -t polymarket-v2
```

The Lightsail browser terminal may flicker while the Rich dashboard redraws. Detaching from tmux does not stop the engine. The reduced V2 refresh rate affects only the display, not the market-data or decision loop.

## Verify that it is working

Check the process:

```bash
pgrep -af 'pm-scalper paper'
```

Check that the raw event file is growing:

```bash
cd ~/cheese/pm-scalper-v2.0.0
watch -n 5 'du -h data/raw-v2/$(date -u +%F)/events-*.jsonl'
```

Inspect progress while the bot remains running:

```bash
.venv/bin/pm-scalper progress --config config/default.yaml
```

The progress view reports:

- minimum, average, and maximum scores;
- counts above `40`, `45`, `50`, `55`, `58`, `60`, `62`, `65`, `67`, `69`, `70`, `72`, and `75`;
- eligible samples;
- maker/taker order states and any fills;
- average queue ahead;
- event queue depth and current/maximum processing lag;
- duplicate trades ignored;
- pending fresh-depth exits;
- entry rejection reasons;
- missed moves after cancelled entries;
- score-bucket outcome labels.

## Record without paper trading

Run until `Ctrl+C`:

```bash
./scripts/record-feed.sh
```

Or record for a fixed period:

```bash
.venv/bin/pm-scalper record \
  --config config/default.yaml \
  --duration 30m
```

Raw normalized events are stored under:

```text
data/raw-v2/YYYY-MM-DD/events-<run-id>.jsonl
```

## Generate a report

For the newest run:

```bash
.venv/bin/pm-scalper report --config config/default.yaml
```

For a specific run:

```bash
.venv/bin/pm-scalper report \
  --config config/default.yaml \
  --run-id YOUR_RUN_ID
```

Exports appear under:

```text
exports-v2/<run-id>/
├── summary.json
├── trades.csv
├── equity.csv
├── signals.csv
├── orders.csv
├── fills.csv
├── exit_requests.csv
├── signal_outcomes.csv
├── missed_moves.csv
└── runtime_metrics.csv
```

## How V2 execution works

### 1. Signal

The V2 baseline score still combines:

```text
short momentum
+ multi-level book imbalance
+ recent aggressive trade flow
+ volume acceleration
+ microprice edge
- spread penalty
- short-horizon volatility penalty
```

The score is a heuristic rank, **not a probability**. A score of `70` does not mean a 70% chance of profit. Forward outcome labels are included specifically to test whether higher score buckets actually predict better future prices.

### 2. Queue-aware maker entry

A resting maker order records:

- its simulated creation time;
- its activation time after latency;
- the last event sequence already processed at creation;
- displayed shares ahead at its price;
- an estimated queue-clear time from recent opposing trade flow.

Only a qualifying trade received after both the sequence and activation gates can reduce queue ahead or fill the order. A single public trade print is shared across candidate paper orders and cannot be reused in full for each one.

### 3. Hybrid taker entry

A high score does not automatically cross the spread. V2 checks:

- current fresh ask depth;
- spread cap;
- valid tick prices;
- share minimum;
- configured taker fee curve;
- available paper cash;
- the rounded maker target after entry;
- whether the resulting target still has positive configured net economics.

Even after passing, the order waits for later fresh ask depth rather than filling against the decision snapshot.

### 4. Profit target

The target is rounded upward to the first valid tick producing at least the configured gross return. Therefore a nominal `+1%` target may be larger in a coarse-tick market. For example, `0.50 → 0.51` is a 2% gross price move.

The target is normally simulated as a maker sell. Queue-ahead logic applies to it too.

### 5. Risk exit

A stop or other forced exit does not invent a fill from stale depth. V2:

```text
trigger exit
→ cancel resting target
→ create EXIT_REQUIRED request
→ wait for later fresh authoritative bid depth
→ submit a full-position FAK-style paper sell
→ fill only the shares available in the shadow book
→ cancel the unfilled remainder
→ wait for another later fresh bid observation if shares remain
```

This can make paper losses look worse and exits slower than V1. That is intentional.

### 6. Shadow liquidity

The simulator tracks observed public depth separately from remaining counterfactual paper depth. If public size changes from 10 shares to 12 shares after the paper trader consumed 5, only the demonstrated increase of 2 can replenish the shadow book. The simulator does not restore all 12 automatically.

### 7. Mark equity versus liquidation equity

- **Mark equity:** values each open position at the displayed best bid. Useful as a conventional mark.
- **Liquidation equity:** walks currently fresh shadow bid depth, deducts taker fees, and values unfilled quantity at the configured conservative haircut.

Daily-loss and kill-switch decisions use liquidation equity.

## Forward score calibration

Every eligible tracking sample uses the fresh ask as the hypothetical entry and later fresh bids as hypothetical exits. It records target-before-stop behavior and returns after each configured horizon.

This calibration deliberately does **not** assume a maker fill. However, it is still a top-of-book signal diagnostic, not a full-bankroll executable backtest. It does not walk all future depth for each sample or model the market impact of a real large order.

## Important limitations

- Aggregate public order books do not expose exact private queue IDs, every cancellation, hidden orders, or how other participants would react to the user's order.
- V2 treats the public trade `side` field as the aggressor direction for maker-queue simulation. That is an execution-model assumption and should be sensitivity-tested.
- The universe is selected at startup and remains fixed during that run.
- No model has yet proved that the V2 score predicts profit. The outcome tables are there to test that claim.
- Near-full-bankroll sizing greatly magnifies a bad signal, news gap, thin-book exit, fee error, or venue failure. It is enabled only to paper-test the user's proposed design.
- **Open positions and pending orders are not restored into memory after a process restart.** Historical database rows remain, but each new process is a fresh paper run. Stop while flat when possible; do not interpret an interrupted run as a continuous portfolio.
- Market resolution is paper-settled at `1` or `0`; that payoff is different from ordinary CLOB liquidity.
- Maker rebates and liquidity rewards are not credited.
- Venue access, law, terms, and geographic restrictions remain the user's responsibility. This project does not implement restriction bypasses.

## Change bankroll behavior

Near-full-bankroll mode:

```yaml
risk:
  starting_cash_usdc: 10000
  sizing_mode: bankroll_fraction
  bankroll_fraction: 0.98
  cash_buffer_usdc: 25
  max_open_positions: 1
  depth_utilization: 0.50
```

Conservative fixed-size paper mode:

```yaml
risk:
  sizing_mode: fixed
  fixed_position_usdc: 1000
  max_open_positions: 1
```

Do not raise `depth_utilization` merely to force the simulator to deploy more money. The cap exists to prevent a large paper order from assuming unrealistic liquidity.

## Data layout

```text
data/pm_scalper_v2.sqlite3       corrected V2 structured database
data/raw-v2/...                  normalized live and REST events
logs/pm-scalper-v2.log              operational log
exports-v2/<run-id>/...          reports
```

## Run tests

```bash
.venv/bin/python -m pytest
```

The release suite includes regression tests for causality, stale exits, shadow liquidity, liquidation equity, minimum share size, duplicate trades, hybrid entry timing/economics, signal hysteresis, full-bankroll sizing, partial FAK exits, stale outcome labels, and report/storage behavior.

## Project layout

```text
pm-scalper-v2.0.0/
├── config/default.yaml
├── scripts/
│   ├── bootstrap.sh
│   ├── run-paper.sh
│   ├── record-feed.sh
│   └── progress.sh
├── src/pm_scalper/
│   ├── polymarket.py       public API and WebSocket clients
│   ├── book.py             observed book and per-level freshness
│   ├── shadow.py           counterfactual executable liquidity
│   ├── features.py         local-time short-horizon features
│   ├── signal.py           transparent score
│   ├── outcomes.py         forward score calibration
│   ├── paper.py            hybrid execution and risk engine
│   ├── storage.py          JSONL and SQLite persistence
│   ├── dashboard.py        terminal UI
│   ├── progress.py         live diagnostics
│   ├── report.py           CSV/JSON analytics
│   └── cli.py
└── tests/
```

## Official protocol references

- Market discovery: <https://docs.polymarket.com/market-data/discover-markets>
- Prices and order books: <https://docs.polymarket.com/market-data/prices-order-books>
- Place orders and share-size minimums: <https://docs.polymarket.com/trading/place-orders>
- Order lifecycle and FAK behavior: <https://docs.polymarket.com/concepts/order-lifecycle>
- Market WebSocket: <https://docs.polymarket.com/market-data/realtime-data>
- Trading fees: <https://docs.polymarket.com/trading/fees>
