from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from pm_scalper.book import BookStore
from pm_scalper.config import AppConfig
from pm_scalper.models import (
    Asset,
    FeatureSnapshot,
    FeeSchedule,
    PaperOrder,
    Position,
    SignalSnapshot,
    TradePrint,
)
from pm_scalper.paper import PaperBroker

BASE = 1_700_000_000.0


class FakeStore:
    def __init__(self) -> None:
        self.orders: list[tuple[str, str, str, bool, str]] = []
        self.fills = []
        self.trades = []
        self.exit_requests = []
        self.missed_moves = []

    def record_order(self, run_id, order, force=False):  # noqa: ANN001
        self.orders.append((run_id, order.id, order.status, force, order.reason))

    def record_fill(self, run_id, fill):  # noqa: ANN001
        self.fills.append(fill)

    def record_closed_trade(self, run_id, trade):  # noqa: ANN001
        self.trades.append(trade)

    def record_exit_request(self, run_id, request):  # noqa: ANN001
        self.exit_requests.append(
            (run_id, request.token_id, request.status, request.reason, request.attempts)
        )

    def record_missed_move(self, run_id, missed):  # noqa: ANN001
        self.missed_moves.append((run_id, missed.id, missed.hit_at))


def make_asset(*, fees: bool = False, token_id: str = "yes-token") -> Asset:
    return Asset(
        token_id=token_id,
        market_id="market-1",
        condition_id="0x1",
        slug="sample",
        question="Will it happen?",
        outcome="Yes",
        market_liquidity=Decimal("100000"),
        market_volume_24h=Decimal("50000"),
        end_date=None,
        fee_schedule=FeeSchedule(
            enabled=fees,
            rate=Decimal("0.07") if fees else Decimal("0"),
            exponent=Decimal("1"),
        ),
    )


def snapshot_payload(
    *,
    token_id: str = "yes-token",
    timestamp: float = BASE,
    tick: str = "0.001",
    minimum: str = "5",
    bids: list[tuple[str, str]] | None = None,
    asks: list[tuple[str, str]] | None = None,
    hash_value: str | None = None,
) -> dict[str, object]:
    payload: dict[str, object] = {
        "asset_id": token_id,
        "timestamp": str(int(timestamp * 1000)),
        "tick_size": tick,
        "min_order_size": minimum,
        "bids": [
            {"price": price, "size": size}
            for price, size in (
                bids
                if bids is not None
                else [("0.500", "10000"), ("0.499", "10000")]
            )
        ],
        "asks": [
            {"price": price, "size": size}
            for price, size in (
                asks
                if asks is not None
                else [("0.510", "10000"), ("0.511", "10000")]
            )
        ],
    }
    if hash_value is not None:
        payload["hash"] = hash_value
    return payload


def make_broker(
    *,
    fees: bool = False,
    tick: str = "0.001",
    bids: list[tuple[str, str]] | None = None,
    asks: list[tuple[str, str]] | None = None,
    minimum: str = "5",
    entry_style: str = "maker",
) -> tuple[PaperBroker, Asset, BookStore, FakeStore, list[int]]:
    config = AppConfig()
    config.risk.starting_cash_usdc = 1000
    config.risk.sizing_mode = "fixed"
    config.risk.fixed_position_usdc = 100
    config.risk.cash_buffer_usdc = 0
    config.risk.max_position_pct_equity = 1.0
    config.risk.max_total_exposure_pct_equity = 1.0
    config.risk.depth_utilization = 1.0
    config.risk.max_daily_loss_pct = 0.05
    config.execution.entry_style = entry_style
    config.execution.base_improve_bid_ticks = 1
    config.execution.aggressive_maker_score = 101
    config.execution.aggressive_improve_bid_ticks = 1
    config.execution.queue_ahead_fraction = 0.0
    config.execution.target_queue_ahead_fraction = 0.0
    config.execution.max_queue_ahead_multiple = 1000
    config.execution.maker_latency_ms = 0
    config.execution.taker_latency_ms = 0
    config.execution.max_exchange_clock_skew_seconds = 0
    config.strategy.stale_book_seconds = 10_000
    config.strategy.signal_fade_grace_seconds = 20

    asset = make_asset(fees=fees)
    books = BookStore()
    books.seed(
        snapshot_payload(
            tick=tick,
            bids=bids,
            asks=asks,
            minimum=minimum,
        ),
        BASE,
        sequence_id=10,
    )
    store = FakeStore()
    watermark = [10]
    broker = PaperBroker(
        config,
        {asset.token_id: asset},
        books,
        store,  # type: ignore[arg-type]
        "run",
        sequence_watermark=lambda: watermark[0],
    )
    return broker, asset, books, store, watermark


def make_signal(token_id: str, score: float, timestamp: float) -> SignalSnapshot:
    features = FeatureSnapshot(
        token_id=token_id,
        timestamp=timestamp,
        warmed_up=True,
        mid=0.505,
        best_bid=0.5,
        best_ask=0.51,
        spread=0.01,
        spread_pct=0.0198,
        momentum_15s=0,
        momentum_60s=0,
        momentum_300s=0,
        book_imbalance=0.5,
        trade_flow=0,
        volume_acceleration=1,
        microprice_edge=0,
        volatility_60s=0,
        bid_depth_usdc=10_000,
        ask_depth_usdc=10_000,
    )
    return SignalSnapshot(
        token_id=token_id,
        timestamp=timestamp,
        score=score,
        eligible=score >= 69,
        reason="eligible" if score >= 69 else "score below entry threshold",
        features=features,
        components={},
    )


def fill_maker_entry(
    broker: PaperBroker,
    asset: Asset,
    order: PaperOrder,
    watermark: list[int],
    *,
    timestamp: float = BASE + 2,
) -> None:
    watermark[0] += 1
    broker.on_trade(
        TradePrint(
            token_id=asset.token_id,
            price=order.limit_price,
            size=Decimal("100000"),
            side="SELL",
            timestamp=timestamp,
            transaction_hash=f"entry-{watermark[0]}",
            sequence_id=watermark[0],
            received_at=timestamp,
        )
    )


def test_maker_entry_and_target_close_profitably() -> None:
    broker, asset, books, store, watermark = make_broker()
    book = books.get(asset.token_id)
    assert book is not None

    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    assert order.execution_style == "MAKER"
    assert order.limit_price == Decimal("0.501")

    fill_maker_entry(broker, asset, order, watermark)
    assert asset.token_id in broker.positions
    target = next(
        item
        for item in broker.orders.values()
        if item.intent == "TARGET" and item.status == "OPEN"
    )
    assert target.limit_price == Decimal("0.507")

    watermark[0] += 1
    broker.on_trade(
        TradePrint(
            token_id=asset.token_id,
            price=target.limit_price,
            size=Decimal("100000"),
            side="BUY",
            timestamp=BASE + 3,
            transaction_hash="target",
            sequence_id=watermark[0],
            received_at=BASE + 3,
        )
    )
    assert asset.token_id not in broker.positions
    assert broker.closed_trades == 1
    assert broker.realized_pnl > 0
    assert broker.cash > broker.starting_cash
    assert len(store.trades) == 1
    assert store.trades[0].exit_reason == "profit target"


def test_pre_order_or_old_exchange_trade_cannot_fill_new_order() -> None:
    broker, asset, books, _, watermark = make_broker()
    broker.config.execution.max_exchange_clock_skew_seconds = 1.0
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 10)
    assert order is not None
    assert order.active_after_sequence == 10

    # This event was already received before the order existed.
    broker.on_trade(
        TradePrint(
            asset.token_id,
            order.limit_price,
            Decimal("1000"),
            "SELL",
            BASE + 9,
            "queued-old",
            sequence_id=10,
            received_at=BASE + 11,
        )
    )
    assert order.filled_quantity == 0

    # It arrived later, but its exchange timestamp clearly predates the order.
    broker.on_trade(
        TradePrint(
            asset.token_id,
            order.limit_price,
            Decimal("1000"),
            "SELL",
            BASE + 5,
            "network-old",
            sequence_id=11,
            received_at=BASE + 11,
        )
    )
    assert order.filled_quantity == 0

    watermark[0] = 12
    broker.on_trade(
        TradePrint(
            asset.token_id,
            order.limit_price,
            Decimal("1000"),
            "SELL",
            BASE + 12,
            "valid-later",
            sequence_id=12,
            received_at=BASE + 12,
        )
    )
    assert order.filled_quantity > 0


def test_minimum_order_size_is_share_quantity() -> None:
    broker, asset, books, _, _ = make_broker(
        tick="0.01",
        bids=[("0.50", "10000")],
        asks=[("0.51", "10000")],
    )
    broker.config.execution.base_improve_bid_ticks = 0
    broker.config.risk.fixed_position_usdc = 2.50
    book = books.get(asset.token_id)
    assert book is not None

    valid = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert valid is not None
    assert valid.quantity == Decimal("5.0000")

    broker._cancel_order(valid, "test", BASE + 2, track_missed=False)
    broker.config.risk.fixed_position_usdc = 2.49
    assert broker.place_entry(asset, book, 80.0, BASE + 3) is None
    assert broker.entry_rejection_counts["entry below minimum share size"] == 1


def test_queue_ahead_must_be_consumed_before_fill() -> None:
    broker, asset, books, _, watermark = make_broker()
    broker.config.execution.queue_ahead_fraction = 1.0
    broker.config.execution.base_improve_bid_ticks = 0
    broker.config.execution.max_queue_ahead_multiple = 100
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    assert order.queue_ahead == Decimal("10000")

    watermark[0] = 11
    broker.on_trade(
        TradePrint(
            asset.token_id,
            order.limit_price,
            Decimal("9999"),
            "SELL",
            BASE + 2,
            "q1",
            sequence_id=11,
            received_at=BASE + 2,
        )
    )
    assert order.filled_quantity == 0
    watermark[0] = 12
    broker.on_trade(
        TradePrint(
            asset.token_id,
            order.limit_price,
            Decimal("2"),
            "SELL",
            BASE + 3,
            "q2",
            sequence_id=12,
            received_at=BASE + 3,
        )
    )
    assert order.filled_quantity == Decimal("1")


def test_one_trade_print_volume_cannot_fill_two_orders_twice() -> None:
    broker, asset, _, _, watermark = make_broker()
    first = broker._new_order(
        asset=asset,
        side="BUY",
        intent="ENTRY",
        execution_style="MAKER",
        limit_price=Decimal("0.500"),
        quantity=Decimal("10"),
        queue_ahead=Decimal("0"),
        score=80,
        timestamp=BASE + 1,
        expires_at=None,
        reason="test",
        latency_ms=0,
    )
    second = broker._new_order(
        asset=asset,
        side="BUY",
        intent="ENTRY",
        execution_style="MAKER",
        limit_price=Decimal("0.500"),
        quantity=Decimal("10"),
        queue_ahead=Decimal("0"),
        score=80,
        timestamp=BASE + 1.1,
        expires_at=None,
        reason="test",
        latency_ms=0,
    )
    watermark[0] = 11
    broker.on_trade(
        TradePrint(
            asset.token_id,
            Decimal("0.500"),
            Decimal("15"),
            "SELL",
            BASE + 2,
            "shared-volume",
            sequence_id=11,
            received_at=BASE + 2,
        )
    )
    assert first.filled_quantity == Decimal("10")
    assert second.filled_quantity == Decimal("5")
    assert first.filled_quantity + second.filled_quantity == Decimal("15")


def test_stale_exit_waits_for_later_fresh_depth() -> None:
    broker, asset, books, store, watermark = make_broker(fees=True)
    broker.config.strategy.stale_book_seconds = 30
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    fill_maker_entry(broker, asset, order, watermark)
    assert broker.request_exit(asset.token_id, "stop loss", BASE + 3, 30.0)
    assert asset.token_id in broker.positions
    assert not store.trades

    # A later sequence carrying an already stale snapshot must not fabricate an exit.
    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 4,
            bids=[("0.490", "10000")],
            asks=[("0.500", "10000")],
            hash_value="stale",
        ),
        BASE + 4,
        sequence_id=12,
    )
    broker.on_book_update(book, BASE + 100)
    assert asset.token_id in broker.positions
    assert broker.exit_requests[asset.token_id].status == "WAITING_FRESH_DEPTH"

    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 101,
            bids=[("0.490", "10000")],
            asks=[("0.500", "10000")],
            hash_value="fresh",
        ),
        BASE + 101,
        sequence_id=13,
    )
    broker.on_book_update(book, BASE + 101)
    assert asset.token_id not in broker.positions
    assert store.trades[-1].exit_reason == "stop loss"
    assert store.trades[-1].fees > 0


def test_shadow_liquidity_is_not_restored_by_repeated_or_unrelated_updates() -> None:
    broker, asset, books, _, watermark = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    entry = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert entry is not None
    fill_maker_entry(broker, asset, entry, watermark)
    initial_quantity = broker.positions[asset.token_id].quantity

    assert broker.request_exit(asset.token_id, "partial test", BASE + 3, 30.0)
    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 4,
            bids=[("0.490", "10")],
            asks=[("0.500", "10000")],
            hash_value="partial",
        ),
        BASE + 4,
        sequence_id=12,
    )
    broker.on_book_update(book, BASE + 4)
    after_first = broker.positions[asset.token_id].quantity
    assert initial_quantity - after_first == Decimal("10")
    assert broker.shadow.available_at(asset.token_id, "BUY", Decimal("0.490")) == 0

    # A complete repeated snapshot is a fresh observation, but it does not prove
    # replenishment at the already-consumed price level.
    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 5,
            bids=[("0.490", "10")],
            asks=[("0.500", "9999")],
            hash_value="unrelated-ask",
        ),
        BASE + 5,
        sequence_id=13,
    )
    broker.on_book_update(book, BASE + 5)
    assert broker.positions[asset.token_id].quantity == after_first

    # Only the demonstrated +5 increase becomes newly available.
    book.apply_change(
        {
            "asset_id": asset.token_id,
            "side": "BUY",
            "price": "0.490",
            "size": "15",
            "hash": "real-replenishment",
        },
        BASE + 6,
        sequence_id=14,
        event_time=BASE + 6,
    )
    broker.on_book_update(book, BASE + 6)
    assert after_first - broker.positions[asset.token_id].quantity == Decimal("5")


def test_liquidation_equity_walks_depth_and_values_unfilled_quantity_at_zero() -> None:
    broker, asset, books, _, _ = make_broker(
        bids=[("0.500", "5"), ("0.450", "20"), ("0.300", "100")],
        asks=[("0.510", "10000")],
    )
    book = books.get(asset.token_id)
    assert book is not None
    broker.cash = Decimal("0")
    broker.positions[asset.token_id] = Position(
        token_id=asset.token_id,
        market_id=asset.market_id,
        outcome=asset.outcome,
        question=asset.question,
        quantity=Decimal("2000"),
        average_entry_price=Decimal("0.50"),
        entry_cost=Decimal("1000"),
        entry_fees=Decimal("0"),
        opened_at=BASE,
        entry_score=70,
        target_price=Decimal("0.51"),
    )
    proceeds, filled = broker.liquidation_quote(asset.token_id, Decimal("2000"), BASE + 1)
    expected = Decimal("5") * Decimal("0.50")
    expected += Decimal("20") * Decimal("0.45")
    expected += Decimal("100") * Decimal("0.30")
    assert proceeds == expected
    assert filled == Decimal("125")
    assert broker.mark_equity == Decimal("1000")
    # The property uses wall time; re-observe every level at wall-clock time.
    now = datetime.now(tz=timezone.utc).timestamp()
    book.apply_snapshot(
        snapshot_payload(
            timestamp=now,
            bids=[("0.500", "5"), ("0.450", "20"), ("0.300", "100")],
            asks=[("0.510", "10000")],
            hash_value="wall-fresh",
        ),
        now,
        sequence_id=20,
    )
    broker.on_book_update(book, now)
    assert broker.liquidation_equity == expected


def test_hybrid_taker_entry_waits_for_later_depth_and_then_fills() -> None:
    broker, asset, books, _, watermark = make_broker(
        tick="0.001",
        bids=[("0.500", "10000")],
        asks=[("0.501", "10000")],
        entry_style="hybrid",
    )
    broker.config.execution.taker_entry_score = 70
    broker.config.execution.max_taker_spread_pct = 0.05
    broker.config.execution.minimum_expected_net_target_return = 0.001
    book = books.get(asset.token_id)
    assert book is not None

    order = broker.place_entry(asset, book, 70.0, BASE + 1)
    assert order is not None
    assert order.execution_style == "TAKER"
    assert order.status == "PENDING"
    assert asset.token_id not in broker.positions

    watermark[0] = 11
    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 2,
            tick="0.001",
            bids=[("0.500", "10000")],
            asks=[("0.501", "10000")],
            hash_value="later-ask",
        ),
        BASE + 2,
        sequence_id=11,
    )
    broker.on_book_update(book, BASE + 2)
    assert order.filled_quantity > 0
    assert asset.token_id in broker.positions


def test_hybrid_taker_rejects_target_that_is_negative_after_fee() -> None:
    broker, asset, books, _, _ = make_broker(
        fees=True,
        tick="0.001",
        bids=[("0.500", "10000")],
        asks=[("0.501", "10000")],
        entry_style="hybrid",
    )
    broker.config.execution.taker_entry_score = 70
    broker.config.execution.max_taker_spread_pct = 0.05
    book = books.get(asset.token_id)
    assert book is not None
    assert broker.place_entry(asset, book, 70.0, BASE + 1) is None
    assert (
        broker.entry_rejection_counts["taker target is not net-positive after fees"]
        == 1
    )


def test_entry_signal_hysteresis_requires_sustained_fade() -> None:
    broker, asset, books, _, _ = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None

    low = make_signal(asset.token_id, 64.0, BASE + 2)
    broker.manage(BASE + 2, {asset.token_id: low})
    assert order.status == "OPEN"
    assert order.fade_started_at == BASE + 2

    broker.manage(BASE + 15, {asset.token_id: low})
    assert order.status == "OPEN"
    broker.manage(BASE + 23, {asset.token_id: low})
    assert order.status == "CANCELLED"
    assert order.reason == "entry signal faded after grace"


def test_bankroll_fraction_mode_sizes_nearly_the_whole_available_bankroll() -> None:
    broker, asset, books, _, _ = make_broker(
        tick="0.001",
        bids=[("0.500", "100000")],
        asks=[("0.510", "100000")],
    )
    broker.config.risk.starting_cash_usdc = 10_000
    broker.starting_cash = Decimal("10000")
    broker.cash = Decimal("10000")
    broker.day_start_equity = Decimal("10000")
    broker.config.risk.sizing_mode = "bankroll_fraction"
    broker.config.risk.bankroll_fraction = 0.98
    broker.config.risk.cash_buffer_usdc = 25
    broker.config.risk.depth_utilization = 1.0
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    notional = order.quantity * order.limit_price
    assert Decimal("9775.4") <= notional <= Decimal("9775.5")


def test_entry_queue_rejection_is_diagnosable() -> None:
    broker, asset, books, _, _ = make_broker()
    broker.config.execution.base_improve_bid_ticks = 0
    broker.config.execution.queue_ahead_fraction = 1
    broker.config.execution.max_queue_ahead_multiple = 0.1
    broker.config.execution.max_queue_rescue_ticks = 0
    book = books.get(asset.token_id)
    assert book is not None
    assert broker.place_entry(asset, book, 69.0, BASE + 1) is None
    assert broker.entry_rejection_counts["maker queue too deep or slow"] == 1
    metrics = broker.runtime_metrics(
        BASE + 2,
        queue_depth=0,
        event_processing_lag_seconds=0,
        max_event_processing_lag_seconds=0,
        duplicate_trades=0,
        received_events=10,
        processed_events=10,
    )
    assert metrics.entry_rejections["maker queue too deep or slow"] == 1


def test_entry_is_blocked_inside_resolution_buffer() -> None:
    broker, asset, books, _, _ = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    end_timestamp = BASE + 1 + broker.config.universe.min_hours_to_end * 3600 - 1
    ending_asset = replace(
        asset, end_date=datetime.fromtimestamp(end_timestamp, tz=timezone.utc)
    )
    allowed, reason = broker.can_enter(ending_asset, book, BASE + 1)
    assert not allowed
    assert reason == "market too close to resolution"


def test_market_resolution_settles_winner_and_blocks_reentry() -> None:
    broker, asset, books, store, watermark = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    fill_maker_entry(broker, asset, order, watermark)

    broker.on_market_resolved([asset.token_id, "no-token"], asset.token_id, BASE + 3)
    assert asset.token_id not in broker.positions
    assert asset.token_id in broker.resolved_tokens
    assert store.trades[-1].average_exit_price == Decimal("1")
    allowed, reason = broker.can_enter(asset, book, BASE + 4)
    assert not allowed
    assert reason == "market resolved"


def test_market_resolution_settles_loser_at_zero() -> None:
    broker, asset, books, store, watermark = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    fill_maker_entry(broker, asset, order, watermark)

    broker.on_market_resolved([asset.token_id, "no-token"], "no-token", BASE + 3)
    assert asset.token_id not in broker.positions
    assert store.trades[-1].average_exit_price == Decimal("0")
    assert store.trades[-1].net_pnl < 0


def test_tick_size_or_minimum_share_change_cancels_invalid_entry() -> None:
    broker, asset, books, _, _ = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert order is not None
    assert order.limit_price == Decimal("0.501")

    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 2,
            tick="0.01",
            minimum="1000",
            bids=[("0.50", "10000")],
            asks=[("0.51", "10000")],
            hash_value="constraints",
        ),
        BASE + 2,
        sequence_id=11,
    )
    broker.manage(BASE + 2, {asset.token_id: make_signal(asset.token_id, 80, BASE + 2)})
    assert order.status == "CANCELLED"
    assert order.reason in {
        "entry price invalid after tick-size change",
        "entry below updated minimum share size",
    }


def test_daily_kill_switch_uses_liquidation_equity() -> None:
    broker, asset, books, _, _ = make_broker(
        bids=[("0.500", "5"), ("0.300", "10")],
        asks=[("0.510", "10000")],
    )
    broker.config.risk.max_daily_loss_pct = 0.05
    broker.risk_day = datetime.fromtimestamp(BASE, tz=timezone.utc).date().isoformat()
    broker.day_start_equity = Decimal("1000")
    broker.cash = Decimal("0")
    broker.positions[asset.token_id] = Position(
        token_id=asset.token_id,
        market_id=asset.market_id,
        outcome=asset.outcome,
        question=asset.question,
        quantity=Decimal("2000"),
        average_entry_price=Decimal("0.5"),
        entry_cost=Decimal("1000"),
        entry_fees=Decimal("0"),
        opened_at=BASE,
        entry_score=70,
        target_price=Decimal("0.51"),
    )
    # Keep every executable bid level fresh at wall-clock time for the risk mark.
    book = books.get(asset.token_id)
    assert book is not None
    now = datetime.now(tz=timezone.utc).timestamp()
    book.apply_snapshot(
        snapshot_payload(
            timestamp=now,
            bids=[("0.500", "5"), ("0.300", "10")],
            asks=[("0.510", "10000")],
            hash_value="kill-switch-fresh",
        ),
        now,
        sequence_id=20,
    )
    broker.on_book_update(book, now)
    broker.manage(BASE + 1, {})
    assert broker.halted
    assert broker.halt_reason == "daily loss limit reached"
    assert asset.token_id in broker.exit_requests


def test_unrelated_ask_update_cannot_unlock_stale_bid_for_exit() -> None:
    broker, asset, books, store, watermark = make_broker()
    book = books.get(asset.token_id)
    assert book is not None
    entry = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert entry is not None
    fill_maker_entry(broker, asset, entry, watermark)
    initial_quantity = broker.positions[asset.token_id].quantity

    assert broker.request_exit(asset.token_id, "stop loss", BASE + 3, 30.0)
    watermark[0] = 12
    # Only the ask side is re-observed. The cached 0.500 bid must not become
    # executable merely because an unrelated side of the book changed.
    book.apply_change(
        {"side": "SELL", "price": "0.600", "size": "10"},
        BASE + 4,
        sequence_id=12,
        event_time=BASE + 4,
    )
    broker.on_book_update(book, BASE + 4)
    assert broker.positions[asset.token_id].quantity == initial_quantity
    assert broker.exit_requests[asset.token_id].status == "WAITING_FRESH_DEPTH"

    watermark[0] = 13
    book.apply_change(
        {"side": "BUY", "price": "0.500", "size": "10000"},
        BASE + 5,
        sequence_id=13,
        event_time=BASE + 5,
    )
    broker.on_book_update(book, BASE + 5)
    assert asset.token_id not in broker.positions
    assert store.trades[-1].exit_reason == "stop loss"


def test_risk_exit_submits_valid_full_size_fak_before_partial_fill() -> None:
    broker, asset, books, _, watermark = make_broker(minimum="5")
    book = books.get(asset.token_id)
    assert book is not None
    entry = broker.place_entry(asset, book, 80.0, BASE + 1)
    assert entry is not None
    fill_maker_entry(broker, asset, entry, watermark)
    original_quantity = broker.positions[asset.token_id].quantity

    assert broker.request_exit(asset.token_id, "partial exit", BASE + 3, 30.0)
    watermark[0] = 12
    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 4,
            bids=[("0.490", "1")],
            asks=[("0.500", "10000")],
            hash_value="one-share-fresh",
        ),
        BASE + 4,
        sequence_id=12,
    )
    broker.on_book_update(book, BASE + 4)

    risk_order = next(
        order for order in broker.orders.values() if order.intent == "RISK_EXIT"
    )
    assert risk_order.quantity == original_quantity
    assert risk_order.filled_quantity == Decimal("1")
    assert risk_order.status == "CANCELLED"
    assert broker.positions[asset.token_id].quantity == original_quantity - Decimal("1")


def test_pending_taker_rechecks_economics_before_fill() -> None:
    broker, asset, books, _, watermark = make_broker(
        tick="0.001",
        bids=[("0.500", "10000")],
        asks=[("0.501", "10000")],
        entry_style="hybrid",
    )
    broker.config.execution.taker_entry_score = 70
    broker.config.execution.minimum_expected_net_target_return = 0.001
    book = books.get(asset.token_id)
    assert book is not None
    order = broker.place_entry(asset, book, 70.0, BASE + 1)
    assert order is not None and order.status == "PENDING"

    # The strategy's economics requirement can tighten while the simulated order is
    # in flight. V2 must check it again against the later authoritative ask depth.
    broker.config.execution.minimum_expected_net_target_return = 0.50
    watermark[0] = 11
    book.apply_snapshot(
        snapshot_payload(
            timestamp=BASE + 2,
            tick="0.001",
            bids=[("0.500", "10000")],
            asks=[("0.501", "10000")],
            hash_value="later-economics",
        ),
        BASE + 2,
        sequence_id=11,
    )
    broker.on_book_update(book, BASE + 2)
    assert order.status == "CANCELLED"
    assert order.filled_quantity == 0
    assert order.reason == "taker economics deteriorated before activation"


def test_unknown_fee_metadata_uses_conservative_default_taker_fee() -> None:
    broker, asset, _, _, _ = make_broker()
    unknown = replace(
        asset,
        fee_schedule=FeeSchedule(
            known=False,
            enabled=True,
            rate=Decimal("0"),
            exponent=Decimal("1"),
        ),
    )
    quantity = Decimal("100")
    price = Decimal("0.50")
    fee = broker._fee(unknown, quantity, price, maker=False)
    assert fee == Decimal("1.75000")
    assert broker._fee(unknown, quantity, price, maker=True) == 0
