from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Any

from .util import ZERO


@dataclass(slots=True, frozen=True)
class FeeSchedule:
    # ``known`` distinguishes an explicitly fee-free market from a compact API
    # record whose fee metadata was unavailable. Unknown taker fees are treated
    # conservatively by the paper broker instead of silently assuming zero.
    known: bool = True
    enabled: bool = False
    rate: Decimal = ZERO
    exponent: Decimal = Decimal("1")
    taker_only: bool = True
    rebate_rate: Decimal = ZERO


@dataclass(slots=True)
class Market:
    id: str
    condition_id: str
    slug: str
    question: str
    outcomes: list[str]
    token_ids: list[str]
    active: bool
    closed: bool
    accepting_orders: bool
    enable_order_book: bool
    liquidity: Decimal
    volume_24h: Decimal
    best_bid: Decimal | None
    best_ask: Decimal | None
    spread: Decimal | None
    last_trade_price: Decimal | None
    one_day_price_change: Decimal | None
    end_date: datetime | None
    seconds_delay: int
    minimum_tick_size: Decimal | None
    minimum_order_size: Decimal | None
    fee_schedule: FeeSchedule
    raw: dict[str, Any] = field(default_factory=dict, repr=False)


@dataclass(slots=True, frozen=True)
class Asset:
    token_id: str
    market_id: str
    condition_id: str
    slug: str
    question: str
    outcome: str
    market_liquidity: Decimal
    market_volume_24h: Decimal
    end_date: datetime | None
    fee_schedule: FeeSchedule

    @property
    def label(self) -> str:
        return f"{self.outcome}: {self.question}"


@dataclass(slots=True, frozen=True)
class EventEnvelope:
    sequence_id: int
    received_at: float
    payload: dict[str, Any]


@dataclass(slots=True, frozen=True)
class TradePrint:
    token_id: str
    price: Decimal
    size: Decimal
    side: str
    timestamp: float
    transaction_hash: str | None = None
    sequence_id: int = 0
    received_at: float = 0.0

    @property
    def notional(self) -> Decimal:
        return self.price * self.size


@dataclass(slots=True)
class FeatureSnapshot:
    token_id: str
    timestamp: float
    warmed_up: bool
    mid: float
    best_bid: float
    best_ask: float
    spread: float
    spread_pct: float
    momentum_15s: float
    momentum_60s: float
    momentum_300s: float
    book_imbalance: float
    trade_flow: float
    volume_acceleration: float
    microprice_edge: float
    volatility_60s: float
    bid_depth_usdc: float
    ask_depth_usdc: float
    buy_volume_60s_shares: float = 0.0
    sell_volume_60s_shares: float = 0.0
    trade_volume_60s_usdc: float = 0.0

    def as_dict(self) -> dict[str, float | bool | str]:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "warmed_up": self.warmed_up,
            "mid": self.mid,
            "best_bid": self.best_bid,
            "best_ask": self.best_ask,
            "spread": self.spread,
            "spread_pct": self.spread_pct,
            "momentum_15s": self.momentum_15s,
            "momentum_60s": self.momentum_60s,
            "momentum_300s": self.momentum_300s,
            "book_imbalance": self.book_imbalance,
            "trade_flow": self.trade_flow,
            "volume_acceleration": self.volume_acceleration,
            "microprice_edge": self.microprice_edge,
            "volatility_60s": self.volatility_60s,
            "bid_depth_usdc": self.bid_depth_usdc,
            "ask_depth_usdc": self.ask_depth_usdc,
            "buy_volume_60s_shares": self.buy_volume_60s_shares,
            "sell_volume_60s_shares": self.sell_volume_60s_shares,
            "trade_volume_60s_usdc": self.trade_volume_60s_usdc,
        }


@dataclass(slots=True)
class SignalSnapshot:
    token_id: str
    timestamp: float
    score: float
    eligible: bool
    reason: str
    features: FeatureSnapshot
    components: dict[str, float]


@dataclass(slots=True)
class PaperOrder:
    id: str
    token_id: str
    market_id: str
    outcome: str
    side: str
    intent: str
    execution_style: str
    limit_price: Decimal
    quantity: Decimal
    filled_quantity: Decimal
    average_fill_price: Decimal
    queue_ahead: Decimal
    created_at: float
    active_at: float
    active_after_sequence: int
    expires_at: float | None
    status: str
    score_at_creation: float
    reason: str
    estimated_queue_seconds: float | None = None
    fade_started_at: float | None = None

    @property
    def remaining_quantity(self) -> Decimal:
        return max(ZERO, self.quantity - self.filled_quantity)

    @property
    def reserved_notional(self) -> Decimal:
        if self.side != "BUY" or self.status not in {"OPEN", "PARTIAL", "PENDING"}:
            return ZERO
        return self.remaining_quantity * self.limit_price


@dataclass(slots=True)
class Position:
    token_id: str
    market_id: str
    outcome: str
    question: str
    quantity: Decimal
    average_entry_price: Decimal
    entry_cost: Decimal
    entry_fees: Decimal
    opened_at: float
    entry_score: float
    target_price: Decimal
    target_order_id: str | None = None
    peak_bid: Decimal = ZERO
    last_score: float = 50.0


@dataclass(slots=True)
class ExitRequest:
    token_id: str
    reason: str
    requested_at: float
    exit_score: float
    active_after_sequence: int
    active_at: float
    status: str = "WAITING_FRESH_DEPTH"
    attempts: int = 0
    last_attempt_at: float | None = None


@dataclass(slots=True)
class Fill:
    id: str
    order_id: str
    token_id: str
    side: str
    intent: str
    quantity: Decimal
    price: Decimal
    fee: Decimal
    maker: bool
    timestamp: float
    sequence_id: int = 0


@dataclass(slots=True)
class ClosedTrade:
    id: str
    token_id: str
    market_id: str
    outcome: str
    question: str
    opened_at: float
    closed_at: float
    quantity: Decimal
    average_entry_price: Decimal
    average_exit_price: Decimal
    gross_pnl: Decimal
    fees: Decimal
    net_pnl: Decimal
    return_pct: Decimal
    exit_reason: str
    entry_score: float
    exit_score: float


@dataclass(slots=True)
class SignalOutcome:
    id: str
    token_id: str
    market_id: str
    outcome: str
    question: str
    created_at: float
    score: float
    entry_ask: Decimal
    initial_bid: Decimal
    target_price: Decimal
    stop_price: Decimal
    first_barrier: str | None = None
    barrier_at: float | None = None
    max_bid: Decimal = ZERO
    min_bid: Decimal = Decimal("1")
    horizon_returns: dict[int, float | None] = field(default_factory=dict)
    completed: bool = False


@dataclass(slots=True)
class MissedMove:
    id: str
    token_id: str
    market_id: str
    outcome: str
    question: str
    order_id: str
    cancelled_at: float
    entry_price: Decimal
    target_price: Decimal
    score: float
    expires_at: float
    hit_at: float | None = None


@dataclass(slots=True)
class RuntimeMetrics:
    timestamp: float
    queue_depth: int = 0
    event_processing_lag_seconds: float = 0.0
    max_event_processing_lag_seconds: float = 0.0
    duplicate_trades: int = 0
    received_events: int = 0
    processed_events: int = 0
    max_score_seen: float = 0.0
    eligible_signals: int = 0
    entry_attempts: int = 0
    entry_orders: int = 0
    maker_entry_orders: int = 0
    taker_entry_orders: int = 0
    filled_entry_orders: int = 0
    cancelled_entry_orders: int = 0
    pending_exits: int = 0
    missed_moves: int = 0
    average_queue_ahead: float = 0.0
    entry_rejections: dict[str, int] = field(default_factory=dict)
