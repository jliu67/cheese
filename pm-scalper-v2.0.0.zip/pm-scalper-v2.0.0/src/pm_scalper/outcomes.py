from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Mapping

from .book import BookStore, OrderBook
from .config import AppConfig
from .models import Asset, SignalOutcome, SignalSnapshot
from .storage import SQLiteStore
from .util import ONE, ceil_to_tick, floor_to_tick


class SignalOutcomeTracker:
    """Forward-label signal quality independently of whether an order filled.

    Each sample assumes an immediately executable entry at the current ask and an
    immediately executable future exit at the bid. This intentionally includes the
    spread and avoids granting the strategy a maker fill it may never receive.
    """

    def __init__(
        self,
        config: AppConfig,
        assets: Mapping[str, Asset],
        books: BookStore,
        store: SQLiteStore,
        run_id: str,
    ) -> None:
        self.config = config
        self.assets = dict(assets)
        self.books = books
        self.store = store
        self.run_id = run_id
        self.samples: dict[str, SignalOutcome] = {}
        self.last_sample_at: dict[str, float] = {}

    def observe_signals(
        self, signals: Mapping[str, SignalSnapshot], timestamp: float
    ) -> None:
        for signal in signals.values():
            if signal.score < self.config.strategy.outcome_tracking_min_score:
                continue
            if (
                timestamp - self.last_sample_at.get(signal.token_id, float("-inf"))
                < self.config.strategy.outcome_tracking_cooldown_seconds
            ):
                continue
            asset = self.assets.get(signal.token_id)
            book = self.books.get(signal.token_id)
            if (
                asset is None
                or book is None
                or book.best_bid is None
                or book.best_ask is None
                or book.best_ask <= book.best_bid
                or not book.top_is_fresh(
                    "BUY", timestamp, self.config.strategy.stale_book_seconds
                )
                or not book.top_is_fresh(
                    "SELL", timestamp, self.config.strategy.stale_book_seconds
                )
            ):
                continue
            entry = book.best_ask
            target = min(
                ONE - book.tick_size,
                ceil_to_tick(
                    entry * (ONE + Decimal(str(self.config.strategy.target_return))),
                    book.tick_size,
                ),
            )
            stop = max(
                book.tick_size,
                floor_to_tick(
                    entry * (ONE - Decimal(str(self.config.strategy.stop_loss))),
                    book.tick_size,
                ),
            )
            horizons = {
                int(value): None for value in self.config.strategy.outcome_horizons_seconds
            }
            sample = SignalOutcome(
                id=uuid.uuid4().hex,
                token_id=asset.token_id,
                market_id=asset.market_id,
                outcome=asset.outcome,
                question=asset.question,
                created_at=timestamp,
                score=signal.score,
                entry_ask=entry,
                initial_bid=book.best_bid,
                target_price=target,
                stop_price=stop,
                max_bid=book.best_bid,
                min_bid=book.best_bid,
                horizon_returns=horizons,
            )
            self.samples[sample.id] = sample
            self.last_sample_at[signal.token_id] = timestamp
            self.store.record_signal_outcome(self.run_id, sample)

    def on_book(self, book: OrderBook, timestamp: float) -> None:
        bid = book.best_bid
        if (
            bid is None
            or not book.top_is_fresh(
                "BUY", timestamp, self.config.strategy.stale_book_seconds
            )
        ):
            return
        max_horizon = max(self.config.strategy.outcome_horizons_seconds)
        for sample_id, sample in list(self.samples.items()):
            if sample.token_id != book.token_id or sample.completed:
                continue
            changed = False
            if bid > sample.max_bid:
                sample.max_bid = bid
                changed = True
            if bid < sample.min_bid:
                sample.min_bid = bid
                changed = True
            if sample.first_barrier is None:
                if bid >= sample.target_price:
                    sample.first_barrier = "TARGET"
                    sample.barrier_at = timestamp
                    changed = True
                elif bid <= sample.stop_price:
                    sample.first_barrier = "STOP"
                    sample.barrier_at = timestamp
                    changed = True
            for horizon in sample.horizon_returns:
                if sample.horizon_returns[horizon] is not None:
                    continue
                if timestamp >= sample.created_at + horizon:
                    sample.horizon_returns[horizon] = float(bid / sample.entry_ask - ONE)
                    changed = True
            if timestamp >= sample.created_at + max_horizon and all(
                value is not None for value in sample.horizon_returns.values()
            ):
                sample.completed = True
                changed = True
            if changed:
                self.store.record_signal_outcome(self.run_id, sample)
            if sample.completed:
                self.samples.pop(sample_id, None)

    @property
    def active_count(self) -> int:
        return len(self.samples)
