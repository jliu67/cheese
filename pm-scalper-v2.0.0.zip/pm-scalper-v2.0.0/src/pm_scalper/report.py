from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table

from .config import AppConfig
from .storage import SQLiteStore, write_csv
from .util import fmt_money, json_dumps

CONSOLE = Console()
ZERO = Decimal("0")


def generate_report(config: AppConfig, run_id: str | None = None) -> Path:
    store = SQLiteStore(config)
    try:
        selected_run = run_id or store.latest_run_id()
        if not selected_run:
            raise RuntimeError("No PM-Scalper V2 runs exist in the configured database")
        run_rows = store.fetch_all("SELECT * FROM runs WHERE run_id=?", (selected_run,))
        if not run_rows:
            raise RuntimeError(f"Run not found: {selected_run}")
        run = dict(run_rows[0])
        trades = store.fetch_all(
            "SELECT * FROM closed_trades WHERE run_id=? ORDER BY closed_at", (selected_run,)
        )
        equity_rows = store.fetch_all(
            "SELECT * FROM equity WHERE run_id=? ORDER BY timestamp", (selected_run,)
        )
        signals = store.fetch_all(
            "SELECT * FROM signals WHERE run_id=? ORDER BY timestamp", (selected_run,)
        )
        orders = store.fetch_all(
            "SELECT * FROM orders WHERE run_id=? ORDER BY created_at", (selected_run,)
        )
        fills = store.fetch_all(
            "SELECT * FROM fills WHERE run_id=? ORDER BY timestamp", (selected_run,)
        )
        outcomes = store.fetch_all(
            "SELECT * FROM signal_outcomes WHERE run_id=? ORDER BY created_at", (selected_run,)
        )
        missed = store.fetch_all(
            "SELECT * FROM missed_moves WHERE run_id=? ORDER BY cancelled_at", (selected_run,)
        )
        exits = store.fetch_all(
            "SELECT * FROM exit_requests WHERE run_id=? ORDER BY requested_at", (selected_run,)
        )
        runtime = store.fetch_all(
            "SELECT * FROM runtime_metrics WHERE run_id=? ORDER BY timestamp", (selected_run,)
        )

        export_root = Path(config.storage.export_dir) / selected_run
        export_root.mkdir(parents=True, exist_ok=True)
        artifacts = {
            "trades_csv": export_root / "trades.csv",
            "equity_csv": export_root / "equity.csv",
            "signals_csv": export_root / "signals.csv",
            "orders_csv": export_root / "orders.csv",
            "fills_csv": export_root / "fills.csv",
            "signal_outcomes_csv": export_root / "signal_outcomes.csv",
            "missed_moves_csv": export_root / "missed_moves.csv",
            "exit_requests_csv": export_root / "exit_requests.csv",
            "runtime_metrics_csv": export_root / "runtime_metrics.csv",
        }
        for path, rows in [
            (artifacts["trades_csv"], trades),
            (artifacts["equity_csv"], equity_rows),
            (artifacts["signals_csv"], signals),
            (artifacts["orders_csv"], orders),
            (artifacts["fills_csv"], fills),
            (artifacts["signal_outcomes_csv"], outcomes),
            (artifacts["missed_moves_csv"], missed),
            (artifacts["exit_requests_csv"], exits),
            (artifacts["runtime_metrics_csv"], runtime),
        ]:
            write_csv(path, rows)

        net_values = [Decimal(row["net_pnl"]) for row in trades]
        return_values = [Decimal(row["return_pct"]) for row in trades]
        fee_values = [Decimal(row["fee"]) for row in fills]
        gross_profit = sum((value for value in net_values if value > ZERO), ZERO)
        gross_loss = -sum((value for value in net_values if value < ZERO), ZERO)
        wins = sum(1 for value in net_values if value > ZERO)
        losses = sum(1 for value in net_values if value <= ZERO)
        realized_net_pnl = sum(net_values, ZERO)
        total_fees = sum(fee_values, ZERO)
        average_return = (
            sum(return_values, ZERO) / Decimal(len(return_values))
            if return_values
            else ZERO
        )
        profit_factor = float(gross_profit / gross_loss) if gross_loss > ZERO else None

        liquidation_values = [Decimal(row["liquidation_equity"]) for row in equity_rows]
        mark_values = [Decimal(row["mark_equity"]) for row in equity_rows]
        try:
            stored_config = json.loads(run.get("config_json") or "{}")
            stored_starting_cash = stored_config["risk"]["starting_cash_usdc"]
        except (json.JSONDecodeError, KeyError, TypeError):
            stored_starting_cash = config.risk.starting_cash_usdc
        starting_equity = Decimal(str(stored_starting_cash))
        ending_liquidation_equity = (
            liquidation_values[-1] if liquidation_values else starting_equity
        )
        ending_mark_equity = mark_values[-1] if mark_values else starting_equity
        session_net_pnl = ending_liquidation_equity - starting_equity
        max_liquidation_drawdown = calculate_max_drawdown(
            [starting_equity, *liquidation_values]
        )
        max_mark_drawdown = calculate_max_drawdown([starting_equity, *mark_values])

        entry_orders = [row for row in orders if row["intent"] == "ENTRY"]
        filled_entries = sum(
            1 for row in entry_orders if Decimal(row["filled_quantity"]) > ZERO
        )
        fill_rate = filled_entries / len(entry_orders) if entry_orders else 0.0
        maker_entries = sum(
            1 for row in entry_orders if row["execution_style"] == "MAKER"
        )
        taker_entries = sum(
            1 for row in entry_orders if row["execution_style"] == "TAKER"
        )
        duplicate_trades = int(runtime[-1]["duplicate_trades"]) if runtime else 0
        max_processing_lag = (
            max(float(row["max_event_processing_lag_seconds"]) for row in runtime)
            if runtime
            else 0.0
        )
        outcome_summary = summarize_signal_outcomes(outcomes)

        summary: dict[str, Any] = {
            "run": run,
            "metrics": {
                "starting_equity": str(starting_equity),
                "ending_liquidation_equity": str(ending_liquidation_equity),
                "ending_mark_equity": str(ending_mark_equity),
                "net_pnl": str(session_net_pnl),
                "realized_net_pnl": str(realized_net_pnl),
                "total_fees": str(total_fees),
                "closed_trades": len(trades),
                "wins": wins,
                "losses": losses,
                "win_rate": wins / len(trades) if trades else 0.0,
                "average_trade_return": str(average_return),
                "profit_factor": profit_factor,
                "max_liquidation_drawdown": max_liquidation_drawdown,
                "max_mark_drawdown": max_mark_drawdown,
                "entry_orders": len(entry_orders),
                "maker_entry_orders": maker_entries,
                "taker_entry_orders": taker_entries,
                "entry_fill_rate": fill_rate,
                "fills": len(fills),
                "signal_samples": len(signals),
                "signal_outcome_samples": len(outcomes),
                "missed_move_hits": sum(1 for row in missed if row["hit_at"] is not None),
                "duplicate_trades_ignored": duplicate_trades,
                "max_event_processing_lag_seconds": max_processing_lag,
            },
            "signal_calibration": outcome_summary,
            "artifacts": {key: str(value) for key, value in artifacts.items()},
        }
        summary_path = export_root / "summary.json"
        summary_path.write_text(
            json_dumps(summary, compact=False) + "\n", encoding="utf-8"
        )
        print_summary(summary, selected_run, summary_path)
        return summary_path
    finally:
        store.close()


def summarize_signal_outcomes(rows: list[Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    buckets = [(40, 50), (50, 55), (55, 60), (60, 65), (65, 69), (69, 101)]
    for low, high in buckets:
        selected = [row for row in rows if low <= float(row["score"]) < high]
        target = sum(1 for row in selected if row["first_barrier"] == "TARGET")
        stop = sum(1 for row in selected if row["first_barrier"] == "STOP")
        returns: dict[str, list[float]] = {}
        for row in selected:
            try:
                payload = json.loads(row["horizon_returns_json"])
            except (json.JSONDecodeError, TypeError):
                continue
            for horizon, value in payload.items():
                if value is not None:
                    returns.setdefault(str(horizon), []).append(float(value))
        averages = {
            horizon: sum(values) / len(values)
            for horizon, values in returns.items()
            if values
        }
        label = f"{low}-{high - 1}" if high < 101 else "69+"
        result[label] = {
            "samples": len(selected),
            "target_first": target,
            "stop_first": stop,
            "target_first_rate_of_decided": (
                target / (target + stop) if target + stop else None
            ),
            "average_top_of_book_returns": averages,
        }
    return result


def calculate_max_drawdown(values: list[Decimal]) -> float:
    if not values:
        return 0.0
    peak = values[0]
    worst = Decimal("0")
    for value in values:
        peak = max(peak, value)
        if peak > ZERO:
            drawdown = value / peak - Decimal("1")
            worst = min(worst, drawdown)
    return float(worst)


def print_summary(summary: dict[str, Any], run_id: str, path: Path) -> None:
    metrics = summary["metrics"]
    table = Table(title=f"PM-Scalper V2 report — {run_id}")
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    table.add_row("Starting equity", fmt_money(Decimal(metrics["starting_equity"])))
    table.add_row(
        "Ending liquidation equity",
        fmt_money(Decimal(metrics["ending_liquidation_equity"])),
    )
    table.add_row("Ending mark equity", fmt_money(Decimal(metrics["ending_mark_equity"])))
    table.add_row("Session net P&L", fmt_money(Decimal(metrics["net_pnl"])))
    table.add_row("Realized net P&L", fmt_money(Decimal(metrics["realized_net_pnl"])))
    table.add_row("Closed trades", str(metrics["closed_trades"]))
    table.add_row("Win rate", f"{metrics['win_rate'] * 100:.1f}%")
    table.add_row(
        "Average trade return",
        f"{Decimal(metrics['average_trade_return']) * 100:.3f}%",
    )
    table.add_row(
        "Profit factor",
        "—" if metrics["profit_factor"] is None else f"{metrics['profit_factor']:.2f}",
    )
    table.add_row(
        "Maximum liquidation drawdown",
        f"{metrics['max_liquidation_drawdown'] * 100:.2f}%",
    )
    table.add_row("Entry fill rate", f"{metrics['entry_fill_rate'] * 100:.1f}%")
    table.add_row(
        "Maker / taker entries",
        f"{metrics['maker_entry_orders']} / {metrics['taker_entry_orders']}",
    )
    table.add_row("Fees", fmt_money(Decimal(metrics["total_fees"])))
    table.add_row(
        "Ignored duplicate trades", str(metrics["duplicate_trades_ignored"])
    )
    table.add_row(
        "Max processing lag",
        f"{metrics['max_event_processing_lag_seconds']:.3f}s",
    )
    CONSOLE.print(table)
    CONSOLE.print(f"Report files: [bold]{path.parent}[/bold]")
