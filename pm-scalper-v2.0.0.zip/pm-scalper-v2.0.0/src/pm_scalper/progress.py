from __future__ import annotations

import json
from decimal import Decimal
from typing import Any

from rich.console import Console
from rich.table import Table

from .config import AppConfig
from .storage import SQLiteStore
from .util import fmt_money

CONSOLE = Console()


def show_progress(config: AppConfig, run_id: str | None = None) -> None:
    store = SQLiteStore(config)
    try:
        selected = run_id or store.latest_run_id(running_only=True) or store.latest_run_id()
        if not selected:
            raise RuntimeError("No PM-Scalper V2 runs exist in the configured database")
        run_rows = store.fetch_all("SELECT * FROM runs WHERE run_id=?", (selected,))
        if not run_rows:
            raise RuntimeError(f"Run not found: {selected}")
        run = run_rows[0]

        overview = Table(title=f"PM-Scalper V2 progress — {selected}")
        overview.add_column("Metric")
        overview.add_column("Value", justify="right")
        overview.add_row("Status", str(run["status"]))
        overview.add_row("Started", str(run["started_at"]))
        overview.add_row("Finished", str(run["finished_at"] or "—"))

        signal = store.fetch_all(
            """
            SELECT COUNT(*) n, MIN(score) min_score, AVG(score) avg_score, MAX(score) max_score,
                   SUM(eligible) eligible
            FROM signals WHERE run_id=?
            """,
            (selected,),
        )[0]
        overview.add_row("Signal samples", f"{int(signal['n'] or 0):,}")
        overview.add_row(
            "Score min / avg / max",
            "—"
            if signal["n"] == 0
            else f"{signal['min_score']:.2f} / {signal['avg_score']:.2f} / {signal['max_score']:.2f}",
        )
        overview.add_row("Eligible signal samples", f"{int(signal['eligible'] or 0):,}")

        latest_equity = store.fetch_all(
            "SELECT * FROM equity WHERE run_id=? ORDER BY timestamp DESC LIMIT 1",
            (selected,),
        )
        if latest_equity:
            equity = latest_equity[0]
            overview.add_row(
                "Liquidation / mark equity",
                f"{fmt_money(Decimal(equity['liquidation_equity']))} / "
                f"{fmt_money(Decimal(equity['mark_equity']))}",
            )
            overview.add_row("Cash", fmt_money(Decimal(equity["cash"])))
            overview.add_row("Open positions", str(equity["open_positions"]))

        trades = store.fetch_all(
            """
            SELECT COUNT(*) n, COALESCE(SUM(CAST(net_pnl AS REAL)),0) pnl,
                   COALESCE(AVG(CAST(return_pct AS REAL)),0) avg_return,
                   SUM(CASE WHEN CAST(net_pnl AS REAL)>0 THEN 1 ELSE 0 END) wins
            FROM closed_trades WHERE run_id=?
            """,
            (selected,),
        )[0]
        overview.add_row("Closed trades", str(trades["n"]))
        overview.add_row("Closed-trade P&L", fmt_money(Decimal(str(trades["pnl"]))))
        if trades["n"]:
            overview.add_row(
                "Win rate / avg return",
                f"{100 * trades['wins'] / trades['n']:.1f}% / "
                f"{100 * trades['avg_return']:.3f}%",
            )
        CONSOLE.print(overview)

        thresholds = Table(title="Score distribution")
        thresholds.add_column("Threshold", justify="right")
        thresholds.add_column("Samples", justify="right")
        for threshold in [40, 45, 50, 55, 58, 60, 62, 65, 67, 69, 70, 72, 75]:
            count = store.fetch_all(
                "SELECT COUNT(*) n FROM signals WHERE run_id=? AND score>=?",
                (selected, threshold),
            )[0]["n"]
            thresholds.add_row(f"{threshold}+", f"{count:,}")
        CONSOLE.print(thresholds)

        order_rows = store.fetch_all(
            """
            SELECT intent, execution_style, status, COUNT(*) n,
                   SUM(CASE WHEN CAST(filled_quantity AS REAL)>0 THEN 1 ELSE 0 END) touched,
                   AVG(CAST(queue_ahead AS REAL)) avg_queue
            FROM orders WHERE run_id=?
            GROUP BY intent, execution_style, status
            ORDER BY intent, execution_style, status
            """,
            (selected,),
        )
        orders = Table(title="Execution progress")
        orders.add_column("Intent")
        orders.add_column("Style")
        orders.add_column("Status")
        orders.add_column("Orders", justify="right")
        orders.add_column("Any fill", justify="right")
        orders.add_column("Avg queue", justify="right")
        for row in order_rows:
            orders.add_row(
                str(row["intent"]),
                str(row["execution_style"]),
                str(row["status"]),
                f"{row['n']:,}",
                f"{int(row['touched'] or 0):,}",
                "—" if row["avg_queue"] is None else f"{row['avg_queue']:,.0f}",
            )
        if not order_rows:
            orders.add_row("—", "—", "—", "0", "0", "—")
        CONSOLE.print(orders)

        latest_runtime = store.fetch_all(
            "SELECT * FROM runtime_metrics WHERE run_id=? ORDER BY timestamp DESC LIMIT 1",
            (selected,),
        )
        if latest_runtime:
            row = latest_runtime[0]
            health = Table(title="Live engine health")
            health.add_column("Metric")
            health.add_column("Value", justify="right")
            health.add_row("Queue depth", f"{row['queue_depth']:,}")
            health.add_row(
                "Current / max processing lag",
                f"{row['event_processing_lag_seconds']:.3f}s / "
                f"{row['max_event_processing_lag_seconds']:.3f}s",
            )
            health.add_row(
                "Processed / received sequence",
                f"{row['processed_events']:,} / {row['received_events']:,}",
            )
            health.add_row("Duplicate trade events ignored", f"{row['duplicate_trades']:,}")
            health.add_row("Pending exits", f"{row['pending_exits']:,}")
            health.add_row("Missed moves", f"{row['missed_moves']:,}")
            try:
                rejection_counts = json.loads(row["entry_rejections_json"] or "{}")
            except (json.JSONDecodeError, TypeError):
                rejection_counts = {}
            if rejection_counts:
                reason, count = max(
                    rejection_counts.items(), key=lambda item: int(item[1])
                )
                health.add_row("Most common entry block", f"{reason} ({int(count):,})")
            CONSOLE.print(health)

        reasons = store.fetch_all(
            """
            SELECT reason, COUNT(*) n FROM signals WHERE run_id=?
            GROUP BY reason ORDER BY n DESC LIMIT 10
            """,
            (selected,),
        )
        reason_table = Table(title="Signal states / rejection reasons")
        reason_table.add_column("Reason")
        reason_table.add_column("Samples", justify="right")
        for row in reasons:
            reason_table.add_row(str(row["reason"]), f"{row['n']:,}")
        CONSOLE.print(reason_table)

        _show_outcome_calibration(store, selected)
    finally:
        store.close()


def _show_outcome_calibration(store: SQLiteStore, run_id: str) -> None:
    rows = store.fetch_all(
        "SELECT score, first_barrier, horizon_returns_json, completed FROM signal_outcomes WHERE run_id=?",
        (run_id,),
    )
    table = Table(title="Forward signal calibration (ask entry → future bid)")
    table.add_column("Score bucket")
    table.add_column("Samples", justify="right")
    table.add_column("Target first", justify="right")
    table.add_column("Stop first", justify="right")
    table.add_column("Matured 1h avg", justify="right")
    buckets = [(40, 49.999), (50, 54.999), (55, 59.999), (60, 64.999), (65, 68.999), (69, 100)]
    for low, high in buckets:
        selected = [row for row in rows if low <= float(row["score"]) <= high]
        target = sum(1 for row in selected if row["first_barrier"] == "TARGET")
        stop = sum(1 for row in selected if row["first_barrier"] == "STOP")
        one_hour: list[float] = []
        for row in selected:
            try:
                returns: dict[str, Any] = json.loads(row["horizon_returns_json"])
                value = returns.get("3600")
                if value is not None:
                    one_hour.append(float(value))
            except (json.JSONDecodeError, TypeError, ValueError):
                continue
        avg = sum(one_hour) / len(one_hour) if one_hour else None
        label = f"{low:.0f}–{high:.0f}" if high < 100 else "69+"
        table.add_row(
            label,
            f"{len(selected):,}",
            f"{target:,}",
            f"{stop:,}",
            "—" if avg is None else f"{avg * 100:+.3f}%",
        )
    CONSOLE.print(table)
