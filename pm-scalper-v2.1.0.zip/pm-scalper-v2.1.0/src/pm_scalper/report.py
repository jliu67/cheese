from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.table import Table

from .config import AppConfig
from .storage import SQLiteStore, write_csv
from .util import fmt_money, json_dumps

CONSOLE = Console()
ZERO = Decimal("0")


def generate_report(config: AppConfig, run_id: str | None = None) -> Path:
    store = SQLiteStore(config)
    try:
        selected_run = run_id or store.latest_run_id()
        if not selected_run:
            raise RuntimeError("No PM-Scalper V2.1 runs exist in the configured database")
        run_rows = store.fetch_all("SELECT * FROM runs WHERE run_id=?", (selected_run,))
        if not run_rows:
            raise RuntimeError(f"Run not found: {selected_run}")
        run = dict(run_rows[0])

        trades = _rows(store, "closed_trades", selected_run, "closed_at")
        equity_rows = _rows(store, "equity", selected_run, "timestamp")
        signals = _rows(store, "signals", selected_run, "timestamp")
        attempts = _rows(store, "entry_attempts", selected_run, "created_at")
        orders = _rows(store, "orders", selected_run, "created_at")
        fills = _rows(store, "fills", selected_run, "timestamp")
        outcomes = _rows(store, "signal_outcomes", selected_run, "created_at")
        missed = _rows(store, "missed_moves", selected_run, "cancelled_at")
        exits = _rows(store, "exit_requests", selected_run, "requested_at")
        runtime = _rows(store, "runtime_metrics", selected_run, "timestamp")

        export_root = Path(config.storage.export_dir) / selected_run
        export_root.mkdir(parents=True, exist_ok=True)
        artifacts = {
            "trades_csv": export_root / "trades.csv",
            "equity_csv": export_root / "equity.csv",
            "signals_csv": export_root / "signals.csv",
            "entry_attempts_csv": export_root / "entry_attempts.csv",
            "orders_csv": export_root / "orders.csv",
            "fills_csv": export_root / "fills.csv",
            "signal_outcomes_csv": export_root / "signal_outcomes.csv",
            "missed_moves_csv": export_root / "missed_moves.csv",
            "exit_requests_csv": export_root / "exit_requests.csv",
            "runtime_metrics_csv": export_root / "runtime_metrics.csv",
        }
        for path, rows in [
            (artifacts["trades_csv"], trades),
            (artifacts["equity_csv"], equity_rows),
            (artifacts["signals_csv"], signals),
            (artifacts["entry_attempts_csv"], attempts),
            (artifacts["orders_csv"], orders),
            (artifacts["fills_csv"], fills),
            (artifacts["signal_outcomes_csv"], outcomes),
            (artifacts["missed_moves_csv"], missed),
            (artifacts["exit_requests_csv"], exits),
            (artifacts["runtime_metrics_csv"], runtime),
        ]:
            write_csv(path, rows)

        net_values = [Decimal(row["net_pnl"]) for row in trades]
        return_values = [Decimal(row["return_pct"]) for row in trades]
        fee_values = [Decimal(row["fee"]) for row in fills]
        gross_profit = sum((value for value in net_values if value > ZERO), ZERO)
        gross_loss = -sum((value for value in net_values if value < ZERO), ZERO)
        wins = sum(1 for value in net_values if value > ZERO)
        losses = sum(1 for value in net_values if value <= ZERO)
        realized_net_pnl = sum(net_values, ZERO)
        total_fees = sum(fee_values, ZERO)
        average_return = (
            sum(return_values, ZERO) / Decimal(len(return_values))
            if return_values
            else ZERO
        )
        profit_factor = float(gross_profit / gross_loss) if gross_loss > ZERO else None

        liquidation_values = [Decimal(row["liquidation_equity"]) for row in equity_rows]
        mark_values = [Decimal(row["mark_equity"]) for row in equity_rows]
        try:
            stored_config = json.loads(run.get("config_json") or "{}")
            stored_starting_cash = stored_config["risk"]["starting_cash_usdc"]
        except (json.JSONDecodeError, KeyError, TypeError):
            stored_starting_cash = config.risk.starting_cash_usdc
        starting_equity = Decimal(str(stored_starting_cash))
        ending_liquidation_equity = (
            liquidation_values[-1] if liquidation_values else starting_equity
        )
        ending_mark_equity = mark_values[-1] if mark_values else starting_equity
        session_net_pnl = ending_liquidation_equity - starting_equity
        max_liquidation_drawdown = calculate_max_drawdown(
            [starting_equity, *liquidation_values]
        )
        max_mark_drawdown = calculate_max_drawdown([starting_equity, *mark_values])

        entry_orders = [row for row in orders if row["intent"] == "ENTRY"]
        filled_entries = sum(
            1 for row in entry_orders if Decimal(row["filled_quantity"]) > ZERO
        )
        fill_rate = filled_entries / len(entry_orders) if entry_orders else 0.0
        maker_entries = sum(
            1 for row in entry_orders if row["execution_style"] == "MAKER"
        )
        taker_entries = sum(
            1 for row in entry_orders if row["execution_style"] == "TAKER"
        )

        attempts_created = len(attempts)
        attempts_refresh_required = sum(int(row["refresh_required"]) for row in attempts)
        attempts_refresh_success = sum(
            1 for row in attempts if row["refresh_success"] == 1
        )
        attempts_refresh_failed = sum(
            1 for row in attempts if row["refresh_success"] == 0
        )
        attempts_order_created = sum(
            1 for row in attempts if row["decision"] == "ORDER_CREATED"
        )
        attempts_blocked = sum(1 for row in attempts if row["decision"] == "BLOCKED")
        attempt_block_reasons = _count_by(attempts, "reason", decision="BLOCKED")

        latest_runtime = runtime[-1] if runtime else None
        duplicate_trades = int(latest_runtime["duplicate_trades"]) if latest_runtime else 0
        max_processing_lag = (
            max(float(row["max_event_processing_lag_seconds"]) for row in runtime)
            if runtime
            else 0.0
        )
        refresh_metrics = {
            "requests": int(latest_runtime["refresh_requests"]) if latest_runtime else 0,
            "successes": int(latest_runtime["refresh_successes"]) if latest_runtime else 0,
            "failures": int(latest_runtime["refresh_failures"]) if latest_runtime else 0,
            "timeouts": int(latest_runtime["refresh_timeouts"]) if latest_runtime else 0,
            "coalesced": int(latest_runtime["refresh_coalesced"]) if latest_runtime else 0,
            "average_latency_ms": (
                float(latest_runtime["average_refresh_latency_ms"])
                if latest_runtime
                else 0.0
            ),
            "max_latency_ms": (
                float(latest_runtime["max_refresh_latency_ms"])
                if latest_runtime
                else 0.0
            ),
        }

        outcome_summary = summarize_signal_outcomes(outcomes)
        untradeable_outcomes = sum(
            1 for row in outcomes if not bool(row["tradeable_at_entry"])
        )
        tradeable_outcomes = len(outcomes) - untradeable_outcomes

        summary: dict[str, Any] = {
            "run": run,
            "metrics": {
                "starting_equity": str(starting_equity),
                "ending_liquidation_equity": str(ending_liquidation_equity),
                "ending_mark_equity": str(ending_mark_equity),
                "net_pnl": str(session_net_pnl),
                "realized_net_pnl": str(realized_net_pnl),
                "total_fees": str(total_fees),
                "closed_trades": len(trades),
                "wins": wins,
                "losses": losses,
                "win_rate": wins / len(trades) if trades else 0.0,
                "average_trade_return": str(average_return),
                "profit_factor": profit_factor,
                "max_liquidation_drawdown": max_liquidation_drawdown,
                "max_mark_drawdown": max_mark_drawdown,
                "entry_attempts": attempts_created,
                "entry_attempts_refresh_required": attempts_refresh_required,
                "entry_attempts_refresh_success": attempts_refresh_success,
                "entry_attempts_refresh_failed": attempts_refresh_failed,
                "entry_attempts_order_created": attempts_order_created,
                "entry_attempts_blocked": attempts_blocked,
                "entry_attempt_block_reasons": attempt_block_reasons,
                "entry_orders": len(entry_orders),
                "maker_entry_orders": maker_entries,
                "taker_entry_orders": taker_entries,
                "entry_fill_rate": fill_rate,
                "fills": len(fills),
                "signal_samples": len(signals),
                "signal_outcome_samples": len(outcomes),
                "signal_outcomes_tradeable_at_entry": tradeable_outcomes,
                "signal_outcomes_untradeable_at_entry": untradeable_outcomes,
                "missed_move_hits": sum(1 for row in missed if row["hit_at"] is not None),
                "duplicate_trades_ignored": duplicate_trades,
                "max_event_processing_lag_seconds": max_processing_lag,
                "targeted_refresh": refresh_metrics,
            },
            "signal_calibration": outcome_summary,
            "execution_calibration": summarize_execution(entry_orders, trades),
            "artifacts": {key: str(value) for key, value in artifacts.items()},
        }
        summary_path = export_root / "summary.json"
        summary_path.write_text(
            json_dumps(summary, compact=False) + "\n", encoding="utf-8"
        )
        print_summary(summary, selected_run, summary_path)
        return summary_path
    finally:
        store.close()


def _rows(
    store: SQLiteStore, table: str, run_id: str, order_column: str
) -> list[Any]:
    return store.fetch_all(
        f'SELECT * FROM "{table}" WHERE run_id=? ORDER BY "{order_column}"',
        (run_id,),
    )


def _count_by(rows: list[Any], field: str, *, decision: str | None = None) -> dict[str, int]:
    counts: dict[str, int] = {}
    for row in rows:
        if decision is not None and row["decision"] != decision:
            continue
        value = str(row[field] or "—")
        counts[value] = counts.get(value, 0) + 1
    return dict(sorted(counts.items(), key=lambda item: (-item[1], item[0])))


def summarize_signal_outcomes(rows: list[Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    buckets = [(40, 50), (50, 55), (55, 60), (60, 65), (65, 69), (69, 101)]
    for low, high in buckets:
        selected = [row for row in rows if low <= float(row["score"]) < high]
        tradeable = [row for row in selected if bool(row["tradeable_at_entry"])]
        untradeable = len(selected) - len(tradeable)
        target = sum(1 for row in tradeable if row["first_barrier"] == "TARGET")
        stop = sum(1 for row in tradeable if row["first_barrier"] == "STOP")
        undecided = sum(
            1 for row in tradeable if row["first_barrier"] not in {"TARGET", "STOP"}
        )
        returns: dict[str, list[float]] = {}
        for row in tradeable:
            try:
                payload = json.loads(row["horizon_returns_json"])
            except (json.JSONDecodeError, TypeError):
                continue
            for horizon, value in payload.items():
                if value is not None:
                    returns.setdefault(str(horizon), []).append(float(value))
        averages = {
            horizon: sum(values) / len(values)
            for horizon, values in returns.items()
            if values
        }
        label = f"{low}-{high - 1}" if high < 101 else "69+"
        result[label] = {
            "samples": len(selected),
            "tradeable_at_entry": len(tradeable),
            "untradeable_at_entry": untradeable,
            "target_first": target,
            "stop_first": stop,
            "undecided": undecided,
            "target_first_rate_of_decided_tradeable": (
                target / (target + stop) if target + stop else None
            ),
            "average_fee_aware_returns": averages,
        }
    return result


def summarize_execution(entry_orders: list[Any], trades: list[Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for style in ("MAKER", "TAKER"):
        selected = [row for row in entry_orders if row["execution_style"] == style]
        any_fill = sum(1 for row in selected if Decimal(row["filled_quantity"]) > ZERO)
        full_fill = sum(1 for row in selected if row["status"] == "FILLED")
        result[style.lower()] = {
            "orders": len(selected),
            "any_fill": any_fill,
            "full_fill": full_fill,
            "any_fill_rate": any_fill / len(selected) if selected else None,
            "average_queue_ahead": (
                sum(Decimal(row["queue_ahead"]) for row in selected) / len(selected)
                if selected
                else None
            ),
        }
    net = [Decimal(row["net_pnl"]) for row in trades]
    returns = [Decimal(row["return_pct"]) for row in trades]
    result["closed_trades"] = {
        "count": len(trades),
        "wins": sum(1 for value in net if value > ZERO),
        "average_return": (
            str(sum(returns, ZERO) / len(returns)) if returns else None
        ),
    }
    # Convert Decimals for JSON serialization.
    for style in ("maker", "taker"):
        value = result[style]["average_queue_ahead"]
        result[style]["average_queue_ahead"] = None if value is None else str(value)
    return result


def calculate_max_drawdown(values: list[Decimal]) -> float:
    if not values:
        return 0.0
    peak = values[0]
    worst = Decimal("0")
    for value in values:
        peak = max(peak, value)
        if peak > ZERO:
            drawdown = value / peak - Decimal("1")
            worst = min(worst, drawdown)
    return float(worst)


def print_summary(summary: dict[str, Any], run_id: str, path: Path) -> None:
    metrics = summary["metrics"]
    table = Table(title=f"PM-Scalper V2.1 report — {run_id}")
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    table.add_row("Starting equity", fmt_money(Decimal(metrics["starting_equity"])))
    table.add_row(
        "Ending liquidation equity",
        fmt_money(Decimal(metrics["ending_liquidation_equity"])),
    )
    table.add_row("Ending mark equity", fmt_money(Decimal(metrics["ending_mark_equity"])))
    table.add_row("Session net P&L", fmt_money(Decimal(metrics["net_pnl"])))
    table.add_row("Realized net P&L", fmt_money(Decimal(metrics["realized_net_pnl"])))
    table.add_row("Closed trades", str(metrics["closed_trades"]))
    table.add_row("Win rate", f"{metrics['win_rate'] * 100:.1f}%")
    table.add_row(
        "Average trade return",
        f"{Decimal(metrics['average_trade_return']) * 100:.3f}%",
    )
    table.add_row(
        "Profit factor",
        "—" if metrics["profit_factor"] is None else f"{metrics['profit_factor']:.2f}",
    )
    table.add_row(
        "Maximum liquidation drawdown",
        f"{metrics['max_liquidation_drawdown'] * 100:.2f}%",
    )
    table.add_row("Entry attempts", str(metrics["entry_attempts"]))
    table.add_row(
        "Attempts → orders / blocked",
        f"{metrics['entry_attempts_order_created']} / {metrics['entry_attempts_blocked']}",
    )
    table.add_row("Entry fill rate", f"{metrics['entry_fill_rate'] * 100:.1f}%")
    table.add_row(
        "Maker / taker entries",
        f"{metrics['maker_entry_orders']} / {metrics['taker_entry_orders']}",
    )
    table.add_row(
        "Calibration tradeable / untradeable",
        f"{metrics['signal_outcomes_tradeable_at_entry']} / "
        f"{metrics['signal_outcomes_untradeable_at_entry']}",
    )
    table.add_row("Fees", fmt_money(Decimal(metrics["total_fees"])))
    table.add_row(
        "Ignored duplicate trades", str(metrics["duplicate_trades_ignored"])
    )
    table.add_row(
        "Max processing lag",
        f"{metrics['max_event_processing_lag_seconds']:.3f}s",
    )
    refresh = metrics["targeted_refresh"]
    table.add_row(
        "Targeted refresh success / failed",
        f"{refresh['successes']} / {refresh['failures']}",
    )
    table.add_row(
        "Targeted refresh latency avg / max",
        f"{refresh['average_latency_ms']:.1f}ms / {refresh['max_latency_ms']:.1f}ms",
    )
    CONSOLE.print(table)
    CONSOLE.print(f"Report files: [bold]{path.parent}[/bold]")
