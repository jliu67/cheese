from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable

from .book import OrderBook
from .util import ZERO


@dataclass(slots=True)
class ShadowSide:
    real: dict[Decimal, Decimal] = field(default_factory=dict)
    available: dict[Decimal, Decimal] = field(default_factory=dict)

    def sync(self, new_real: dict[Decimal, Decimal]) -> None:
        """Reconcile a public side without resurrecting consumed paper liquidity.

        Only a demonstrated increase at the same price replenishes counterfactual
        availability. A decrease also reduces availability. A removed level becomes
        unavailable; if it later reappears, that reappearance is observable new depth.
        """

        previous_real = self.real
        previous_available = self.available
        next_available: dict[Decimal, Decimal] = {}
        for price, new_size in new_real.items():
            if price not in previous_real:
                available = new_size
            else:
                delta = new_size - previous_real[price]
                # If a level was fully consumed, absence from previous_available means
                # zero counterfactual shares—not the old public size.
                available = previous_available.get(price, ZERO) + delta
                available = max(ZERO, min(new_size, available))
            if available > ZERO:
                next_available[price] = available
        self.real = dict(new_real)
        self.available = next_available


@dataclass(slots=True)
class ShadowTokenBook:
    token_id: str
    bids: ShadowSide = field(default_factory=ShadowSide)
    asks: ShadowSide = field(default_factory=ShadowSide)
    bid_level_sequences: dict[Decimal, int] = field(default_factory=dict)
    ask_level_sequences: dict[Decimal, int] = field(default_factory=dict)
    bid_level_received_at: dict[Decimal, float] = field(default_factory=dict)
    ask_level_received_at: dict[Decimal, float] = field(default_factory=dict)
    last_bid_sequence: int = 0
    last_ask_sequence: int = 0
    last_depth_received_at: float = 0.0


class ShadowBookStore:
    """Counterfactual liquidity ledger for the paper trader.

    Public CLOB depth is immutable from the point of view of a paper order. This
    ledger remembers what the hypothetical trader already consumed, then restores
    only increases that are later demonstrated by the real public book.
    """

    def __init__(self) -> None:
        self.books: dict[str, ShadowTokenBook] = {}

    def ensure(self, token_id: str) -> ShadowTokenBook:
        state = self.books.get(token_id)
        if state is None:
            state = ShadowTokenBook(token_id=token_id)
            self.books[token_id] = state
        return state

    def sync(self, book: OrderBook) -> ShadowTokenBook:
        state = self.ensure(book.token_id)
        state.bids.sync(book.bids)
        state.asks.sync(book.asks)
        state.bid_level_sequences = {
            price: sequence
            for price, sequence in book.bid_level_sequences.items()
            if price in book.bids
        }
        state.ask_level_sequences = {
            price: sequence
            for price, sequence in book.ask_level_sequences.items()
            if price in book.asks
        }
        state.bid_level_received_at = {
            price: observed_at
            for price, observed_at in book.bid_level_received_at.items()
            if price in book.bids
        }
        state.ask_level_received_at = {
            price: observed_at
            for price, observed_at in book.ask_level_received_at.items()
            if price in book.asks
        }
        state.last_bid_sequence = book.last_bid_sequence
        state.last_ask_sequence = book.last_ask_sequence
        state.last_depth_received_at = book.last_depth_received_at
        return state

    def available_at(self, token_id: str, side: str, price: Decimal) -> Decimal:
        state = self.books.get(token_id)
        if state is None:
            return ZERO
        levels = state.bids.available if side.upper() == "BUY" else state.asks.available
        return levels.get(price, ZERO)

    def depth_notional(
        self,
        token_id: str,
        side: str,
        levels: int = 5,
        *,
        after_sequence: int | None = None,
        active_at: float | None = None,
        timestamp: float | None = None,
        stale_seconds: float | None = None,
    ) -> Decimal:
        eligible = self._eligible_levels(
            token_id,
            side,
            after_sequence=after_sequence,
            active_at=active_at,
            timestamp=timestamp,
            stale_seconds=stale_seconds,
        )
        return sum((price * size for price, size in eligible[:levels]), ZERO)

    def walk(
        self,
        token_id: str,
        side: str,
        quantity: Decimal,
        *,
        consume: bool,
        limit_price: Decimal | None = None,
        after_sequence: int | None = None,
        active_at: float | None = None,
        timestamp: float | None = None,
        stale_seconds: float | None = None,
    ) -> list[tuple[Decimal, Decimal]]:
        """Walk shadow levels.

        side="BUY" means sell into bids (highest price first).
        side="SELL" means buy from asks (lowest price first).
        Optional observation filters ensure only per-level depth seen after an order
        became active—and/or still locally fresh—can be used.
        """

        state = self.books.get(token_id)
        if state is None or quantity <= ZERO:
            return []
        is_bid = side.upper() == "BUY"
        available_levels = state.bids.available if is_bid else state.asks.available
        remaining = quantity
        fills: list[tuple[Decimal, Decimal]] = []
        for price, available in self._eligible_levels(
            token_id,
            side,
            after_sequence=after_sequence,
            active_at=active_at,
            timestamp=timestamp,
            stale_seconds=stale_seconds,
        ):
            if limit_price is not None:
                if is_bid and price < limit_price:
                    continue
                if not is_bid and price > limit_price:
                    continue
            take = min(remaining, available)
            if take <= ZERO:
                continue
            fills.append((price, take))
            remaining -= take
            if consume:
                left = available_levels.get(price, ZERO) - take
                if left > ZERO:
                    available_levels[price] = left
                else:
                    available_levels.pop(price, None)
            if remaining <= ZERO:
                break
        return fills

    def _eligible_levels(
        self,
        token_id: str,
        side: str,
        *,
        after_sequence: int | None,
        active_at: float | None,
        timestamp: float | None,
        stale_seconds: float | None,
    ) -> list[tuple[Decimal, Decimal]]:
        state = self.books.get(token_id)
        if state is None:
            return []
        is_bid = side.upper() == "BUY"
        levels = state.bids.available if is_bid else state.asks.available
        sequences = state.bid_level_sequences if is_bid else state.ask_level_sequences
        received = state.bid_level_received_at if is_bid else state.ask_level_received_at
        eligible: list[tuple[Decimal, Decimal]] = []
        for price in sorted(levels, reverse=is_bid):
            sequence = sequences.get(price, 0)
            observed_at = received.get(price, 0.0)
            if after_sequence is not None and sequence <= after_sequence:
                continue
            if active_at is not None and observed_at < active_at:
                continue
            if (
                timestamp is not None
                and stale_seconds is not None
                and (observed_at <= 0 or timestamp - observed_at > stale_seconds)
            ):
                continue
            available = levels.get(price, ZERO)
            if available > ZERO:
                eligible.append((price, available))
        return eligible

    def consume_fills(
        self, token_id: str, side: str, fills: Iterable[tuple[Decimal, Decimal]]
    ) -> None:
        """Consume exact already-previewed levels without touching any extra depth."""

        state = self.books.get(token_id)
        if state is None:
            return
        levels = state.bids.available if side.upper() == "BUY" else state.asks.available
        for price, quantity in fills:
            if quantity <= ZERO:
                continue
            available = levels.get(price, ZERO)
            take = min(available, quantity)
            left = available - take
            if left > ZERO:
                levels[price] = left
            else:
                levels.pop(price, None)

    @staticmethod
    def aggregate(
        fills: Iterable[tuple[Decimal, Decimal]],
    ) -> tuple[Decimal | None, Decimal]:
        total_quantity = ZERO
        total_notional = ZERO
        for price, quantity in fills:
            total_quantity += quantity
            total_notional += price * quantity
        if total_quantity <= ZERO:
            return None, ZERO
        return total_notional / total_quantity, total_quantity
