from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Hashable, Iterator

from .models import TradePrint
from .util import ONE, ZERO, as_bool, dec, epoch_seconds, opt_dec


@dataclass(slots=True)
class OrderBook:
    token_id: str
    market: str = ""
    bids: dict[Decimal, Decimal] = field(default_factory=dict)
    asks: dict[Decimal, Decimal] = field(default_factory=dict)
    tick_size: Decimal = Decimal("0.01")
    # Polymarket's min_order_size is an order quantity in outcome shares.
    min_order_size: Decimal = Decimal("5")
    neg_risk: bool = False
    last_trade_price: Decimal | None = None

    # Exchange/event time for feature chronology.
    last_update: float = 0.0
    last_depth_update: float = 0.0
    # Local receive time for freshness and causality.
    last_received_at: float = 0.0
    last_depth_received_at: float = 0.0
    # Complete REST/WebSocket book snapshots have their own freshness clock. A
    # single price_change refreshes one level, not the whole depth ladder.
    last_full_depth_update: float = 0.0
    last_full_depth_received_at: float = 0.0
    last_sequence: int = 0
    last_depth_sequence: int = 0
    last_full_depth_sequence: int = 0
    last_bid_sequence: int = 0
    last_ask_sequence: int = 0

    # best_bid_ask and price_change messages can carry a fresh top quote without
    # certifying the displayed sizes. Keep that hint separate from depth.
    quoted_best_bid: Decimal | None = None
    quoted_best_ask: Decimal | None = None
    last_bid_quote_received_at: float = 0.0
    last_ask_quote_received_at: float = 0.0
    last_quote_sequence: int = 0

    # Per-price observation metadata. A price_change certifies only the changed
    # level; a full snapshot certifies every level it contains. This prevents an
    # unrelated update from making an old cached top-of-book level executable.
    bid_level_sequences: dict[Decimal, int] = field(default_factory=dict)
    ask_level_sequences: dict[Decimal, int] = field(default_factory=dict)
    bid_level_received_at: dict[Decimal, float] = field(default_factory=dict)
    ask_level_received_at: dict[Decimal, float] = field(default_factory=dict)

    depth_version: int = 0
    bid_version: int = 0
    ask_version: int = 0
    book_hash: str | None = None

    def _update_quote_hints(
        self,
        bid: Decimal | None,
        ask: Decimal | None,
        received_at: float,
        sequence_id: int,
    ) -> None:
        if bid is not None and ZERO < bid < ONE:
            self.quoted_best_bid = bid
            self.last_bid_quote_received_at = received_at
        if ask is not None and ZERO < ask < ONE:
            self.quoted_best_ask = ask
            self.last_ask_quote_received_at = received_at
        if bid is not None or ask is not None:
            self.last_quote_sequence = max(self.last_quote_sequence, sequence_id)

    def apply_snapshot(
        self, payload: dict[str, Any], received_at: float, sequence_id: int = 0
    ) -> bool:
        event_time = epoch_seconds(payload.get("timestamp"), received_at)
        new_bids = levels_to_dict(payload.get("bids"))
        new_asks = levels_to_dict(payload.get("asks"))
        new_hash_raw = payload.get("hash")
        new_hash = str(new_hash_raw) if new_hash_raw else None

        # A REST snapshot can carry an exchange timestamp slightly behind a more
        # recent WebSocket change. Never roll the public book backward. An older
        # snapshot may still certify freshness when it exactly matches the current
        # aggregate book (or its authoritative hash matches).
        older = self.last_depth_update > 0 and event_time < self.last_depth_update
        same_aggregate = new_bids == self.bids and new_asks == self.asks
        same_hash = bool(new_hash and self.book_hash and new_hash == self.book_hash)
        if older and not (same_aggregate or same_hash):
            return False

        is_first = self.last_full_depth_received_at <= 0
        bids_changed = is_first or new_bids != self.bids
        asks_changed = is_first or new_asks != self.asks
        aggregate_changed = bids_changed or asks_changed
        hash_changed = new_hash is not None and new_hash != self.book_hash
        changed = is_first or hash_changed or aggregate_changed

        self.market = str(payload.get("market") or self.market)
        # Only replace levels when the snapshot is not an older same-hash
        # certification whose aggregate differs from newer WebSocket state.
        if not older or same_aggregate:
            self.bids = new_bids
            self.asks = new_asks
        current_bids = self.bids
        current_asks = self.asks
        # A complete matching snapshot is a fresh observation of every current
        # level, even when sizes/hash did not change.
        self.bid_level_sequences = {price: sequence_id for price in current_bids}
        self.ask_level_sequences = {price: sequence_id for price in current_asks}
        self.bid_level_received_at = {price: received_at for price in current_bids}
        self.ask_level_received_at = {price: received_at for price in current_asks}

        tick = opt_dec(payload.get("tick_size") or payload.get("tickSize"))
        minimum = opt_dec(payload.get("min_order_size") or payload.get("minOrderSize"))
        if tick is not None and tick > ZERO:
            self.tick_size = tick
        if minimum is not None and minimum > ZERO:
            self.min_order_size = minimum
        if payload.get("neg_risk") is not None:
            self.neg_risk = as_bool(payload.get("neg_risk"), self.neg_risk)
        last = opt_dec(payload.get("last_trade_price") or payload.get("lastTradePrice"))
        if last is not None:
            self.last_trade_price = last
        if new_hash is not None and (not older or same_hash or same_aggregate):
            self.book_hash = new_hash

        self.last_update = max(self.last_update, event_time)
        self.last_depth_update = max(self.last_depth_update, event_time)
        self.last_full_depth_update = max(self.last_full_depth_update, event_time)
        self.last_received_at = max(self.last_received_at, received_at)
        self.last_depth_received_at = received_at
        self.last_full_depth_received_at = received_at
        self.last_sequence = max(self.last_sequence, sequence_id)
        self.last_depth_sequence = max(self.last_depth_sequence, sequence_id)
        self.last_full_depth_sequence = max(self.last_full_depth_sequence, sequence_id)
        self.last_bid_sequence = max(self.last_bid_sequence, sequence_id)
        self.last_ask_sequence = max(self.last_ask_sequence, sequence_id)
        self._update_quote_hints(self.best_bid, self.best_ask, received_at, sequence_id)
        if changed and not older:
            self.depth_version += 1
        if bids_changed and not older:
            self.bid_version += 1
        if asks_changed and not older:
            self.ask_version += 1
        return changed

    def apply_change(
        self,
        change: dict[str, Any],
        received_at: float,
        sequence_id: int = 0,
        event_time: float | None = None,
    ) -> bool:
        exchange_time = event_time if event_time is not None else received_at
        if self.last_depth_update > 0 and exchange_time < self.last_depth_update:
            return False
        price = dec(change.get("price"))
        size = dec(change.get("size"))
        side = str(change.get("side") or "").upper()
        if price <= ZERO or price >= ONE:
            return False
        if side == "BUY":
            levels = self.bids
            sequence_map = self.bid_level_sequences
            received_map = self.bid_level_received_at
        elif side == "SELL":
            levels = self.asks
            sequence_map = self.ask_level_sequences
            received_map = self.ask_level_received_at
        else:
            return False

        old_size = levels.get(price, ZERO)
        if size <= ZERO:
            aggregate_changed = price in levels
            levels.pop(price, None)
            sequence_map.pop(price, None)
            received_map.pop(price, None)
        else:
            aggregate_changed = old_size != size
            levels[price] = size
            # Even an unchanged-size update is a fresh observation of this one level.
            sequence_map[price] = sequence_id
            received_map[price] = received_at

        new_hash_raw = change.get("hash")
        new_hash = str(new_hash_raw) if new_hash_raw else None
        hash_changed = new_hash is not None and new_hash != self.book_hash
        changed = aggregate_changed or hash_changed
        if new_hash is not None:
            self.book_hash = new_hash
        self._update_quote_hints(
            opt_dec(change.get("best_bid") or change.get("bestBid")),
            opt_dec(change.get("best_ask") or change.get("bestAsk")),
            received_at,
            sequence_id,
        )
        self.last_update = max(self.last_update, exchange_time)
        self.last_depth_update = max(self.last_depth_update, exchange_time)
        self.last_received_at = max(self.last_received_at, received_at)
        self.last_depth_received_at = received_at
        self.last_sequence = max(self.last_sequence, sequence_id)
        self.last_depth_sequence = max(self.last_depth_sequence, sequence_id)
        if side == "BUY":
            self.last_bid_sequence = max(self.last_bid_sequence, sequence_id)
        else:
            self.last_ask_sequence = max(self.last_ask_sequence, sequence_id)
        if changed:
            self.depth_version += 1
        if aggregate_changed:
            if side == "BUY":
                self.bid_version += 1
            else:
                self.ask_version += 1
        return changed

    def invalidate_for_trade(self, trade: TradePrint) -> None:
        """Invalidate cached levels that a trade may have consumed.

        The public trade message does not provide the post-trade residual depth. We
        therefore leave displayed sizes intact for features but do not treat affected
        levels as executable again until a later price_change or full snapshot
        re-observes them. `SELL` prints can consume bids at/above the trade price;
        `BUY` prints can consume asks at/below it.
        """

        if trade.side == "SELL":
            for price in list(self.bid_level_sequences):
                if price >= trade.price:
                    self.bid_level_sequences.pop(price, None)
                    self.bid_level_received_at.pop(price, None)
        elif trade.side == "BUY":
            for price in list(self.ask_level_sequences):
                if price <= trade.price:
                    self.ask_level_sequences.pop(price, None)
                    self.ask_level_received_at.pop(price, None)

    @property
    def best_bid(self) -> Decimal | None:
        return max(self.bids) if self.bids else None

    @property
    def best_ask(self) -> Decimal | None:
        return min(self.asks) if self.asks else None

    @property
    def midpoint(self) -> Decimal | None:
        bid, ask = self.best_bid, self.best_ask
        if bid is None or ask is None or ask <= bid:
            return None
        return (bid + ask) / Decimal("2")

    @property
    def spread(self) -> Decimal | None:
        bid, ask = self.best_bid, self.best_ask
        if bid is None or ask is None:
            return None
        return ask - bid

    @property
    def microprice(self) -> Decimal | None:
        bid, ask = self.best_bid, self.best_ask
        if bid is None or ask is None:
            return None
        bid_size = self.bids.get(bid, ZERO)
        ask_size = self.asks.get(ask, ZERO)
        total = bid_size + ask_size
        if total <= ZERO:
            return self.midpoint
        return (ask * bid_size + bid * ask_size) / total

    def depth_notional(self, side: str, levels: int = 5) -> Decimal:
        source = self.bids if side.upper() == "BUY" else self.asks
        prices = sorted(source, reverse=side.upper() == "BUY")[:levels]
        return sum((price * source[price] for price in prices), ZERO)

    def depth_shares(self, side: str, levels: int = 5) -> Decimal:
        source = self.bids if side.upper() == "BUY" else self.asks
        prices = sorted(source, reverse=side.upper() == "BUY")[:levels]
        return sum((source[price] for price in prices), ZERO)

    def size_at(self, side: str, price: Decimal) -> Decimal:
        source = self.bids if side.upper() == "BUY" else self.asks
        return source.get(price, ZERO)

    def level_sequence(self, side: str, price: Decimal) -> int:
        source = (
            self.bid_level_sequences
            if side.upper() == "BUY"
            else self.ask_level_sequences
        )
        return source.get(price, 0)

    def level_received_at(self, side: str, price: Decimal) -> float:
        source = (
            self.bid_level_received_at
            if side.upper() == "BUY"
            else self.ask_level_received_at
        )
        return source.get(price, 0.0)

    def level_is_fresh(
        self, side: str, price: Decimal, timestamp: float, stale_seconds: float
    ) -> bool:
        observed_at = self.level_received_at(side, price)
        return observed_at > 0 and timestamp - observed_at <= stale_seconds

    def top_is_fresh(self, side: str, timestamp: float, stale_seconds: float) -> bool:
        price = self.best_bid if side.upper() == "BUY" else self.best_ask
        return price is not None and self.level_is_fresh(
            side, price, timestamp, stale_seconds
        )

    def top_age_seconds(self, side: str, timestamp: float) -> float | None:
        price = self.best_bid if side.upper() == "BUY" else self.best_ask
        if price is None:
            return None
        observed_at = self.level_received_at(side, price)
        return None if observed_at <= 0 else max(0.0, timestamp - observed_at)

    def quote_age_seconds(self, timestamp: float) -> float | None:
        observations = [
            value
            for value in (self.last_bid_quote_received_at, self.last_ask_quote_received_at)
            if value > 0
        ]
        return None if len(observations) < 2 else max(0.0, timestamp - min(observations))

    def quotes_are_fresh(self, timestamp: float, stale_seconds: float) -> bool:
        age = self.quote_age_seconds(timestamp)
        return age is not None and age <= stale_seconds

    def full_depth_age_seconds(self, timestamp: float) -> float | None:
        if self.last_full_depth_received_at <= 0:
            return None
        return max(0.0, timestamp - self.last_full_depth_received_at)

    def full_depth_is_fresh(self, timestamp: float, stale_seconds: float) -> bool:
        age = self.full_depth_age_seconds(timestamp)
        return age is not None and age <= stale_seconds

    def iter_observed_levels(
        self,
        side: str,
        *,
        after_sequence: int | None = None,
        active_at: float | None = None,
        timestamp: float | None = None,
        stale_seconds: float | None = None,
    ) -> Iterator[tuple[Decimal, Decimal]]:
        is_bid = side.upper() == "BUY"
        levels = self.bids if is_bid else self.asks
        sequences = self.bid_level_sequences if is_bid else self.ask_level_sequences
        received = self.bid_level_received_at if is_bid else self.ask_level_received_at
        for price in sorted(levels, reverse=is_bid):
            sequence = sequences.get(price, 0)
            observed_at = received.get(price, 0.0)
            if after_sequence is not None and sequence <= after_sequence:
                continue
            if active_at is not None and observed_at < active_at:
                continue
            if (
                timestamp is not None
                and stale_seconds is not None
                and (observed_at <= 0 or timestamp - observed_at > stale_seconds)
            ):
                continue
            yield price, levels[price]

    def imbalance(self, levels: int = 5) -> Decimal:
        bid = self.depth_notional("BUY", levels)
        ask = self.depth_notional("SELL", levels)
        total = bid + ask
        return bid / total if total > ZERO else Decimal("0.5")

    def taker_sell_vwap(self, quantity: Decimal) -> tuple[Decimal | None, Decimal]:
        return self._walk(self.bids, quantity, reverse=True)

    def taker_buy_vwap(self, quantity: Decimal) -> tuple[Decimal | None, Decimal]:
        return self._walk(self.asks, quantity, reverse=False)

    @staticmethod
    def _walk(
        levels: dict[Decimal, Decimal], quantity: Decimal, *, reverse: bool
    ) -> tuple[Decimal | None, Decimal]:
        remaining = quantity
        filled = ZERO
        notional = ZERO
        for price in sorted(levels, reverse=reverse):
            available = levels[price]
            take = min(remaining, available)
            if take <= ZERO:
                continue
            notional += take * price
            filled += take
            remaining -= take
            if remaining <= ZERO:
                break
        if filled <= ZERO:
            return None, ZERO
        return notional / filled, filled


class BookStore:
    def __init__(self, trade_dedupe_capacity: int = 100_000) -> None:
        self.books: dict[str, OrderBook] = {}
        self.trade_dedupe_capacity = max(1, trade_dedupe_capacity)
        self._seen_trades: OrderedDict[Hashable, None] = OrderedDict()
        self.duplicate_trades = 0

    def get(self, token_id: str) -> OrderBook | None:
        return self.books.get(token_id)

    def ensure(self, token_id: str) -> OrderBook:
        book = self.books.get(token_id)
        if book is None:
            book = OrderBook(token_id=token_id)
            self.books[token_id] = book
        return book

    def seed(
        self, payload: dict[str, Any], received_at: float, sequence_id: int = 0
    ) -> OrderBook | None:
        token_id = str(payload.get("asset_id") or payload.get("token_id") or payload.get("tokenId") or "")
        if not token_id:
            return None
        book = self.ensure(token_id)
        book.apply_snapshot(payload, received_at, sequence_id)
        return book

    def apply_event(
        self, payload: dict[str, Any], received_at: float, sequence_id: int = 0
    ) -> tuple[list[OrderBook], list[TradePrint]]:
        event_type = str(payload.get("event_type") or "")
        updated: list[OrderBook] = []
        trades: list[TradePrint] = []

        if event_type == "book":
            token_id = str(payload.get("asset_id") or payload.get("token_id") or payload.get("tokenId") or "")
            if token_id:
                book = self.ensure(token_id)
                book.apply_snapshot(payload, received_at, sequence_id)
                updated.append(book)
        elif event_type == "price_change":
            event_time = epoch_seconds(payload.get("timestamp"), received_at)
            for change in payload.get("price_changes") or []:
                if not isinstance(change, dict):
                    continue
                token_id = str(change.get("asset_id") or change.get("token_id") or change.get("tokenId") or "")
                if not token_id:
                    continue
                book = self.ensure(token_id)
                book.apply_change(change, received_at, sequence_id, event_time)
                updated.append(book)
        elif event_type == "last_trade_price":
            token_id = str(payload.get("asset_id") or payload.get("token_id") or payload.get("tokenId") or "")
            if token_id:
                price = dec(payload.get("price"))
                size = dec(payload.get("size"))
                timestamp = epoch_seconds(payload.get("timestamp"), received_at)
                book = self.ensure(token_id)
                if price > ZERO:
                    book.last_trade_price = price
                    book.last_update = max(book.last_update, timestamp)
                    book.last_received_at = max(book.last_received_at, received_at)
                    book.last_sequence = max(book.last_sequence, sequence_id)
                    updated.append(book)
                if price > ZERO and size > ZERO:
                    trade = TradePrint(
                        token_id=token_id,
                        price=price,
                        size=size,
                        side=str(payload.get("side") or "").upper(),
                        timestamp=timestamp,
                        transaction_hash=(
                            str(payload.get("transaction_hash"))
                            if payload.get("transaction_hash")
                            else None
                        ),
                        sequence_id=sequence_id,
                        received_at=received_at,
                    )
                    if self._is_duplicate_trade(trade):
                        self.duplicate_trades += 1
                    else:
                        # A trade can consume cached top-of-book depth before the next
                        # authoritative size update arrives. Invalidate, don't invent
                        # a residual size.
                        book.invalidate_for_trade(trade)
                        trades.append(trade)
        elif event_type == "tick_size_change":
            token_id = str(payload.get("asset_id") or payload.get("token_id") or payload.get("tokenId") or "")
            tick = opt_dec(payload.get("new_tick_size"))
            if token_id and tick is not None and tick > ZERO:
                book = self.ensure(token_id)
                book.tick_size = tick
                book.last_update = max(
                    book.last_update,
                    epoch_seconds(payload.get("timestamp"), received_at),
                )
                book.last_received_at = max(book.last_received_at, received_at)
                book.last_sequence = max(book.last_sequence, sequence_id)
                updated.append(book)
        elif event_type == "best_bid_ask":
            # This is a fresh top-of-book hint, but not authoritative size/depth.
            token_id = str(payload.get("asset_id") or payload.get("token_id") or payload.get("tokenId") or "")
            if token_id:
                book = self.ensure(token_id)
                book._update_quote_hints(
                    opt_dec(payload.get("best_bid") or payload.get("bestBid")),
                    opt_dec(payload.get("best_ask") or payload.get("bestAsk")),
                    received_at,
                    sequence_id,
                )
                book.last_update = max(
                    book.last_update,
                    epoch_seconds(payload.get("timestamp"), received_at),
                )
                book.last_received_at = max(book.last_received_at, received_at)
                book.last_sequence = max(book.last_sequence, sequence_id)
                updated.append(book)
        return unique_books(updated), trades

    def _is_duplicate_trade(self, trade: TradePrint) -> bool:
        if trade.transaction_hash:
            key: Hashable = (
                trade.token_id,
                trade.transaction_hash,
                str(trade.price),
                str(trade.size),
                trade.side,
                round(trade.timestamp, 6),
            )
        else:
            key = (
                trade.token_id,
                round(trade.timestamp, 6),
                str(trade.price),
                str(trade.size),
                trade.side,
            )
        if key in self._seen_trades:
            self._seen_trades.move_to_end(key)
            return True
        self._seen_trades[key] = None
        if len(self._seen_trades) > self.trade_dedupe_capacity:
            self._seen_trades.popitem(last=False)
        return False


def levels_to_dict(value: Any) -> dict[Decimal, Decimal]:
    result: dict[Decimal, Decimal] = {}
    if not isinstance(value, list):
        return result
    for level in value:
        if not isinstance(level, dict):
            continue
        price = dec(level.get("price"))
        size = dec(level.get("size"))
        if ZERO < price < ONE and size > ZERO:
            result[price] = size
    return result


def unique_books(books: list[OrderBook]) -> list[OrderBook]:
    return list({book.token_id: book for book in books}.values())
