from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Mapping

from .book import BookStore, OrderBook
from .config import AppConfig
from .models import Asset, SignalOutcome, SignalSnapshot
from .storage import SQLiteStore
from .util import ONE, ZERO, ceil_to_tick, floor_to_tick


class SignalOutcomeTracker:
    """Fee-aware forward labels for short-term signal calibration.

    V2.1 models a conservative taker-style hypothetical: enter at the current ask,
    include the applicable/unknown-default taker fee, then value every future exit
    at the executable bid after an exit taker fee. A setup whose initial spread and
    fees already breach the configured stop is labelled UNTRADEABLE_AT_ENTRY rather
    than being counted as a predictive STOP failure.
    """

    def __init__(
        self,
        config: AppConfig,
        assets: Mapping[str, Asset],
        books: BookStore,
        store: SQLiteStore,
        run_id: str,
    ) -> None:
        self.config = config
        self.assets = dict(assets)
        self.books = books
        self.store = store
        self.run_id = run_id
        self.samples: dict[str, SignalOutcome] = {}
        self.last_sample_at: dict[str, float] = {}

    def observe_signals(
        self, signals: Mapping[str, SignalSnapshot], timestamp: float
    ) -> None:
        for signal in signals.values():
            if signal.score < self.config.strategy.outcome_tracking_min_score:
                continue
            if (
                timestamp - self.last_sample_at.get(signal.token_id, float("-inf"))
                < self.config.strategy.outcome_tracking_cooldown_seconds
            ):
                continue
            asset = self.assets.get(signal.token_id)
            book = self.books.get(signal.token_id)
            if (
                asset is None
                or book is None
                or book.best_bid is None
                or book.best_ask is None
                or book.best_ask <= book.best_bid
                or not book.top_is_fresh(
                    "BUY", timestamp, self.config.strategy.top_book_stale_seconds
                )
                or not book.top_is_fresh(
                    "SELL", timestamp, self.config.strategy.top_book_stale_seconds
                )
            ):
                continue

            entry = book.best_ask
            entry_fee = self._fee_per_share(asset, entry)
            entry_cost = entry + entry_fee
            initial_return = self._net_exit_return(asset, book.best_bid, entry_cost)
            tradeable = initial_return > -Decimal(str(self.config.strategy.stop_loss))
            reason = None
            barrier = None
            barrier_at = None
            if not tradeable:
                reason = "spread and taker fees breach stop at entry"
                barrier = "UNTRADEABLE_AT_ENTRY"
                barrier_at = timestamp

            target = self._price_for_return(
                asset,
                book,
                entry_cost,
                Decimal(str(self.config.strategy.target_return)),
                upward=True,
            )
            stop = self._price_for_return(
                asset,
                book,
                entry_cost,
                -Decimal(str(self.config.strategy.stop_loss)),
                upward=False,
            )
            horizons = {
                int(value): None for value in self.config.strategy.outcome_horizons_seconds
            }
            sample = SignalOutcome(
                id=uuid.uuid4().hex,
                token_id=asset.token_id,
                market_id=asset.market_id,
                outcome=asset.outcome,
                question=asset.question,
                created_at=timestamp,
                score=signal.score,
                entry_ask=entry,
                initial_bid=book.best_bid,
                target_price=target,
                stop_price=stop,
                calibration_style="TAKER",
                entry_fee_per_share=entry_fee,
                entry_cost_per_share=entry_cost,
                tradeable_at_entry=tradeable,
                untradeable_reason=reason,
                first_barrier=barrier,
                barrier_at=barrier_at,
                max_bid=book.best_bid,
                min_bid=book.best_bid,
                horizon_returns=horizons,
            )
            self.samples[sample.id] = sample
            self.last_sample_at[signal.token_id] = timestamp
            self.store.record_signal_outcome(self.run_id, sample)

    def on_book(self, book: OrderBook, timestamp: float) -> None:
        bid = book.best_bid
        if (
            bid is None
            or not book.top_is_fresh(
                "BUY", timestamp, self.config.strategy.top_book_stale_seconds
            )
        ):
            return
        asset = self.assets.get(book.token_id)
        if asset is None:
            return
        max_horizon = max(self.config.strategy.outcome_horizons_seconds)
        for sample_id, sample in list(self.samples.items()):
            if sample.token_id != book.token_id or sample.completed:
                continue
            changed = False
            if bid > sample.max_bid:
                sample.max_bid = bid
                changed = True
            if bid < sample.min_bid:
                sample.min_bid = bid
                changed = True

            net_return = self._net_exit_return(asset, bid, sample.entry_cost_per_share)
            if sample.tradeable_at_entry and sample.first_barrier is None:
                if net_return >= Decimal(str(self.config.strategy.target_return)):
                    sample.first_barrier = "TARGET"
                    sample.barrier_at = timestamp
                    changed = True
                elif net_return <= -Decimal(str(self.config.strategy.stop_loss)):
                    sample.first_barrier = "STOP"
                    sample.barrier_at = timestamp
                    changed = True
            for horizon in sample.horizon_returns:
                if sample.horizon_returns[horizon] is not None:
                    continue
                if timestamp >= sample.created_at + horizon:
                    sample.horizon_returns[horizon] = float(net_return)
                    changed = True
            if timestamp >= sample.created_at + max_horizon and all(
                value is not None for value in sample.horizon_returns.values()
            ):
                sample.completed = True
                changed = True
            if changed:
                self.store.record_signal_outcome(self.run_id, sample)
            if sample.completed:
                self.samples.pop(sample_id, None)

    def _fee_per_share(self, asset: Asset, price: Decimal) -> Decimal:
        schedule = asset.fee_schedule
        if schedule.known and not schedule.enabled:
            return ZERO
        rate = schedule.rate
        if rate <= ZERO:
            rate = Decimal(str(self.config.execution.default_taker_fee_rate))
        exponent = schedule.exponent
        if exponent <= ZERO:
            exponent = Decimal(str(self.config.execution.default_fee_exponent))
        return rate * ((price * (ONE - price)) ** exponent)

    def _net_exit_return(
        self, asset: Asset, bid: Decimal, entry_cost_per_share: Decimal
    ) -> Decimal:
        if entry_cost_per_share <= ZERO:
            return Decimal("-1")
        exit_fee = self._fee_per_share(asset, bid)
        net_proceeds = max(ZERO, bid - exit_fee)
        return net_proceeds / entry_cost_per_share - ONE

    def _price_for_return(
        self,
        asset: Asset,
        book: OrderBook,
        entry_cost: Decimal,
        desired_return: Decimal,
        *,
        upward: bool,
    ) -> Decimal:
        """Return a tick-rounded indicative bid price for a net return barrier."""

        tick = book.tick_size
        if upward:
            price = max(tick, ceil_to_tick(entry_cost * (ONE + desired_return), tick))
            while price < ONE:
                if self._net_exit_return(asset, price, entry_cost) >= desired_return:
                    return min(ONE - tick, price)
                price += tick
            return ONE - tick

        price = min(ONE - tick, floor_to_tick(entry_cost * (ONE + desired_return), tick))
        while price > tick:
            if self._net_exit_return(asset, price, entry_cost) <= desired_return:
                return max(tick, price)
            price -= tick
        return tick

    @property
    def active_count(self) -> int:
        return len(self.samples)
