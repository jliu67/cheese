"""PM-Scalper public-data research package."""

__version__ = "2.1.0"
