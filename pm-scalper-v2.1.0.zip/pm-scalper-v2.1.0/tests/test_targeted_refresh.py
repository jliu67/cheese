from __future__ import annotations

import asyncio
import time

import pytest

from pm_scalper.config import AppConfig
from pm_scalper.engine import EventSequencer, OnDemandBookRefresher


@pytest.mark.asyncio
async def test_targeted_book_refresh_emits_causal_later_book_event(monkeypatch) -> None:
    class FakeClob:
        def __init__(self, config):  # noqa: ANN001
            del config

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, traceback):  # noqa: ANN001
            return False

        async def fetch_books(self, token_ids):  # noqa: ANN001
            assert token_ids == ["token"]
            await asyncio.sleep(0)
            return [
                {
                    "asset_id": "token",
                    "timestamp": str(int(time.time() * 1000)),
                    "bids": [{"price": "0.49", "size": "10"}],
                    "asks": [{"price": "0.51", "size": "10"}],
                }
            ]

    monkeypatch.setattr("pm_scalper.engine.ClobDataClient", FakeClob)
    config = AppConfig()
    stop = asyncio.Event()
    queue = asyncio.Queue()
    sequencer = EventSequencer()
    refresher = OnDemandBookRefresher(config, stop, queue, sequencer)
    task = asyncio.create_task(refresher.worker(0))
    try:
        request_id = refresher.request("token", "ENTRY_DECISION", time.time(), "attempt")
        assert request_id is not None
        envelope = await asyncio.wait_for(queue.get(), timeout=1)
        event = envelope.payload
        assert envelope.sequence_id == 1
        assert event["event_type"] == "book"
        assert event["_refresh_request_id"] == request_id
        assert event["_refresh_purpose"] == "ENTRY_DECISION"
        assert event["_refresh_related_id"] == "attempt"
        assert event["_refresh_success"] is True
        assert event["_refresh_completed_at"] >= event["_refresh_started_at"]
    finally:
        stop.set()
        task.cancel()
        await asyncio.gather(task, return_exceptions=True)


@pytest.mark.asyncio
async def test_targeted_refresh_coalesces_same_exact_request(monkeypatch) -> None:
    del monkeypatch
    config = AppConfig()
    stop = asyncio.Event()
    queue = asyncio.Queue()
    sequencer = EventSequencer()
    refresher = OnDemandBookRefresher(config, stop, queue, sequencer)
    first = refresher.request("token", "EXIT", time.time() + 100, "exit-1")
    second = refresher.request("token", "EXIT", time.time() + 100, "exit-1")
    assert first is not None
    assert second == first
    assert refresher.requests.qsize() == 1
