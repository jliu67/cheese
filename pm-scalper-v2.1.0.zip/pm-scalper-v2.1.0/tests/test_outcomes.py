from __future__ import annotations

from decimal import Decimal

from pm_scalper.book import BookStore
from pm_scalper.config import AppConfig
from pm_scalper.models import Asset, FeeSchedule
from pm_scalper.outcomes import SignalOutcomeTracker
from test_paper_broker import BASE, make_signal


class OutcomeStore:
    def __init__(self) -> None:
        self.rows = []

    def record_signal_outcome(self, run_id, outcome):  # noqa: ANN001
        self.rows.append((run_id, outcome.id, outcome.first_barrier, dict(outcome.horizon_returns)))


def test_forward_signal_outcome_tracks_barrier_and_horizons() -> None:
    config = AppConfig()
    config.strategy.outcome_tracking_min_score = 40
    config.strategy.outcome_tracking_cooldown_seconds = 0
    config.strategy.outcome_horizons_seconds = [5, 10]
    asset = Asset(
        token_id="token",
        market_id="market",
        condition_id="condition",
        slug="slug",
        question="Question?",
        outcome="Yes",
        market_liquidity=Decimal("1000"),
        market_volume_24h=Decimal("100"),
        end_date=None,
        fee_schedule=FeeSchedule(),
    )
    books = BookStore()
    book = books.seed(
        {
            "asset_id": "token",
            "timestamp": str(int(BASE * 1000)),
            "tick_size": "0.001",
            "bids": [{"price": "0.499", "size": "100"}],
            "asks": [{"price": "0.500", "size": "100"}],
        },
        BASE,
        sequence_id=1,
    )
    assert book is not None
    store = OutcomeStore()
    tracker = SignalOutcomeTracker(
        config,
        {asset.token_id: asset},
        books,
        store,  # type: ignore[arg-type]
        "run",
    )

    tracker.observe_signals({"token": make_signal("token", 70, BASE)}, BASE)
    assert tracker.active_count == 1
    sample = next(iter(tracker.samples.values()))
    assert sample.entry_ask == Decimal("0.500")
    assert sample.target_price == Decimal("0.505")

    book.apply_change(
        {"side": "BUY", "price": "0.506", "size": "100"},
        BASE + 2,
        sequence_id=2,
        event_time=BASE + 2,
    )
    tracker.on_book(book, BASE + 2)
    assert sample.first_barrier == "TARGET"

    book.apply_change(
        {"side": "BUY", "price": "0.506", "size": "0"},
        BASE + 5,
        sequence_id=3,
        event_time=BASE + 5,
    )
    book.apply_change(
        {"side": "BUY", "price": "0.504", "size": "100"},
        BASE + 5,
        sequence_id=4,
        event_time=BASE + 5,
    )
    tracker.on_book(book, BASE + 5)
    assert sample.horizon_returns[5] == 0.008

    book.apply_change(
        {"side": "BUY", "price": "0.510", "size": "100"},
        BASE + 10,
        sequence_id=5,
        event_time=BASE + 10,
    )
    tracker.on_book(book, BASE + 10)
    assert sample.completed
    assert tracker.active_count == 0
    assert sample.horizon_returns[10] == 0.02


def test_forward_outcome_does_not_sample_or_label_stale_top_of_book() -> None:
    config = AppConfig()
    config.strategy.outcome_tracking_min_score = 40
    config.strategy.outcome_tracking_cooldown_seconds = 0
    config.strategy.outcome_horizons_seconds = [5]
    config.strategy.top_book_stale_seconds = 1
    asset = Asset(
        token_id="token",
        market_id="market",
        condition_id="condition",
        slug="slug",
        question="Question?",
        outcome="Yes",
        market_liquidity=Decimal("1000"),
        market_volume_24h=Decimal("100"),
        end_date=None,
        fee_schedule=FeeSchedule(),
    )
    books = BookStore()
    book = books.seed(
        {
            "asset_id": "token",
            "timestamp": str(int(BASE * 1000)),
            "tick_size": "0.001",
            "bids": [{"price": "0.499", "size": "100"}],
            "asks": [{"price": "0.500", "size": "100"}],
        },
        BASE,
        sequence_id=1,
    )
    assert book is not None
    store = OutcomeStore()
    tracker = SignalOutcomeTracker(
        config, {asset.token_id: asset}, books, store, "run"  # type: ignore[arg-type]
    )

    tracker.observe_signals({"token": make_signal("token", 70, BASE + 2)}, BASE + 2)
    assert tracker.active_count == 0

    # A full fresh snapshot certifies both sides and allows sampling.
    book.apply_snapshot(
        {
            "asset_id": "token",
            "timestamp": str(int((BASE + 2) * 1000)),
            "tick_size": "0.001",
            "bids": [{"price": "0.499", "size": "100"}],
            "asks": [{"price": "0.500", "size": "100"}],
        },
        BASE + 2,
        sequence_id=2,
    )
    tracker.observe_signals({"token": make_signal("token", 70, BASE + 2)}, BASE + 2)
    assert tracker.active_count == 1
    sample = next(iter(tracker.samples.values()))

    # The old top bid must not complete the five-second horizon after it goes stale.
    tracker.on_book(book, BASE + 8)
    assert sample.horizon_returns[5] is None


def test_spread_loss_at_entry_is_untradeable_not_a_stop_failure() -> None:
    config = AppConfig()
    config.strategy.outcome_tracking_min_score = 40
    config.strategy.outcome_tracking_cooldown_seconds = 0
    config.strategy.outcome_horizons_seconds = [5]
    asset = Asset(
        token_id="token",
        market_id="market",
        condition_id="condition",
        slug="slug",
        question="Question?",
        outcome="Yes",
        market_liquidity=Decimal("1000"),
        market_volume_24h=Decimal("100"),
        end_date=None,
        fee_schedule=FeeSchedule(known=True, enabled=False),
    )
    books = BookStore()
    book = books.seed(
        {
            "asset_id": "token",
            "timestamp": str(int(BASE * 1000)),
            "tick_size": "0.01",
            "bids": [{"price": "0.45", "size": "100"}],
            "asks": [{"price": "0.46", "size": "100"}],
        },
        BASE,
        sequence_id=1,
    )
    assert book is not None
    store = OutcomeStore()
    tracker = SignalOutcomeTracker(
        config, {asset.token_id: asset}, books, store, "run"  # type: ignore[arg-type]
    )

    tracker.observe_signals({"token": make_signal("token", 70, BASE)}, BASE)
    sample = next(iter(tracker.samples.values()))
    assert not sample.tradeable_at_entry
    assert sample.first_barrier == "UNTRADEABLE_AT_ENTRY"
    assert sample.untradeable_reason == "spread and taker fees breach stop at entry"
