#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

choose_python() {
  if [[ -n "${PM_SCALPER_PYTHON:-}" ]]; then
    command -v "$PM_SCALPER_PYTHON" >/dev/null 2>&1 || {
      echo "PM_SCALPER_PYTHON is set but not found: $PM_SCALPER_PYTHON" >&2
      return 1
    }
    printf '%s\n' "$PM_SCALPER_PYTHON"
    return 0
  fi
  local candidate
  for candidate in python3.13 python3.12 python3.11 python3; do
    if command -v "$candidate" >/dev/null 2>&1; then
      if "$candidate" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info >= (3, 11) else 1)
PY
      then
        printf '%s\n' "$candidate"
        return 0
      fi
    fi
  done
  return 1
}

PYTHON_BIN="$(choose_python)" || {
  echo "PM-Scalper V2.1 requires Python 3.11 or newer." >&2
  echo "Ubuntu 24.04: sudo apt install -y python3 python3-venv" >&2
  exit 1
}

printf 'Using %s: ' "$PYTHON_BIN"
"$PYTHON_BIN" --version

if [[ -x .venv/bin/python ]]; then
  if ! .venv/bin/python - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info >= (3, 11) else 1)
PY
  then
    echo "Existing .venv uses an unsupported Python; recreating it."
    rm -rf .venv
  fi
fi

if [[ ! -x .venv/bin/python ]]; then
  rm -rf .venv
  if ! "$PYTHON_BIN" -m venv .venv; then
    echo >&2
    echo "Could not create .venv. Install virtual-environment support, then retry:" >&2
    echo "  sudo apt update && sudo apt install -y python3-venv" >&2
    exit 1
  fi
fi

.venv/bin/python -m pip install --upgrade pip setuptools wheel
.venv/bin/python -m pip install -e '.[dev]'
.venv/bin/pm-scalper validate --config config/default.yaml

printf '\nInstalled successfully. Next commands:\n'
printf '  .venv/bin/pm-scalper discover --config config/default.yaml\n'
printf '  ./scripts/run-paper.sh\n  ./scripts/progress.sh --top 20\n'
