# PM-Scalper V2.1

PM-Scalper V2.1 is a **live Polymarket public-data recorder and forward paper-trading research engine** for short-horizon YES/NO contracts. It watches liquid markets, calculates a transparent short-term opportunity score, simulates queue-aware entries, aims for a tick-valid profit target around `+1%`, and records enough execution and outcome data to determine whether the idea actually has an edge.

> **Paper only.** This release cannot place a real order. It contains no wallet, private key, signing, authentication, deposit, withdrawal, or live-order code. Configuration validation rejects every execution mode except `paper`.

V2.1 is not a profitability claim. It is a stricter simulator and data-collection release designed to stop the paper engine from granting itself fills or liquidation prices that a simultaneously running real trader could not have received.

## What changed in V2.1

V2.1 is a narrow execution/diagnostics correction based on the live V2 run that produced eligible `69+` signals but no orders because execution rejected stale top-of-book/depth state. It keeps the score threshold and hybrid maker/taker concept; it changes what happens after a signal becomes eligible.

### Targeted freshness and execution

- **Stale eligible signals now request a targeted CLOB book refresh instead of being abandoned.** The refresh is only for the affected token and runs in separate async workers, so the WebSocket event processor does not block on REST.
- **Separate freshness clocks.** V2.1 tracks quote age, bid/ask top-level age, and complete-depth age independently. Maker/taker sizing requires the appropriate fresh executable state rather than treating one generic timestamp as sufficient.
- **Post-refresh signal recheck.** A refreshed book does not execute an old score blindly. The feature/signal snapshot is recalculated from the later state; an entry proceeds only if the latest signal is still eligible and at or above the configured `entry_score`.
- **Causal refresh sequencing.** A targeted REST response enters the same monotonic local event stream as WebSocket events. Orders created afterward can only fill from qualifying later observations after simulated latency.
- **Targeted refreshes for taker entries and risk exits.** Pending marketable entries and exits can request later authoritative depth when the cached side cannot support a causal fill.

### Auditability

- **Persistent `entry_attempts`.** Every eligible entry decision is recorded even if no order is created, including initial/refreshed score, bid/ask, quote/depth ages, refresh request/result/latency, candidate execution style, estimated economics, final decision, and reason.
- **Expanded progress view.** `pm-scalper progress` now reports refresh requests/success/failures/timeouts, average/max refresh latency, pending refreshes, recent entry attempts, and exact entry-block reasons.
- **Operational logging.** Entry attempts and targeted refresh request/results are emitted to `logs/pm-scalper-v2.1.log`.

### Forward-calibration correction

- **Spread/fee-invalid samples are no longer counted as stop failures.** A hypothetical taker entry whose initial executable bid, spread, and taker fees already breach the configured stop is labelled `UNTRADEABLE_AT_ENTRY`.
- **Fee-aware taker calibration.** Tradeable samples enter hypothetically at the ask plus entry fee and evaluate later executable bids net of exit fee for target-before-stop and horizon-return statistics.

### Preserved V2 safeguards

V2.1 retains causal event sequencing, simulated maker/taker latency, shadow liquidity, stale-exit protection, fee/depth-aware liquidation equity, trade deduplication, queue-aware maker entries, hybrid maker/taker execution, signal hysteresis, near-full-bankroll depth-capped paper sizing, and paper-only operation.

## Default V2.1 behavior

```yaml
strategy:
  entry_score: 69
  entry_cancel_score: 65
  signal_fade_grace_seconds: 20
  target_return: 0.01
  stop_loss: 0.0125
  maximum_hold_seconds: 14400   # 4 hours

risk:
  starting_cash_usdc: 10000
  sizing_mode: bankroll_fraction
  bankroll_fraction: 0.98
  cash_buffer_usdc: 25
  max_open_positions: 1
  depth_utilization: 0.50

execution:
  mode: paper
  entry_style: hybrid
  maker_latency_ms: 250
  taker_latency_ms: 250
```

This does **not** guarantee that every entry uses exactly 98% of the bankroll. The final quantity is the minimum allowed by available cash, risk limits, fresh executable depth, market minimum share size, valid price ticks, and fee-aware affordability.

## Install on Ubuntu or Debian

PM-Scalper requires Python 3.11 or newer. The installer automatically selects Python 3.13, 3.12, 3.11, or a compatible `python3`.

```bash
cd pm-scalper-v2.1.0
chmod +x scripts/*.sh
./scripts/bootstrap.sh
```

Ubuntu 24.04 normally uses Python 3.12, which is supported.

If virtual-environment support is missing:

```bash
sudo apt update
sudo apt install -y python3-venv
./scripts/bootstrap.sh
```

Verify the installation:

```bash
.venv/bin/pm-scalper --version
.venv/bin/pm-scalper validate --config config/default.yaml
```

## Upgrade from V2

V2.1 uses a separate database, raw-data directory, and export directory:

```text
data/pm_scalper_v2_1.sqlite3
data/raw-v2.1/
exports-v2.1/
```

It therefore does not mix V2.1 results with the earlier V2 database. Keep the V2 folder/data for comparison, but run V2.1 from its own extracted folder.

On the remote server:

```bash
cd ~/cheese
unzip pm-scalper-v2.1.0.zip
cd pm-scalper-v2.1.0
chmod +x scripts/*.sh
./scripts/bootstrap.sh
.venv/bin/pm-scalper validate --config config/default.yaml
.venv/bin/pm-scalper discover --config config/default.yaml
```

Stop the old V2 process before starting V2.1 so both programs do not duplicate storage and network work:

```bash
pgrep -af 'pm-scalper paper'
```

Use `Ctrl+C` in the V2 tmux session, or terminate only the verified V2 PID.

## Check the live universe

```bash
.venv/bin/pm-scalper discover --config config/default.yaml
```

The message that some outcomes “failed live book filters” means they were rejected by liquidity, spread, price, depth, or market-time filters. It is not a program failure.

## Run continuously on Lightsail with tmux

```bash
cd ~/cheese/pm-scalper-v2.1.0

tmux new -s polymarket-v21
./scripts/run-paper.sh
```

Detach without stopping the bot:

```text
Ctrl+B, release, then D
```

Later:

```bash
tmux ls
tmux attach -t polymarket-v21
```

For Lightsail, the headless runner avoids the Rich dashboard repaint entirely:

```bash
tmux kill-session -t polymarket-v21 2>/dev/null || true
tmux new-session -d -s polymarket-v21 \
  "cd $HOME/cheese/pm-scalper-v2.1.0 && exec ./scripts/run-paper-headless.sh"
```

The Lightsail browser terminal may flicker while the Rich dashboard redraws. Detaching from tmux does not stop the engine. The reduced V2.1 refresh rate affects only the display, not the market-data or decision loop.

## Verify that it is working

Check the process:

```bash
pgrep -af 'pm-scalper paper'
```

Check that the raw event file is growing:

```bash
cd ~/cheese/pm-scalper-v2.1.0
watch -n 5 'du -h data/raw-v2.1/$(date -u +%F)/events-*.jsonl'
```

Inspect progress while the bot remains running:

```bash
.venv/bin/pm-scalper progress --config config/default.yaml
```

The progress view reports:

- minimum, average, and maximum scores;
- counts above `40`, `45`, `50`, `55`, `58`, `60`, `62`, `65`, `67`, `69`, `70`, `72`, and `75`;
- eligible samples;
- persistent entry attempts, including blocked/refreshing/order-created states;
- quote/top/depth ages for recent attempts;
- targeted refresh requests, successes, failures, timeouts, and latency;
- initial score → refreshed score so a faded setup is visible;
- maker/taker order states and any fills;
- average queue ahead;
- event queue depth and current/maximum processing lag;
- duplicate trades ignored;
- pending fresh-depth exits;
- exact entry rejection reasons;
- missed moves after cancelled entries;
- fee-aware forward calibration split into tradeable and `UNTRADEABLE_AT_ENTRY` samples.

## Record without paper trading

Run until `Ctrl+C`:

```bash
./scripts/record-feed.sh
```

Or record for a fixed period:

```bash
.venv/bin/pm-scalper record \
  --config config/default.yaml \
  --duration 30m
```

Raw normalized events are stored under:

```text
data/raw-v2.1/YYYY-MM-DD/events-<run-id>.jsonl
```

## Generate a report

For the newest run:

```bash
.venv/bin/pm-scalper report --config config/default.yaml
```

For a specific run:

```bash
.venv/bin/pm-scalper report \
  --config config/default.yaml \
  --run-id YOUR_RUN_ID
```

Exports appear under:

```text
exports-v2.1/<run-id>/
├── summary.json
├── trades.csv
├── equity.csv
├── signals.csv
├── orders.csv
├── fills.csv
├── exit_requests.csv
├── signal_outcomes.csv
├── missed_moves.csv
└── runtime_metrics.csv
```

## How V2.1 execution works

### 1. Signal

The V2.1 baseline score still combines:

```text
short momentum
+ multi-level book imbalance
+ recent aggressive trade flow
+ volume acceleration
+ microprice edge
- spread penalty
- short-horizon volatility penalty
```

The score is a heuristic rank, **not a probability**. A score of `70` does not mean a 70% chance of profit. Forward outcome labels are included specifically to test whether higher score buckets actually predict better future prices.

### 2. Queue-aware maker entry

A resting maker order records:

- its simulated creation time;
- its activation time after latency;
- the last event sequence already processed at creation;
- displayed shares ahead at its price;
- an estimated queue-clear time from recent opposing trade flow.

Only a qualifying trade received after both the sequence and activation gates can reduce queue ahead or fill the order. A single public trade print is shared across candidate paper orders and cannot be reused in full for each one.

### 3. Hybrid taker entry

A high score does not automatically cross the spread. V2.1 checks:

- current fresh ask depth;
- spread cap;
- valid tick prices;
- share minimum;
- configured taker fee curve;
- available paper cash;
- the rounded maker target after entry;
- whether the resulting target still has positive configured net economics.

Even after passing, the order waits for later fresh ask depth rather than filling against the decision snapshot.

### 4. Profit target

The target is rounded upward to the first valid tick producing at least the configured gross return. Therefore a nominal `+1%` target may be larger in a coarse-tick market. For example, `0.50 → 0.51` is a 2% gross price move.

The target is normally simulated as a maker sell. Queue-ahead logic applies to it too.

### 5. Risk exit

A stop or other forced exit does not invent a fill from stale depth. V2.1:

```text
trigger exit
→ cancel resting target
→ create EXIT_REQUIRED request
→ wait for later fresh authoritative bid depth
→ submit a full-position FAK-style paper sell
→ fill only the shares available in the shadow book
→ cancel the unfilled remainder
→ wait for another later fresh bid observation if shares remain
```

This can make paper losses look worse and exits slower than V1. That is intentional.

### 6. Shadow liquidity

The simulator tracks observed public depth separately from remaining counterfactual paper depth. If public size changes from 10 shares to 12 shares after the paper trader consumed 5, only the demonstrated increase of 2 can replenish the shadow book. The simulator does not restore all 12 automatically.

### 7. Mark equity versus liquidation equity

- **Mark equity:** values each open position at the displayed best bid. Useful as a conventional mark.
- **Liquidation equity:** walks currently fresh shadow bid depth, deducts taker fees, and values unfilled quantity at the configured conservative haircut.

Daily-loss and kill-switch decisions use liquidation equity.

## Forward score calibration

Every eligible tracking sample uses the fresh ask as the hypothetical entry and later fresh bids as hypothetical exits. It records target-before-stop behavior and returns after each configured horizon.

This calibration deliberately does **not** assume a maker fill. However, it is still a top-of-book signal diagnostic, not a full-bankroll executable backtest. It does not walk all future depth for each sample or model the market impact of a real large order.

## Important limitations

- Aggregate public order books do not expose exact private queue IDs, every cancellation, hidden orders, or how other participants would react to the user's order.
- V2.1 treats the public trade `side` field as the aggressor direction for maker-queue simulation. That is an execution-model assumption and should be sensitivity-tested.
- The universe is selected at startup and remains fixed during that run.
- No model has yet proved that the V2.1 score predicts profit. The outcome tables are there to test that claim.
- Near-full-bankroll sizing greatly magnifies a bad signal, news gap, thin-book exit, fee error, or venue failure. It is enabled only to paper-test the user's proposed design.
- **Open positions and pending orders are not restored into memory after a process restart.** Historical database rows remain, but each new process is a fresh paper run. Stop while flat when possible; do not interpret an interrupted run as a continuous portfolio.
- Market resolution is paper-settled at `1` or `0`; that payoff is different from ordinary CLOB liquidity.
- Maker rebates and liquidity rewards are not credited.
- Venue access, law, terms, and geographic restrictions remain the user's responsibility. This project does not implement restriction bypasses.

## Change bankroll behavior

Near-full-bankroll mode:

```yaml
risk:
  starting_cash_usdc: 10000
  sizing_mode: bankroll_fraction
  bankroll_fraction: 0.98
  cash_buffer_usdc: 25
  max_open_positions: 1
  depth_utilization: 0.50
```

Conservative fixed-size paper mode:

```yaml
risk:
  sizing_mode: fixed
  fixed_position_usdc: 1000
  max_open_positions: 1
```

Do not raise `depth_utilization` merely to force the simulator to deploy more money. The cap exists to prevent a large paper order from assuming unrealistic liquidity.

## Data layout

```text
data/pm_scalper_v2_1.sqlite3       V2.1 structured database
data/raw-v2.1/...                  normalized live and REST events
logs/pm-scalper-v2.1.log              operational log
exports-v2.1/<run-id>/...          reports
```

## Run tests

```bash
.venv/bin/python -m pytest
```

The release suite includes regression tests for causality, stale exits, shadow liquidity, liquidation equity, minimum share size, duplicate trades, hybrid entry timing/economics, signal hysteresis, full-bankroll sizing, partial FAK exits, stale outcome labels, and report/storage behavior.

## Project layout

```text
pm-scalper-v2.1.0/
├── config/default.yaml
├── scripts/
│   ├── bootstrap.sh
│   ├── run-paper.sh
│   ├── record-feed.sh
│   └── progress.sh
├── src/pm_scalper/
│   ├── polymarket.py       public API and WebSocket clients
│   ├── book.py             observed book and per-level freshness
│   ├── shadow.py           counterfactual executable liquidity
│   ├── features.py         local-time short-horizon features
│   ├── signal.py           transparent score
│   ├── outcomes.py         forward score calibration
│   ├── paper.py            hybrid execution and risk engine
│   ├── storage.py          JSONL and SQLite persistence
│   ├── dashboard.py        terminal UI
│   ├── progress.py         live diagnostics
│   ├── report.py           CSV/JSON analytics
│   └── cli.py
└── tests/
```

## Official protocol references

- Market discovery: <https://docs.polymarket.com/market-data/discover-markets>
- Prices and order books: <https://docs.polymarket.com/market-data/prices-order-books>
- Place orders and share-size minimums: <https://docs.polymarket.com/trading/place-orders>
- Order lifecycle and FAK behavior: <https://docs.polymarket.com/concepts/order-lifecycle>
- Market WebSocket: <https://docs.polymarket.com/market-data/realtime-data>
- Trading fees: <https://docs.polymarket.com/trading/fees>
